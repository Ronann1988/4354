import gate_api
from gate_api.exceptions import ApiException, GateApiException
import telebot
from dotenv import load_dotenv
import re
import time
from datetime import datetime
import logging
import sqlite3
from threading import Thread, Lock
import schedule
import threading
from decimal import Decimal, ROUND_DOWN
import random
import traceback
import os
import json  # Добавляем импорт json

# Импортируем TrailingStopManager
from trailing_stop_manager import TrailingStopManager

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('trading-bot')


# Функция для создания необходимых файлов
def create_required_files():
    """Создает только необходимые файлы для работы бота"""
    from pathlib import Path
    import sys
    import os

    # Определяем рабочую директорию
    if getattr(sys, 'frozen', False):
        # Если запущен .exe
        BASE_DIR = Path(sys.executable).parent
    else:
        # Если запущен .py
        BASE_DIR = Path(__file__).parent.absolute()

    # Переходим в рабочую директорию
    os.chdir(BASE_DIR)

    # Создание файла signals.txt если его нет
    signals_file = BASE_DIR / SIGNALS_FILE
    if not signals_file.exists():
        with open(signals_file, 'w', encoding='utf-8') as f:
            f.write("# Файл для торговых сигналов\n")

    # Создание папки для логов если её нет
    log_dir = BASE_DIR / "logs"
    if not log_dir.exists():
        os.makedirs(log_dir)


def create_env_file():
    """Создает файл .env из 1.env или создает пустой"""
    from pathlib import Path
    import sys
    import os

    # Определяем рабочую директорию
    if getattr(sys, 'frozen', False):
        # Если запущен .exe
        BASE_DIR = Path(sys.executable).parent
    else:
        # Если запущен .py
        BASE_DIR = Path(__file__).parent.absolute()

    # Переходим в рабочую директорию
    os.chdir(BASE_DIR)

    env_file = BASE_DIR / ".env"

    # Если .env уже существует, ничего не делаем
    if env_file.exists():
        return True

    # Копируем из 1.env если он есть
    if (BASE_DIR / "1.env").exists():
        with open(BASE_DIR / "1.env", 'r', encoding='utf-8') as f:
            env_content = f.read()
        with open(env_file, 'w', encoding='utf-8') as f:
            f.write(env_content)
        return True

    # Создаем пустой .env файл
    with open(env_file, 'w', encoding='utf-8') as f:
        f.write("# Конфигурация торгового бота\n")
        f.write("TELEGRAM_TOKEN=\n")
        f.write("GATEIO_API_KEY=\n")
        f.write("GATEIO_API_SECRET=\n")
        f.write("GROUP_CHAT_ID=\n")
        f.write("ALLOWED_USERS=\n")

    return True


# Загрузка переменных окружения
def load_environment():
    """Загружает переменные окружения"""
    # Создаем .env если его нет
    create_env_file()

    # Загружаем переменные
    load_dotenv()

    # Получаем переменные с значениями по умолчанию
    TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN', '')
    GROUP_CHAT_ID = os.getenv('GROUP_CHAT_ID', '0')
    ALLOWED_USERS_STR = os.getenv('ALLOWED_USERS', '')
    GATEIO_API_KEY = os.getenv('GATEIO_API_KEY', '')
    GATEIO_API_SECRET = os.getenv('GATEIO_API_SECRET', '')

    # Отладочный вывод
    logger.debug(f"TELEGRAM_TOKEN: {TELEGRAM_TOKEN}")
    if not TELEGRAM_TOKEN or ':' not in TELEGRAM_TOKEN:
        logger.error("TELEGRAM_TOKEN не содержит двоеточия или пустой")

    return TELEGRAM_TOKEN, GROUP_CHAT_ID, ALLOWED_USERS_STR, GATEIO_API_KEY, GATEIO_API_SECRET


# Загружаем переменные окружения
TELEGRAM_TOKEN, GROUP_CHAT_ID_STR, ALLOWED_USERS_STR, GATEIO_API_KEY, GATEIO_API_SECRET = load_environment()

# Преобразуем строки в нужные типы
GROUP_CHAT_ID = int(GROUP_CHAT_ID_STR) if GROUP_CHAT_ID_STR.replace('-', '').isdigit() else 0
ALLOWED_USERS = [int(uid) for uid in ALLOWED_USERS_STR.split(',') if uid and uid.isdigit()]

# Глобальная переменная для отслеживания активных трейлинг-стопов
active_trailing_stops = {}

# Глобальные словари для отслеживания потоков
user_threads = {}  # {user_id: {'signals': thread, 'sync': thread, 'trailing': {thread_key: thread}}}
thread_status = {}  # {user_id: {'signals': 'running'/'stopped', 'sync': 'running'/'stopped', 'trailing': {thread_key: 'running'/'stopped'}}}

# Путь к файлу сигналов и базе данных
SIGNALS_FILE = "signals.txt"
DB_PATH = "trading_bot.db"
CHECK_INTERVAL = 5

# Инициализация Telegram бота
bot = telebot.TeleBot(TELEGRAM_TOKEN)

# Инициализация Gate.io API (v4)
configuration = gate_api.Configuration(
    host="https://api.gateio.ws/api/v4",
    key=GATEIO_API_KEY,
    secret=GATEIO_API_SECRET
)
api_client = gate_api.ApiClient(configuration)
futures_api = gate_api.FuturesApi(api_client)

# Состояния и блокировка
states = {}
user_top3_data = {}  # Для временного хранения данных ТОП-3 при импорте
lock = Lock()
processed_messages = set()

# --- Глобальный словарь для хранения данных регистрации ---
user_reg_data = {}

# --- Переменные для предотвращения дублирования сообщений ---
sent_messages = set()
message_lock = Lock()

def clean_processed_messages():
    with lock:
        processed_messages.clear()  # Или удалять сообщения старше определенного времени


schedule.every(1).minute.do(clean_processed_messages)


# --- Безопасное получение данных пользователя ---
def safe_get_user_data(user_id, chat_id=None):
    user_data = get_user_data(user_id)
    if not user_data:
        if chat_id:
            bot.send_message(chat_id, "Пользователь не зарегистрирован. Используйте /start.")
        return None
    return user_data


# Функция для соединения с базой данных
def get_db_connection():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logger.error(f"Ошибка подключения к базе данных {DB_PATH}: {str(e)}")
        raise


# Инициализация базы данных
with get_db_connection() as conn:
    cursor = conn.cursor()

    # Создание таблицы users
    cursor.execute('''
                   CREATE TABLE IF NOT EXISTS users
                   (
                       user_id
                       INTEGER
                       PRIMARY
                       KEY,
                       api_key
                       TEXT, -- Gate.io API ключ
                       api_secret
                       TEXT, -- Gate.io API секрет
                       account_type
                       TEXT
                       DEFAULT
                       'demo',
                       leverage
                       REAL
                       DEFAULT
                       10.0,
                       margin_mode
                       TEXT
                       DEFAULT
                       'isolated',
                       order_type
                       TEXT
                       DEFAULT
                       'percentage',
                       qty_percentage
                       REAL
                       DEFAULT
                       5.0,
                       fixed_volume
                       REAL
                       DEFAULT
                       100.0,
                       initial_stop_percentage
                       REAL
                       DEFAULT
                       3.0,
                       trigger_profit_percentage
                       REAL
                       DEFAULT
                       5.0,
                       profit_lock_percentage
                       REAL
                       DEFAULT
                       2.0,
                       trailing_percentage
                       REAL
                       DEFAULT
                       1.0,
                       trailing_interval
                       REAL
                       DEFAULT
                       3.0,
                       daily_loss_limit
                       INTEGER
                       DEFAULT
                       3,
                       max_open_trades
                       INTEGER
                       DEFAULT
                       5,
                       is_trading
                       INTEGER
                       DEFAULT
                       0,
                       report_type
                       TEXT
                       DEFAULT
                       'fixed',
                       report_time
                       TEXT
                       DEFAULT
                       '00:00',
                       averaging_enabled
                       INTEGER
                       DEFAULT
                       0,    -- Включение усреднения (0 - выкл, 1 - вкл)
                       averaging_pause
                       REAL
                       DEFAULT
                       300.0 -- Пауза между усреднениями в секундах
                   )
                   ''')

    # Создание таблицы trades
    cursor.execute('''
                   CREATE TABLE IF NOT EXISTS trades
                   (
                       trade_id
                       INTEGER
                       PRIMARY
                       KEY
                       AUTOINCREMENT,
                       user_id
                       INTEGER,
                       symbol
                       TEXT,
                       side
                       TEXT,
                       price
                       REAL,
                       amount
                       REAL,
                       timestamp
                       INTEGER,
                       status
                       TEXT,
                       timescale
                       TEXT,
                       current_stop_price
                       REAL,
                       open_order_id
                       TEXT,
                       close_order_id
                       TEXT,
                       average_entry_price
                       REAL,
                       trailing_active
                       INTEGER
                       DEFAULT
                       0,
                       highest_price
                       REAL,
                       lowest_price
                       REAL,
                       close_reason
                       TEXT,
                       close_price
                       REAL,
                       pnl
                       REAL
                       DEFAULT
                       0.0, -- Добавляем поле pnl
                       fees
                       REAL
                       DEFAULT
                       0.0, -- Добавляем поле fees
                       FOREIGN
                       KEY
                   (
                       user_id
                   ) REFERENCES users
                   (
                       user_id
                   )
                       )
                   ''')

    # Создание таблицы tp_config
    cursor.execute('''
                   CREATE TABLE IF NOT EXISTS tp_config
                   (
                       user_id
                       INTEGER,
                       timescale
                       TEXT
                       NOT
                       NULL,
                       stop_loss_percentage
                       REAL,
                       trigger_profit_percentage
                       REAL,
                       trailing_percentage
                       REAL,
                       profit_lock_percentage
                       REAL,
                       pnl_based_trailing
                       BOOLEAN
                       DEFAULT
                       0,
                       PRIMARY
                       KEY
                   (
                       user_id,
                       timescale
                   )
                       )
                   ''')

    # Добавляем поле pnl_based_trailing если его нет
    try:
        cursor.execute('ALTER TABLE tp_config ADD COLUMN pnl_based_trailing BOOLEAN DEFAULT 0')
    except sqlite3.OperationalError:
        # Поле уже существует
        pass

    # Создание индексов
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_timestamp ON trades(timestamp)")

    # Проверка наличия столбца original_stop_price и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'original_stop_price' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN original_stop_price REAL;
                       ''')

    # Проверка наличия столбца trailing_stop_price и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'trailing_stop_price' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN trailing_stop_price REAL;
                       ''')

    # Проверка наличия столбца close_price и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'close_price' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN close_price REAL;
                       ''')

    # Проверка наличия столбца margin и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'margin' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN margin REAL;
                       ''')

    # Проверка наличия столбца balance_at_open и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'balance_at_open' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN balance_at_open REAL;
                       ''')

    # Проверка наличия столбца signal_id и добавление его, если он отсутствует
    cursor.execute("PRAGMA table_info(trades)")
    columns = cursor.fetchall()
    if not any(col[1] == 'signal_id' for col in columns):
        cursor.execute('''
                       ALTER TABLE trades
                           ADD COLUMN signal_id TEXT;
                       ''')

    conn.commit()


# Функции для работы с базой данных
def add_user(user_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        logger.info(f"Добавление пользователя с ID: {user_id}")
        cursor.execute('''
                       INSERT
                       OR IGNORE INTO users (user_id) VALUES (?)
                       ''', (user_id,))
        conn.commit()


def update_user_data(user_id, key, value):
    allowed_keys = [
        'api_key', 'api_secret', 'account_type', 'leverage', 'margin_mode', 'order_type',
        'qty_percentage', 'fixed_volume', 'initial_stop_percentage', 'trigger_profit_percentage',
        'profit_lock_percentage', 'trailing_percentage', 'trailing_interval', 'daily_loss_limit',
        'max_open_trades', 'is_trading', 'report_type', 'report_time',
        'averaging_enabled', 'averaging_pause'
    ]
    if key not in allowed_keys:
        raise ValueError(f"Недопустимый ключ: {key}")
    if key == 'report_time':
        user_data = get_user_data(user_id)
        if user_data is None:
            raise ValueError("Пользователь не найден")
        if user_data['report_type'] == 'fixed':
            if not re.match(r'^([0-1][0-9]|2[0-3]):([0-5][0-9])$', str(value)):
                raise ValueError("Недопустимый формат времени для fixed, ожидается ЧЧ:ММ")
        else:
            try:
                interval = float(value)
                if interval < 1 or interval > 24:
                    raise ValueError("Интервал должен быть от 1 до 24 часов")
            except ValueError:
                raise ValueError("Для interval ожидается число (например, 6)")
    if key == 'averaging_enabled':
        value = int(value)
        if value not in [0, 1]:
            raise ValueError("averaging_enabled должно быть 0 или 1")
    if key == 'averaging_pause':
        try:
            value = float(value)
            if value < 60:
                raise ValueError("Пауза между усреднениями должна быть не менее 60 секунд")
        except ValueError:
            raise ValueError("averaging_pause должно быть числом (например, 300)")
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(f"UPDATE users SET {key} = ? WHERE user_id = ?", (value, user_id))
        if cursor.rowcount == 0:
            logger.warning(f"Пользователь {user_id} не найден")
        conn.commit()
        logger.info(f"Обновлено {key} для пользователя {user_id}: {value}")


def get_user_data(user_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT user_id,
                              api_key,
                              api_secret,
                              account_type,
                              leverage,
                              margin_mode,
                              order_type,
                              qty_percentage,
                              fixed_volume,
                              initial_stop_percentage,
                              trigger_profit_percentage,
                              profit_lock_percentage,
                              trailing_percentage,
                              trailing_interval,
                              daily_loss_limit,
                              max_open_trades,
                              is_trading,
                              report_type,
                              report_time,
                              averaging_enabled,
                              averaging_pause
                       FROM users
                       WHERE user_id = ?
                       ''', (user_id,))
        row = cursor.fetchone()
        if row:
            return {
                'user_id': row[0], 'api_key': row[1], 'api_secret': row[2], 'account_type': row[3],
                'leverage': row[4], 'margin_mode': row[5], 'order_type': row[6], 'qty_percentage': row[7],
                'fixed_volume': row[8], 'initial_stop_percentage': row[9], 'trigger_profit_percentage': row[10],
                'profit_lock_percentage': row[11], 'trailing_percentage': row[12], 'trailing_interval': row[13],
                'daily_loss_limit': row[14], 'max_open_trades': row[15], 'is_trading': row[16],
                'report_type': row[17], 'report_time': row[18], 'averaging_enabled': row[19],
                'averaging_pause': row[20]
            }
        return None


def add_trade(user_id, symbol, side, price, amount, timestamp, status, timescale, current_stop_price=None,
              open_order_id=None, average_entry_price=None, trailing_active=0, highest_price=None, lowest_price=None,
              close_reason=None, original_stop_price=None, trailing_stop_price=None, margin=None, balance_at_open=None, signal_id=None):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        logger.info(
            f"Добавление сделки для {user_id}: {symbol}, {side}, {price}, {amount:.2f}, {timescale}, margin={margin}, balance_at_open={balance_at_open}")
        cursor.execute('''
                       INSERT INTO trades (user_id, symbol, side, price, amount, timestamp, status, timescale,
                                           current_stop_price, open_order_id, average_entry_price, trailing_active,
                                           highest_price, lowest_price, close_reason, original_stop_price,
                                           trailing_stop_price, margin, balance_at_open, signal_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                       (user_id, symbol, side, price, amount, timestamp, status, timescale,
                        current_stop_price, open_order_id, average_entry_price, trailing_active,
                        highest_price, lowest_price, close_reason, original_stop_price, trailing_stop_price, margin,
                        balance_at_open, signal_id))
        conn.commit()
        return cursor.lastrowid


def get_open_trades(user_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT *
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'OPEN'
                       ''', (user_id,))
        return [dict(t) for t in cursor.fetchall()]


def get_open_trades_with_pnl(user_id):
    """Получает открытые позиции с расчетом текущего PnL"""
    open_trades = get_open_trades(user_id)
    if not open_trades:
        return []

    user_data = get_user_data(user_id)
    if not user_data:
        return open_trades

    gate = GateIO(user_data)
    trades_with_pnl = []

    for trade in open_trades:
        try:
            current_price = gate.get_current_price(trade['symbol'])
            if current_price is not None:
                # Расчет PnL
                entry_price = trade['price']
                amount = trade['amount']

                if trade['side'] == 'buy':
                    pnl = (current_price - entry_price) * amount
                else:  # sell
                    pnl = (entry_price - current_price) * amount

                # Добавляем PnL к данным сделки
                trade_with_pnl = trade.copy()
                trade_with_pnl['pnl'] = pnl
                trade_with_pnl['current_price'] = current_price
                trades_with_pnl.append(trade_with_pnl)
            else:
                # Если не удалось получить цену, добавляем без PnL
                trade_with_pnl = trade.copy()
                trade_with_pnl['pnl'] = None
                trade_with_pnl['current_price'] = None
                trades_with_pnl.append(trade_with_pnl)
        except Exception as e:
            logger.error(f"Ошибка расчета PnL для {trade['symbol']}: {str(e)}")
            trade_with_pnl = trade.copy()
            trade_with_pnl['pnl'] = None
            trade_with_pnl['current_price'] = None
            trades_with_pnl.append(trade_with_pnl)

    return trades_with_pnl

def get_open_trades_by_symbol_and_side(user_id, symbol, side):
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''SELECT *
                              FROM trades
                              WHERE user_id = ?
                                AND symbol = ?
                                AND side = ?
                                AND status = 'OPEN' ''',
                           (user_id, symbol, side))
            trades = [dict(row) for row in cursor.fetchall()]
            logger.debug(f"Пользователь {user_id}: Найдено {len(trades)} открытых сделок для {symbol} ({side})")
            return trades if trades is not None else []
    except Exception as e:
        logger.error(f"Пользователь {user_id}: Ошибка получения сделок для {symbol} ({side}): {str(e)}")
        return []


def get_trades_by_symbol(user_id, symbol=None):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if symbol:
            cursor.execute('''
                           SELECT *
                           FROM trades
                           WHERE user_id = ?
                             AND symbol = ?
                             AND status = 'OPEN'
                           ''', (user_id, symbol))
        else:
            cursor.execute('''
                           SELECT *
                           FROM trades
                           WHERE user_id = ?
                             AND status = 'OPEN'
                           ''', (user_id,))
        return [dict(t) for t in cursor.fetchall()]


def get_trade_history(user_id, limit=10):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT *
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                       ORDER BY timestamp DESC LIMIT ?
                       ''', (user_id, limit))
        return [dict(t) for t in cursor.fetchall()]

def get_trade_by_id(trade_id):
    """Получает сделку по её ID, независимо от статуса"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT *
                       FROM trades
                       WHERE trade_id = ?
                       ''', (trade_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

def update_trade_status(trade_id, status, **kwargs):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        fields = ", ".join([f"{k} = ?" for k in kwargs.keys()])
        values = list(kwargs.values()) + [trade_id]
        query = f"UPDATE trades SET status = ?, {fields} WHERE trade_id = ?"
        cursor.execute(query, [status] + values)
        conn.commit()

        # Если статус "CLOSED", обнуляем трейлинг-стоп
        if status == "CLOSED":
            cursor.execute("UPDATE trades SET trailing_active = 0, trailing_stop_price = NULL WHERE trade_id = ?",
                           (trade_id,))
            conn.commit()

def check_daily_loss_limit(user_id):
    today = int(time.time() // 86400) * 86400
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT COUNT(*)
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                         AND timestamp >= ?
                         AND close_price IS NOT NULL
                         AND ((side = 'buy'
                         AND close_price
                           < price)
                          OR (side = 'sell'
                         AND close_price
                           > price))
                       ''', (user_id, today))
        loss_count = cursor.fetchone()[0]
        user_data = get_user_data(user_id)
        if not user_data:
            return False
        return loss_count >= user_data.get('daily_loss_limit', 3)


def check_max_open_trades(user_id):
    user_data = get_user_data(user_id)
    if not user_data:
        return False
    open_trades = get_open_trades(user_id)
    return len(open_trades) >= user_data.get('max_open_trades', 5)


def set_tp_config(user_id, timescale, stop_loss, trigger_profit, trailing_limit, profit_lock, pnl_based_trailing=False):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO tp_config (user_id, timescale, stop_loss_percentage, trigger_profit_percentage,
                                             trailing_percentage, profit_lock_percentage, pnl_based_trailing)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, timescale, stop_loss, trigger_profit, trailing_limit, profit_lock, pnl_based_trailing))
        conn.commit()
    logger.info(
        f"Пользователь {user_id}: Настройки для {timescale}: SL={stop_loss}%, TP={trigger_profit}%, TL={trailing_limit}%, PL={profit_lock}%, PnL-based={pnl_based_trailing}")


def get_tp_config(user_id, timescale):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT stop_loss_percentage,
                              trigger_profit_percentage,
                              trailing_percentage,
                              profit_lock_percentage,
                              pnl_based_trailing
                       FROM tp_config
                       WHERE user_id = ?
                         AND timescale = ?
                       ''', (user_id, timescale))
        result = cursor.fetchone()
    if result:
        return {
            'stop_loss_percentage': result[0],
            'trigger_profit_percentage': result[1],
            'trailing_percentage': result[2],
            'profit_lock_percentage': result[3],
            'pnl_based_trailing': result[4] if len(result) > 4 else False
        }
    user_data = get_user_data(user_id)
    if not user_data:
        return {
            'stop_loss_percentage': 3.0,
            'trigger_profit_percentage': 5.0,
            'trailing_percentage': 1.0,
            'profit_lock_percentage': 2.0,
            'pnl_based_trailing': False
        }
    return {
        'stop_loss_percentage': user_data.get('initial_stop_percentage', 3.0),
        'trigger_profit_percentage': user_data.get('trigger_profit_percentage', 5.0),
        'trailing_percentage': user_data.get('trailing_percentage', 1.0),
        'profit_lock_percentage': user_data.get('profit_lock_percentage', 2.0),
        'pnl_based_trailing': user_data.get('pnl_based_trailing', False)
    }


def get_all_tp_configs(user_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT timescale,
                              stop_loss_percentage,
                              trigger_profit_percentage,
                              trailing_percentage,
                              profit_lock_percentage
                       FROM tp_config
                       WHERE user_id = ?
                       ''', (user_id,))
        results = cursor.fetchall()
    configs = {}
    for row in results:
        configs[row[0]] = {
            'stop_loss_percentage': row[1],
            'trigger_profit_percentage': row[2],
            'trailing_percentage': row[3],
            'profit_lock_percentage': row[4]
        }
    return configs

# Класс GateIO
class GateIO:
    def __init__(self, user_data):
        self.user_id = user_data['user_id']
        self.user_data = user_data
        self.api_key = user_data['api_key'] or GATEIO_API_KEY
        self.api_secret = user_data['api_secret'] or GATEIO_API_SECRET
        self.leverage = user_data.get('leverage', 10.0)
        self.margin_mode = user_data.get('margin_mode', 'isolated')
        self.qty_percentage = min(user_data.get('qty_percentage', 5.0), 50.0)
        self.order_type = user_data.get('order_type', 'percentage')
        self.fixed_volume = user_data.get('fixed_volume', 100.0)
        self.trailing_interval = user_data.get('trailing_interval', 3.0)
        self.trailing_threads = {}
        api_url = "https://api.gateio.ws/api/v4" if user_data[
                                                        'account_type'] == 'real' else "https://api-testnet.gateapi.io/api/v4"
        configuration = gate_api.Configuration(
            host=api_url,
            key=self.api_key,
            secret=self.api_secret
        )
        api_client = gate_api.ApiClient(configuration)
        self.futures_api = gate_api.FuturesApi(api_client)
        # Инициализируем менеджер трейлинг-стопа
        self.trailing_stop_manager = TrailingStopManager(self)
        logger.info(
            f"Инициализация GateIO для пользователя {self.user_id}, account_type={user_data['account_type']}, api_url={api_url}")

    def place_order(self, symbol, side, timescale='1h', qty=None, usdt_amount=None, retries=3, delay=1.0):
        attempt = 0
        while attempt < retries:
            try:
                user_settings = get_user_data(self.user_id)
                if not user_settings:
                    logger.error(f"Пользователь {self.user_id}: Не удалось получить настройки")
                    bot.send_message(GROUP_CHAT_ID,
                                     f"Ошибка: Не удалось получить настройки пользователя {self.user_id}")
                    return None, None
                if not all([user_settings.get(key) for key in ['fixed_volume', 'leverage', 'order_type']]):
                    logger.error(f"Пользователь {self.user_id}: Отсутствуют обязательные настройки")
                    bot.send_message(GROUP_CHAT_ID, f"Ошибка: Настройте параметры через /settings")
                    return None, None

                logger.debug(
                    f"Пользователь {self.user_id}: Настройки - averaging_enabled={user_settings['averaging_enabled']}, averaging_pause={user_settings['averaging_pause']}")

                positions = self.futures_api.list_positions(settle='usdt')
                if positions is None:
                    logger.error(f"Пользователь {self.user_id}: Ошибка получения позиций для {symbol}")
                    bot.send_message(GROUP_CHAT_ID, f"Ошибка получения позиций для {symbol}")
                    return None, None
                existing_trade = None
                existing_qty = 0
                existing_entry_price = 0
                for pos in positions:
                    if pos.contract == symbol and pos.size != 0:
                        existing_side = 'buy' if pos.size > 0 else 'sell'
                        if side != existing_side:
                            close_qty = abs(pos.size)
                            close_order = gate_api.FuturesOrder(
                                contract=symbol,
                                size=-close_qty if existing_side == 'buy' else close_qty,
                                price="0",
                                tif='ioc'
                            )
                            response = self.futures_api.create_futures_order(settle='usdt', futures_order=close_order)
                            if response is None:
                                logger.error(f"Пользователь {self.user_id}: Ошибка создания ордера закрытия для {symbol}")
                                bot.send_message(GROUP_CHAT_ID, f"Ошибка закрытия позиции {existing_side} для {symbol}: не удалось создать ордер")
                                return None, None
                            order_id = response.id
                            actual_qty = abs(response.size)

                            existing_trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, existing_side)
                            if not existing_trades:
                                logger.error(
                                    f"Пользователь {self.user_id}: Сделка для {symbol} ({existing_side}) не найдена в базе")
                                bot.send_message(GROUP_CHAT_ID,
                                                 f"Ошибка: Сделка {existing_side} для {symbol} не найдена в базе")
                                return None, None
                            trade = existing_trades[0]
                            trade_id = trade['trade_id']
                            entry_price = trade['average_entry_price'] or trade['price']

                            current_price = self.get_current_price(symbol)
                            if not current_price:
                                logger.error(f"Пользователь {self.user_id}: Ошибка получения текущей цены для {symbol}")
                                current_price = float(response.fill_price) if response.fill_price else entry_price

                            total_profit = 0.0
                            total_fees = 0.0
                            try:
                                closed_positions = self.futures_api.list_position_close(settle='usdt', contract=symbol)
                                for closed_pos in closed_positions:
                                    if int(closed_pos.time) >= trade['timestamp'] and closed_pos.contract == symbol:
                                        if (closed_pos.side == 'long' and existing_side == 'buy') or (
                                                closed_pos.side == 'short' and existing_side == 'sell'):
                                            total_profit = float(closed_pos.pnl) if hasattr(closed_pos,
                                                                                            'pnl') and closed_pos.pnl is not None else 0.0
                                            total_fees = float(closed_pos.fee) if hasattr(closed_pos,
                                                                                          'fee') and closed_pos.fee is not None else 0.0
                                            break
                            except Exception as e:
                                logger.error(
                                    f"Пользователь {self.user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")

                            update_trade_status(trade_id, "CLOSED", close_price=current_price, close_order_id=order_id,
                                                close_reason="reverse_signal", pnl=total_profit, fees=total_fees)

                            profit_label = "Прибыль" if total_profit >= 0 else "Убыток"
                            # Получаем margin с биржи для правильного расчёта процента
                            margin = 0
                            try:
                                positions = self.futures_api.list_positions(settle='usdt')
                                for pos in positions:
                                    if pos.contract == symbol and (
                                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                                        margin = float(pos.margin)
                                        break
                            except:
                                pass
                            profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0
                            current_balance = self.get_balance_usdt() or 0.0

                            # Получаем баланс при открытии из базы данных
                            open_trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, existing_side)
                            balance_at_open = None
                            if open_trades:
                                trade = open_trades[0]
                                with get_db_connection() as conn:
                                    cursor = conn.cursor()
                                    cursor.execute("SELECT balance_at_open FROM trades WHERE trade_id = ?",
                                                   (trade['trade_id'],))
                                    row = cursor.fetchone()
                                    if row is not None and row[0] is not None:
                                        balance_at_open = row[0]

                            # Рассчитываем изменение баланса
                            balance_change = 0.0
                            # Изменение баланса равно PnL сделки
                            balance_change = total_profit
                            balance_change_percentage = (
                                        balance_change / balance_at_open * 100) if balance_at_open is not None and balance_at_open > 0 else 0.0

                            msg = (
                                f"✅ Закрыта {existing_side}: {symbol}\n"
                                f"📋 Причина: обратный сигнал\n"
                                f"💰 {profit_label}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%)\n"
                                f"💳 Баланс: {current_balance:.2f} USDT ({balance_change:+.2f} USDT, {balance_change_percentage:+.2f}%)"
                            )
                            with message_lock:
                                msg_key = (self.user_id, symbol, existing_side, 'close_reverse', int(time.time() // 60))
                                if msg_key not in sent_messages:
                                    bot.send_message(GROUP_CHAT_ID, msg)
                                    sent_messages.add(msg_key)
                            logger.info(
                                f"Пользователь {self.user_id}: Закрыта позиция {existing_side} для {symbol}, Прибыль={total_profit:.2f}, Комиссии={total_fees:.2f}")
                            # Добавляем паузу, чтобы не открывался обратный ордер сразу после закрытия
                            time.sleep(5)
                        elif side == existing_side:
                            existing_qty = abs(pos.size)
                            existing_entry_price = float(pos.entry_price)
                            existing_trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
                            existing_trade = existing_trades[0] if existing_trades else None
                            if not existing_trade:
                                price = self.get_current_price(symbol)
                                if not price:
                                    bot.send_message(GROUP_CHAT_ID,
                                                     f"Не удалось обработать позицию для {symbol}: не удалось получить цену")
                                    return None, None
                                config = get_tp_config(self.user_id, timescale)
                                stop_price = price * (
                                    1 - config['stop_loss_percentage'] / 100 if side == 'buy' else 1 + config[
                                        'stop_loss_percentage'] / 100)
                                trailing_price = price * (
                                    1 + config['trigger_profit_percentage'] / 100 if side == 'buy' else 1 - config[
                                        'trigger_profit_percentage'] / 100)
                                margin = float(pos.margin)
                                balance = self.get_balance_usdt()
                                trade_id = add_trade(
                                    self.user_id, symbol, side, price, existing_qty, int(time.time()), "OPEN",
                                    timescale,
                                    current_stop_price=stop_price, open_order_id=None,
                                    average_entry_price=existing_entry_price,
                                    highest_price=price if side == 'buy' else None,
                                    lowest_price=price if side == 'sell' else None,
                                    original_stop_price=stop_price,  # Устанавливаем original_stop_price
                                    trailing_stop_price=trailing_price,  # Устанавливаем trailing_stop_price
                                    margin=margin, balance_at_open=balance
                                )
                                logger.info(
                                    f"Пользователь {self.user_id}: Создана запись для существующей позиции {side} {symbol}, qty={existing_qty}, timestamp={int(time.time())}")
                                with message_lock:
                                    msg_key = (self.user_id, symbol, side, 'existing_position', int(time.time() // 60))
                                    if msg_key not in sent_messages:
                                        bot.send_message(GROUP_CHAT_ID,
                                                         f"Обнаружена новая позиция {side} для {symbol} на бирже\n"
                                                         f"Маржа: {margin:.2f} USDT,\n"
                                                         f"Цена: {price:.4f},\n"
                                                         f"Стоп: {stop_price:.4f},\n"
                                                         f"Трейлинг: {trailing_price:.4f},\n"
                                                         f"Объем: {existing_qty:.4f},\n"
                                                         f"Баланс: {balance:.2f} USDT" if balance is not None else "Баланс: Ошибка получения")
                                        sent_messages.add(msg_key)
                                existing_trade = {'trade_id': trade_id, 'timestamp': int(time.time()),
                                                  'amount': existing_qty}
                                thread_key = (self.user_id, symbol, side)
                                if thread_key not in self.trailing_threads or not self.trailing_threads[
                                    thread_key].is_alive():
                                    # Используем новый менеджер трейлинг-стопа
                                    self.trailing_stop_manager.start_monitoring(symbol, side)
                            else:
                                # Если запись уже существует, обновляем existing_trade
                                existing_trade = existing_trades[0] if existing_trades else None
                                if existing_trade:
                                    # Обновляем timestamp для правильной работы усреднения
                                    existing_trade = {'trade_id': existing_trade['trade_id'], 
                                                     'timestamp': existing_trade['timestamp'],
                                                     'amount': existing_qty}
                if check_daily_loss_limit(self.user_id):
                    logger.warning(f"Пользователь {self.user_id}: Достигнут дневной лимит убытков")
                    bot.send_message(GROUP_CHAT_ID, f"Достигнут дневной лимит убытков для {symbol} ({side})")
                    return None, None
                if check_max_open_trades(self.user_id) and not existing_trade:
                    logger.warning(f"Пользователь {self.user_id}: Достигнут лимит открытых позиций")
                    bot.send_message(GROUP_CHAT_ID, f"Достигнут лимит открытых позиций для {symbol} ({side})")
                    return None, None

                if existing_trade and user_settings['averaging_enabled']:
                    last_trade_time = existing_trade['timestamp']
                    current_time = int(time.time())
                    time_diff = current_time - last_trade_time
                    logger.debug(
                        f"Пользователь {self.user_id}: Усреднение для {symbol} ({side}), время с последнего ордера={time_diff}, пауза={user_settings['averaging_pause']}")
                    if time_diff < user_settings['averaging_pause']:
                        logger.info(f"Пользователь {self.user_id}: Пауза между усреднениями для {symbol} не истекла")
                        bot.send_message(GROUP_CHAT_ID, f"Пропуск: Пауза между усреднениями для {symbol} ({side})")
                        return None, None
                elif existing_trade and not user_settings['averaging_enabled']:
                    logger.warning(
                        f"Пользователь {self.user_id}: Позиция {side} для {symbol} уже открыта, усреднение отключено")
                    bot.send_message(GROUP_CHAT_ID, f"Позиция {side} для {symbol} уже открыта")
                    return None, None

                price = self.get_current_price(symbol)
                if not price:
                    bot.send_message(GROUP_CHAT_ID, f"Не удалось открыть {side} для {symbol}: не удалось получить цену")
                    return None, None

                if qty is None and usdt_amount is None:
                    qty = self.calculate_qty(symbol)
                    if not qty:
                        balance = self.get_balance_usdt()
                        bot.send_message(GROUP_CHAT_ID,
                                         f"Не удалось открыть {side} для {symbol}: Недостаточно средств для маржи ({user_settings['fixed_volume']} USDT)\n"
                                         f"Баланс: {balance:.2f} USDT" if balance is not None else "Баланс: Ошибка получения")
                        return None, None
                elif usdt_amount:
                    qty = usdt_amount / price
                    qty = Decimal(str(qty)).quantize(Decimal('0.0001'), rounding=ROUND_DOWN)
                    if float(qty) <= 0:
                        logger.error(f"Пользователь {self.user_id}: Количество {qty} меньше минимального")
                        bot.send_message(GROUP_CHAT_ID,
                                         f"Не удалось открыть {side} для {symbol}: Количество меньше минимального")
                        return None, None

                contract = self.futures_api.get_futures_contract(settle='usdt', contract=symbol)
                max_size = Decimal(str(getattr(contract, 'order_size_max', 1000000)))
                min_size = Decimal(str(getattr(contract, 'order_size_min', 1)))
                size_increment = Decimal(str(getattr(contract, 'order_size_increment', 1)))
                qty = Decimal(str(qty)).quantize(Decimal('0.0001'), rounding=ROUND_DOWN)
                qty = (qty // size_increment) * size_increment
                if qty < min_size or qty > max_size:
                    logger.error(
                        f"Пользователь {self.user_id}: qty {qty} для {symbol} вне диапазона [{min_size}, {max_size}]")
                    bot.send_message(GROUP_CHAT_ID,
                                     f"Не удалось открыть {side} для {symbol}: Размер ордера вне допустимого диапазона")
                    return None, None

                logger.info(
                    f"Пользователь {self.user_id}: Создание ордера: {side} {symbol}, qty={qty}, timeframe={timescale}")
                order = gate_api.FuturesOrder(
                    contract=symbol,
                    size=int(qty) if side == 'buy' else -int(qty),
                    price="0",
                    tif='ioc'
                )
                response = self.futures_api.create_futures_order(settle='usdt', futures_order=order)
                order_id = response.id
                actual_qty = abs(response.size)

                order_status = self.futures_api.get_futures_order(settle='usdt', order_id=order_id)
                if order_status.status not in ['filled', 'finished'] or order_status.size == 0:
                    logger.error(
                        f"Пользователь {self.user_id}: Ордер {order_id} для {symbol} не выполнен, статус: {order_status.status}")
                    bot.send_message(GROUP_CHAT_ID,
                                     f"Ошибка: Ордер {side} для {symbol} не выполнен, статус: {order_status.status}")
                    return None, None

                positions = self.futures_api.list_positions(settle='usdt')
                margin = 0
                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        margin = float(pos.margin)
                        break
                balance = self.get_balance_usdt()

                config = get_tp_config(self.user_id, timescale)
                stop_price = price * (1 - config['stop_loss_percentage'] / 100 if side == 'buy' else 1 + config[
                    'stop_loss_percentage'] / 100)
                trailing_price = price * (
                    1 + config['trigger_profit_percentage'] / 100 if side == 'buy' else 1 - config[
                        'trigger_profit_percentage'] / 100)

                if existing_trade and user_settings['averaging_enabled']:
                    total_qty = existing_qty + actual_qty
                    new_avg_price = ((existing_entry_price * existing_qty) + (price * actual_qty)) / total_qty
                    stop_price = new_avg_price * (
                        1 - config['stop_loss_percentage'] / 100 if side == 'buy' else 1 + config[
                            'stop_loss_percentage'] / 100)
                    trailing_price = new_avg_price * (
                        1 + config['trigger_profit_percentage'] / 100 if side == 'buy' else 1 - config[
                            'trigger_profit_percentage'] / 100)

                    update_trade_status(
                        existing_trade['trade_id'], "OPEN",
                        current_stop_price=stop_price,
                        average_entry_price=new_avg_price,
                        highest_price=price if side == 'buy' else None,
                        lowest_price=price if side == 'sell' else None,
                        original_stop_price=stop_price,  # Обновляем original_stop_price
                        trailing_stop_price=trailing_price  # Обновляем trailing_stop_price
                    )
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute('''
                                       UPDATE trades
                                       SET amount    = amount + ?,
                                           timestamp = ?
                                       WHERE trade_id = ?
                                       ''', (actual_qty, int(time.time()), existing_trade['trade_id']))
                        conn.commit()

                    with message_lock:
                        msg_key = (self.user_id, symbol, side, 'averaging', int(time.time() // 60))
                        if msg_key not in sent_messages:
                            bot.send_message(GROUP_CHAT_ID,
                                             f"Усреднена {side}: {symbol} ({timescale})\n"
                                             f"Маржа: {margin:.2f} USDT,\n"
                                             f"Новая средняя цена: {new_avg_price:.4f},\n"
                                             f"Стоп: {stop_price:.4f},\n"
                                             f"Трейлинг: {trailing_price:.4f},\n"
                                             f"Общий объем: {total_qty:.4f},\n"
                                             f"Баланс: {balance:.2f} USDT" if balance is not None else "Баланс: Ошибка получения")
                            sent_messages.add(msg_key)
                    logger.info(
                        f"Пользователь {self.user_id}: Усреднен ордер {side} для {symbol}, order_id={order_id}, qty={actual_qty}, новая средняя цена={new_avg_price}, новый timestamp={int(time.time())}")
                else:
                    trade_id = add_trade(
                        self.user_id, symbol, side, price, actual_qty, int(time.time()), "OPEN", timescale,
                        current_stop_price=stop_price, open_order_id=order_id, average_entry_price=price,
                        highest_price=price if side == 'buy' else None, lowest_price=price if side == 'sell' else None,
                        original_stop_price=stop_price,  # Устанавливаем original_stop_price
                        trailing_stop_price=trailing_price,  # Устанавливаем trailing_stop_price
                        margin=margin, balance_at_open=balance, signal_id=signal.get('signal_id') if 'signal' in locals() else None
                    )
                    with message_lock:
                        msg_key = (self.user_id, symbol, side, 'open_position', int(time.time() // 60))
                        if msg_key not in sent_messages:
                            bot.send_message(GROUP_CHAT_ID,
                                             f"Открыта {side}: {symbol} ({timescale})\n"
                                             f"Маржа: {margin:.2f} USDT,\n"
                                             f"Цена: {price:.4f},\n"
                                             f"Стоп: {stop_price:.4f},\n"
                                             f"Трейлинг: {trailing_price:.4f},\n"
                                             f"Объем: {actual_qty:.4f},\n"
                                             f"Баланс: {balance:.2f} USDT" if balance is not None else "Баланс: Ошибка получения")
                            sent_messages.add(msg_key)
                    logger.info(
                        f"Пользователь {self.user_id}: Ордер {side} для {symbol}, order_id={order_id}, qty={actual_qty}, margin={margin}")

                # Используем новый менеджер трейлинг-стопа
                self.trailing_stop_manager.start_monitoring(symbol, side)

                return order_id, actual_qty
            except GateApiException as ex:
                attempt += 1
                logger.error(
                    f"Пользователь {self.user_id}: Ошибка размещения ордера (попытка {attempt}): {ex.label}, {ex.message}")
                if attempt >= retries:
                    if ex.label == "INSUFFICIENT_AVAILABLE":
                        bot.send_message(GROUP_CHAT_ID,
                                         f"Не удалось открыть {side} для {symbol}: Недостаточно доступных средств, требуется {ex.message.split('margin ')[1].split(' while')[0]} USDT, доступно {ex.message.split('available ')[1]} USDT")
                    else:
                        bot.send_message(GROUP_CHAT_ID,
                                         f"Не удалось открыть {side} для {symbol}: {ex.label}, {ex.message}")
                    return None, None
                time.sleep(delay)
            except ApiException as e:
                attempt += 1
                logger.error(f"Пользователь {self.user_id}: Ошибка размещения ордера (попытка {attempt}): {str(e)}")
                if attempt >= retries:
                    bot.send_message(GROUP_CHAT_ID, f"Не удалось открыть {side} для {symbol}: {str(e)}")
                    return None, None
                time.sleep(delay)

    def handle_signal(self, signal):
        logger.info(f"Пользователь {self.user_id}: Обработка сигнала: {signal}")
        try:
            action = signal.get('action')
            symbol = signal.get('symbol')
            timeframe = signal.get('timeframe', '1h')
            signal_id = signal.get('signal_id')

            # Проверяем, не обрабатывали ли мы уже этот сигнал
            if signal_id:
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT trade_id FROM trades WHERE signal_id = ?", (signal_id,))
                    row = cursor.fetchone()
                    if row:
                        logger.info(f"Пользователь {self.user_id}: Сигнал {signal_id} уже был обработан ранее")
                        return
            
            # Проверяем, не обрабатывали ли мы такой же сигнал недавно (защита от дубликатов)
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT timestamp FROM trades 
                    WHERE user_id = ? AND symbol = ? AND side = ? 
                    ORDER BY timestamp DESC LIMIT 1
                """, (self.user_id, symbol, action))
                row = cursor.fetchone()
                if row and (time.time() - row[0]) < 30:  # Менее 30 секунд
                    logger.info(f"Пользователь {self.user_id}: Такой же сигнал для {symbol} ({action}) уже обрабатывался менее 30 секунд назад")
                    return

            if not action or not symbol:
                logger.error(f"Пользователь {self.user_id}: Некорректный сигнал: {signal}")
                return

            if not self.user_data.get('is_trading', 0):
                logger.info(f"Пользователь {self.user_id}: Торговля отключена, сигнал {signal} пропущен")
                bot.send_message(GROUP_CHAT_ID,
                                 f"Сигнал не обработан: торговля не активна для пользователя {self.user_id}")
                return

            if timeframe not in ['1m', '3m', '5m', '15m', '30m', '1h', '4h', '12h', '1d', '1w']:
                logger.info(f"Пользователь {self.user_id}: Таймфрейм {timeframe} не поддерживается, сигнал пропущен")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: таймфрейм {timeframe} не поддерживается")
                return

            if not self.validate_symbol(symbol):
                logger.error(f"Пользователь {self.user_id}: Символ {symbol} не поддерживается")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: символ {symbol} не поддерживается")
                return

            # Проверяем, не была ли недавно закрыта противоположная позиция по стоп-лоссу или трейлинг-стопу
            opposite_action = 'sell' if action == 'buy' else 'buy'
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT close_reason, timestamp 
                    FROM trades 
                    WHERE user_id = ? AND symbol = ? AND side = ? AND status = 'CLOSED'
                    ORDER BY timestamp DESC 
                    LIMIT 1
                """, (self.user_id, symbol, opposite_action))
                row = cursor.fetchone()
                if row and row[0] in ["stop_loss", "trailing_stop", "reverse_signal"] and (time.time() - row[1]) < 120:  # Менее 2 минут
                    logger.info(
                        f"Пользователь {self.user_id}: Противоположная позиция {symbol} ({opposite_action}) была закрыта по {row[0]} менее 2 минут назад, сигнал пропущен")
                    bot.send_message(GROUP_CHAT_ID,
                                     f"Сигнал не обработан: противоположная позиция {symbol} ({opposite_action}) была закрыта по {row[0]} менее 2 минут назад")
                    return

            open_trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, action)
            if open_trades and not self.user_data.get('averaging_enabled', 0):
                logger.info(
                    f"Пользователь {self.user_id}: Позиция для {symbol} ({action}) уже открыта, сигнал пропущен")
                bot.send_message(GROUP_CHAT_ID,
                                 f"Сигнал не обработан: позиция для {symbol} ({action}) уже открыта, усреднение отключено")
                return

            balance = self.get_balance_usdt()
            if not balance or balance < 10:
                logger.error(f"Пользователь {self.user_id}: Недостаточный баланс ({balance:.2f} USDT), сигнал пропущен")
                bot.send_message(GROUP_CHAT_ID, f"Ошибка: Недостаточный баланс ({balance:.2f} USDT) для {symbol}")
                return

            qty = self.calculate_qty(symbol)
            if not qty:
                logger.error(f"Пользователь {self.user_id}: Не удалось рассчитать qty для {symbol}")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: не удалось рассчитать объем для {symbol}")
                return

            logger.info(f"Пользователь {self.user_id}: Подготовка к открытию позиции: {action} {symbol}, qty={qty:.4f}")
            order_id, actual_qty = self.place_order(symbol, action, timeframe, qty)
            if order_id:
                logger.info(
                    f"Пользователь {self.user_id}: Позиция {action} для {symbol} открыта, order_id={order_id}, qty={actual_qty:.4f}")
            else:
                logger.error(f"Пользователь {self.user_id}: Не удалось открыть позицию для {symbol}")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: не удалось открыть позицию для {symbol}")
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка обработки сигнала {signal}: {str(e)}")
            bot.send_message(GROUP_CHAT_ID, f"Ошибка обработки сигнала {symbol}: {str(e)}")

    def sync_positions(self):
        try:
            positions = self.futures_api.list_positions(settle='usdt')
            open_trades = get_open_trades(self.user_id)

            # Проверяем позиции на бирже
            for trade in open_trades:
                symbol = trade['symbol']
                side = trade['side']
                trade_id = trade['trade_id']
                found = False
                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        found = True
                        # Обновляем данные о позиции
                        current_price = self.get_current_price(symbol)
                        if current_price:
                            update_trade_status(trade_id, "OPEN", current_stop_price=trade['current_stop_price'],
                                                average_entry_price=float(pos.entry_price),
                                                highest_price=max(trade['highest_price'] or current_price,
                                                                  current_price) if side == 'buy' else None,
                                                lowest_price=min(trade['lowest_price'] or current_price,
                                                                 current_price) if side == 'sell' else None)
                        break
                if not found:
                    # ДОБАВЛЕНО: Проверка статуса сделки перед закрытием
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT status FROM trades WHERE trade_id = ?", (trade_id,))
                        row = cursor.fetchone()
                        if row and row[0] == "CLOSED":
                            continue  # Уже закрыта другим процессом, пропускаем
                    # Позиция закрыта на бирже
                    current_price = self.get_current_price(symbol)
                    if not current_price:
                        logger.error(f"Пользователь {self.user_id}: Не удалось получить цену для {symbol}")
                        current_price = trade['average_entry_price'] or trade['price']
                    # Получаем данные сделки
                    entry_price = trade['average_entry_price'] or trade['price']
                    amount = trade['amount']
                    logger.debug(f"Пользователь {self.user_id}: Закрыта на бирже {symbol}, side={side}, "
                                 f"entry_price={entry_price}, amount={amount}, current_price={current_price}")
                    # Получаем прибыль и комиссии через API
                    total_profit = 0.0
                    total_fees = 0.0
                    try:
                        closed_positions = self.futures_api.list_position_close(settle='usdt', contract=symbol)
                        for closed_pos in closed_positions:
                            if int(closed_pos.time) >= trade['timestamp'] and closed_pos.contract == symbol:
                                if (closed_pos.side == 'long' and side == 'buy') or (
                                        closed_pos.side == 'short' and side == 'sell'):
                                    total_profit = float(closed_pos.pnl) if hasattr(closed_pos,
                                                                                    'pnl') and closed_pos.pnl is not None else 0.0
                                    total_fees = float(closed_pos.fee) if hasattr(closed_pos,
                                                                                  'fee') and closed_pos.fee is not None else 0.0
                                    logger.debug(
                                        f"Пользователь {self.user_id}: API Profit={total_profit}, Fee={total_fees}, close_price={current_price}")
                                    break
                    except Exception as e:
                        logger.error(f"Пользователь {self.user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")
                    # Рассчитываем процент прибыли по margin
                    margin = 0
                    try:
                        positions = self.futures_api.list_positions(settle='usdt')
                        for pos in positions:
                            if pos.contract == symbol and (
                                    (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                                margin = float(pos.margin)
                                break
                    except:
                        pass
                    profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0
                    balance = self.get_balance_usdt() or 0.0

                    # Получаем баланс при открытии из базы данных
                    balance_at_open = None
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT balance_at_open FROM trades WHERE trade_id = ?", (trade_id,))
                        row_balance = cursor.fetchone()
                        if row_balance is not None and row_balance[0] is not None:
                            balance_at_open = row_balance[0]

                    # Изменение баланса равно PnL сделки
                    balance_change = total_profit
                    balance_change_percentage = (
                                balance_change / balance_at_open * 100) if balance_at_open is not None and balance_at_open > 0 else 0.0

                    # Проверяем, не была ли позиция уже закрыта системой (стоп-лосс, трейлинг и т.д.)
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT close_reason FROM trades WHERE trade_id = ?", (trade_id,))
                        row = cursor.fetchone()
                        logger.debug(f"Пользователь {self.user_id}: Проверка причины закрытия для {symbol} ({side}), trade_id={trade_id}, row={row}")
                        if row and row[0] and row[0] != "closed_on_exchange":
                            # Позиция уже была закрыта системой, не отправляем сообщение о закрытии на бирже
                            logger.info(f"Пользователь {self.user_id}: Позиция {side} для {symbol} уже была закрыта системой ({row[0]}), не отправляем сообщение о закрытии на бирже")
                            continue
                        elif row and (row[0] is None or row[0] == "closed_on_exchange"):
                            # Если причина закрытия None или уже "closed_on_exchange", это может указывать на проблему
                            logger.warning(f"Пользователь {self.user_id}: Позиция {side} для {symbol} имеет некорректную причину закрытия: {row[0]}")
                    
                    update_trade_status(trade_id, "CLOSED", close_price=current_price, close_order_id=None,
                                        close_reason="closed_on_exchange", pnl=total_profit, fees=total_fees)
                    logger.debug(f"Пользователь {self.user_id}: Обновлен статус сделки {trade_id} на closed_on_exchange")
                    # Проверяем еще раз, не была ли позиция уже закрыта системой
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT close_reason FROM trades WHERE trade_id = ?", (trade_id,))
                        row = cursor.fetchone()
                        logger.debug(f"Пользователь {self.user_id}: Проверка причины закрытия после обновления для {symbol} ({side}), trade_id={trade_id}, row={row}")
                        if row and row[0] and row[0] != "closed_on_exchange":
                            # Позиция уже была закрыта системой, не отправляем сообщение
                            logger.info(f"Пользователь {self.user_id}: Позиция {side} для {symbol} уже была закрыта системой, не отправляем сообщение")
                        else:
                            profit_label = "Прибыль" if total_profit >= 0 else "Убыток"
                            # Рассчитываем процент прибыли/убытка от баланса
                            balance_percentage = (total_profit / balance * 100) if balance and balance > 0 else 0.0
                            msg = (f"✅ Закрыта {side}: {symbol}\n"
                                   f"📋 Причина: закрыто на бирже\n"
                                   f"💰 {profit_label}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%, {balance_percentage:+.2f}% от баланса)\n"
                                   f"💳 Баланс: {balance:.2f} USDT ({balance_change:+.2f} USDT, {balance_change_percentage:+.2f}%)")
                            with message_lock:
                                msg_key = (self.user_id, symbol, side, 'close_exchange', int(time.time() // 60))
                                if msg_key not in sent_messages:
                                    bot.send_message(GROUP_CHAT_ID, msg)
                                    sent_messages.add(msg_key)
                    logger.info(f"Пользователь {self.user_id}: Позиция {side} для {symbol} закрыта на бирже, "
                                f"Прибыль={total_profit:.2f}, Комиссии={total_fees:.2f}")

            # Проверяем позиции на бирже, которых нет в базе
            for pos in positions:
                if pos.size != 0:
                    symbol = pos.contract
                    side = 'buy' if pos.size > 0 else 'sell'
                    existing_trades = get_open_trades_by_symbol_and_side(self.user_id, symbol, side)
                    # Проверяем, есть ли недавно закрытые позиции для этого символа
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("""
                            SELECT status, close_reason, timestamp 
                            FROM trades 
                            WHERE user_id = ? AND symbol = ? AND side = ? 
                            ORDER BY timestamp DESC 
                            LIMIT 1
                        """, (self.user_id, symbol, side))
                        row = cursor.fetchone()
                        if row and row[0] == "CLOSED" and (time.time() - row[2]) < 60:  # Закрыта менее минуты назад
                            logger.info(
                                f"Пользователь {self.user_id}: Позиция {symbol} ({side}) недавно закрыта, пропускаем")
                            continue

                    if not existing_trades:
                        contract = self.futures_api.get_futures_contract(settle='usdt', contract=symbol)
                        quanto_multiplier = float(contract.quanto_multiplier)
                        # pos.size уже в контрактах, переводим в монеты
                        amount = abs(float(pos.size)) * quanto_multiplier
                        current_price = self.get_current_price(symbol)
                        if not current_price:
                            logger.error(f"Пользователь {self.user_id}: Не удалось получить цену для {symbol}")
                            continue
                        config = get_tp_config(self.user_id, '1h')
                        stop_price = current_price * (
                            1 - config['stop_loss_percentage'] / 100 if side == 'buy' else 1 + config[
                                'stop_loss_percentage'] / 100)
                        trailing_price = current_price * (
                            1 + config['trigger_profit_percentage'] / 100 if side == 'buy' else 1 - config[
                                'trigger_profit_percentage'] / 100)
                        margin = float(pos.margin)
                        balance = self.get_balance_usdt()
                        trade_id = add_trade(
                            self.user_id, symbol, side, float(pos.entry_price), amount,
                            int(time.time()), "OPEN", '1h', current_stop_price=stop_price,
                            average_entry_price=float(pos.entry_price),
                            highest_price=current_price if side == 'buy' else None,
                            lowest_price=current_price if side == 'sell' else None,
                            margin=margin, signal_id=None
                        )
                        with message_lock:
                            msg_key = (self.user_id, symbol, side, 'new_position', int(time.time() // 60))
                            if msg_key not in sent_messages:
                                bot.send_message(GROUP_CHAT_ID,
                                                 f"🔍 Обнаружена новая позиция {side} для {symbol} на бирже\n"
                                                 f"💰 Маржа: {margin:.2f} USDT\n"
                                                 f"📊 Цена: {current_price:.4f}\n"
                                                 f"🛑 Стоп: {stop_price:.4f}\n"
                                                 f"📈 Трейлинг: {trailing_price:.4f}\n"
                                                 f"📦 Объем: {amount:.4f}\n"
                                                 f"💳 Баланс: {balance:.2f} USDT" if balance is not None else "💳 Баланс: Ошибка получения")
                                sent_messages.add(msg_key)
                        logger.info(
                            f"Пользователь {self.user_id}: Создана запись для {symbol} ({side}), amount={amount}")
                        thread_key = (self.user_id, symbol, side)
                        if thread_key not in self.trailing_threads or not self.trailing_threads[thread_key].is_alive():
                            # Проверяем, что позиция ещё открыта перед запуском мониторинга
                            with get_db_connection() as conn:
                                cursor = conn.cursor()
                                cursor.execute("SELECT status FROM trades WHERE trade_id = ?", (trade_id,))
                                row = cursor.fetchone()
                                if row and row[0] == "OPEN":
                                    # Используем новый менеджер трейлинг-стопа
                                    self.trailing_stop_manager.start_monitoring(symbol, side)
                                else:
                                    logger.info(
                                        f"Пользователь {self.user_id}: Позиция {symbol} ({side}) уже закрыта, трейлинг не запускается")
            # Добавляем разделитель для лучшей читаемости логов
            separator = "═" * 80
            logger.info(f"\n{separator}\n"
                        f"🔄 Синхронизация позиций завершена для пользователя {self.user_id}\n"
                        f"📊 Найдено {len(open_trades)} открытых позиций\n"
                        f"🎯 Позиции на бирже: {len([p for p in positions if p.size != 0])}\n"
                        f"{separator}")
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка синхронизации позиций: {str(e)}")

    def check_permissions(self):
        try:
            balance = self.futures_api.list_futures_accounts(settle='usdt')
            logger.info(f"Пользователь {self.user_id}: API ключи валидны")
            return True
        except GateApiException as ex:
            logger.error(f"Пользователь {self.user_id}: Ошибка проверки API: {ex.label}, {ex.message}")
            return False
        except ApiException as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка проверки API: {str(e)}")
            return False

    def get_balance_usdt(self):
        try:
            account = self.futures_api.list_futures_accounts(settle='usdt')
            balance = float(account.total)
            logger.debug(f"Пользователь {self.user_id}: Баланс {balance:.2f} USDT")
            return balance
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка получения баланса: {str(e)}")
            return None

    def get_current_price(self, symbol, retries=3, delay=1.0):
        for attempt in range(retries):
            try:
                ticker = self.futures_api.list_futures_tickers(settle='usdt', contract=symbol)
                price = float(ticker[0].last)
                if price > 0:
                    logger.debug(f"Пользователь {self.user_id}: Цена {symbol}: {price}")
                    return price
                logger.error(f"Пользователь {self.user_id}: Некорректная цена 0 для {symbol}")
            except Exception as e:
                logger.error(f"Пользователь {self.user_id}: Ошибка получения цены для {symbol}: {str(e)}")
                if attempt < retries - 1:
                    time.sleep(delay)
        return None

    def validate_symbol(self, symbol):
        try:
            self.futures_api.get_futures_contract(settle='usdt', contract=symbol)
            return True
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Символ {symbol} не поддерживается: {str(e)}")
            return False

    def calculate_qty(self, symbol):
        try:
            user_settings = get_user_data(self.user_id)
            if not user_settings:
                logger.error(f"Пользователь {self.user_id}: Не удалось получить настройки")
                return None

            order_type = user_settings.get('order_type', 'fixed')
            leverage = Decimal(str(user_settings.get('leverage', 10)))

            # Определяем размер позиции в зависимости от типа ордера
            if order_type == 'percentage':
                # Получаем текущий баланс
                balance = self.get_balance_usdt()
                if not balance:
                    logger.error(f"Пользователь {self.user_id}: Не удалось получить баланс")
                    return None

                # Рассчитываем размер позиции как процент от баланса
                qty_percentage = Decimal(str(user_settings.get('qty_percentage', 5.0)))
                position_size_usdt = Decimal(str(balance)) * (qty_percentage / Decimal('100'))
                logger.debug(
                    f"Пользователь {self.user_id}: Баланс: {balance:.2f} USDT, процент: {qty_percentage}%, размер позиции: {position_size_usdt:.2f} USDT")
            else:
                # Используем фиксированный объем
                position_size_usdt = Decimal(str(user_settings.get('fixed_volume', 10)))
                logger.debug(
                    f"Пользователь {self.user_id}: Фиксированный размер позиции: {position_size_usdt:.2f} USDT")

            price = self.get_current_price(symbol)
            if not price:
                logger.error(f"Пользователь {self.user_id}: Не удалось получить цену для {symbol}")
                return None

            nominal_value = position_size_usdt * leverage
            contract = self.futures_api.get_futures_contract(settle='usdt', contract=symbol)
            quanto_multiplier = Decimal(str(contract.quanto_multiplier))  # Используем quanto_multiplier
            min_size = Decimal(str(getattr(contract, 'order_size_min', 1)))  # Минимальный размер ордера
            size_increment = Decimal(str(getattr(contract, 'order_size_increment', 1)))  # Шаг размера
            max_size = Decimal(str(getattr(contract, 'order_size_max', 1000000)))  # Максимальный размер

            qty = nominal_value / (Decimal(str(price)) * quanto_multiplier)
            qty = qty.quantize(Decimal('0.0001'), rounding=ROUND_DOWN)

            if qty < min_size:
                logger.error(
                    f"Пользователь {self.user_id}: Рассчитанное qty {qty} для {symbol} меньше минимального {min_size}")
                return None
            if qty > max_size:
                logger.error(
                    f"Пользователь {self.user_id}: Рассчитанное qty {qty} для {symbol} превышает максимум {max_size}")
                return None

            qty = (qty // size_increment) * size_increment
            qty = qty.quantize(Decimal('0.0001'), rounding=ROUND_DOWN)

            if qty <= 0:
                logger.error(f"Пользователь {self.user_id}: Рассчитанное qty {qty} для {symbol} некорректно")
                return None

            logger.debug(
                f"Пользователь {self.user_id}: Рассчитано qty для {symbol}: {qty}, размер позиции: {position_size_usdt} USDT, плечо: {leverage}x, тип: {order_type}")
            return qty
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка расчета qty для {symbol}: {str(e)}")
            return None

    def cleanup_trailing_threads(self):
        self.trailing_threads = {k: v for k, v in self.trailing_threads.items() if v.is_alive()}

    # Удалена функция monitor_trailing_stop, теперь используется TrailingStopManager
    # Также удалена дублирующаяся функция close_position_enhanced
    # Также удален остаточный код от старой функции monitor_trailing_stop
    # Вся логика трейлинг-стопа теперь находится в trailing_stop_manager.py

    def close_position_enhanced(self, symbol, side, qty, partial_qty=None, reason="manual", max_retries=3):
        """Улучшенное закрытие позиции с повторными попытками и проверкой статуса."""
        for attempt in range(max_retries):
            try:
                logger.info(f"🔄 [{reason.upper()}] Попытка {attempt + 1}/{max_retries} закрытия {symbol} ({side})")

                # Получаем текущую позицию
                positions = self.futures_api.list_positions(settle='usdt')
                position_size = 0
                entry_price = 0
                current_pnl = 0

                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        position_size = abs(pos.size)
                        entry_price = float(pos.entry_price)
                        current_pnl = float(pos.unrealised_pnl)
                        break

                if position_size == 0:
                    logger.info(f"✅ Позиция {symbol} ({side}) уже закрыта")
                    return None, None

                logger.info(
                    f"📊 Позиция {symbol} ({side}): размер={position_size:.4f}, цена входа={entry_price:.4f}, PnL={current_pnl:.2f} USDT")

                # Получаем параметры контракта
                contract = self.futures_api.get_futures_contract(settle='usdt', contract=symbol)
                quanto_multiplier = Decimal(str(contract.quanto_multiplier))
                min_size = Decimal(str(getattr(contract, 'order_size_min', 1)))
                max_size = Decimal(str(getattr(contract, 'order_size_max', 1000000)))
                size_increment = Decimal(str(getattr(contract, 'order_size_increment', 1)))

                # Если указан partial_qty, используем его, иначе закрываем всю позицию
                if partial_qty is not None:
                    qty_to_close = partial_qty
                else:
                    # Закрываем всю позицию - используем реальный размер позиции
                    # position_size уже в контрактах, переводим в монеты
                    qty_to_close = position_size * quanto_multiplier

                # Преобразуем qty из монет в контракты
                qty_in_coins = Decimal(str(qty_to_close))
                qty_in_contracts = qty_in_coins / quanto_multiplier

                # Проверяем диапазон
                if qty_in_contracts < min_size or qty_in_contracts > max_size:
                    logger.error(
                        f"❌ qty {qty_in_coins} ({qty_in_contracts} контрактов) вне диапазона [{min_size}, {max_size}]")
                    return None, None

                # Округляем до шага
                qty_in_contracts = (qty_in_contracts // size_increment) * size_increment
                qty_in_contracts = qty_in_contracts.quantize(Decimal('1'), rounding=ROUND_DOWN)
                if qty_in_contracts <= 0:
                    logger.error(f"❌ Некорректный qty {qty_in_contracts} для {symbol}")
                    return None, None

                logger.info(f"📝 Создание ордера: {symbol} ({side}), размер={qty_in_contracts:.4f} контрактов")

                # Создаём ордер на закрытие
                close_side = 'sell' if side == 'buy' else 'buy'
                order = gate_api.FuturesOrder(
                    contract=symbol,
                    size=-int(qty_in_contracts) if side == 'buy' else int(qty_in_contracts),
                    price="0",
                    tif='ioc'
                )

                response = self.futures_api.create_futures_order(settle='usdt', futures_order=order)
                order_id = response.id
                actual_qty = Decimal(str(abs(response.size))) * quanto_multiplier

                logger.info(f"📋 Ордер создан: ID={order_id}, размер={actual_qty:.4f}")

                # Проверяем статус ордера с повторными попытками
                order_status = None
                for status_attempt in range(5):  # Увеличиваем количество попыток
                    try:
                        order_status = self.futures_api.get_futures_order(settle='usdt', order_id=order_id)
                        logger.debug(f"📊 Статус ордера {order_id}: {order_status.status}")

                        if order_status.status in ['filled', 'finished'] and order_status.size != 0:
                            logger.info(f"✅ Ордер {order_id} выполнен успешно")
                            break
                        elif order_status.status in ['cancelled', 'expired']:
                            logger.warning(f"❌ Ордер {order_id} отменен/истек: {order_status.status}")
                            break

                        time.sleep(0.5)
                    except Exception as e:
                        logger.warning(f"⚠️ Ошибка получения статуса ордера {order_id}: {str(e)}")
                        if status_attempt < 4:
                            time.sleep(1)

                if order_status and order_status.status in ['filled', 'finished'] and order_status.size != 0:
                    # Дополнительная проверка - убеждаемся что позиция действительно закрыта
                    time.sleep(2)  # Увеличиваем время ожидания
                    positions_after = self.futures_api.list_positions(settle='usdt')
                    position_still_open = False
                    remaining_size = 0

                    for pos in positions_after:
                        if pos.contract == symbol and (
                                (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                            remaining_size = abs(pos.size)
                            if remaining_size > 0.001:  # Если осталось больше 0.001 контракта
                                position_still_open = True
                                logger.warning(
                                    f"⚠️ Позиция {symbol} ({side}) закрыта частично, осталось: {remaining_size}")
                                break

                    if not position_still_open:
                        logger.info(f"✅ Позиция {symbol} ({side}) успешно закрыта полностью")
                        # Добавляем паузу, чтобы не открывался обратный ордер сразу после закрытия
                        time.sleep(5)
                    return order_id, actual_qty
                elif order_status and order_status.status not in ['filled', 'finished']:
                    logger.warning(
                        f"❌ Ордер {order_id} для {symbol} не выполнен, статус: {order_status.status if order_status else 'unknown'}")
                    if attempt < max_retries - 1:
                        time.sleep(3)  # Увеличиваем время ожидания
                        continue
                    else:
                        return None, None
                else:
                    logger.warning(
                        f"❌ Ордер {order_id} для {symbol} не выполнен, статус: {order_status.status if order_status else 'unknown'}")
                    if attempt < max_retries - 1:
                        time.sleep(3)  # Увеличиваем время ожидания
                        continue
                    else:
                        return None, None

            except Exception as e:
                logger.error(f"❌ Ошибка при попытке {attempt + 1} закрытия {symbol}: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(3)
                else:
                    return None, None

        return None, None

    def calculate_adaptive_interval(self, symbol, base_interval, price_history=None):
        """Рассчитывает адаптивный интервал трейлинга на основе волатильности."""
        try:
            # Получаем историю цен для расчета волатильности
            if price_history is None:
                # Получаем последние цены для расчета волатильности
                try:
                    # Используем простой метод - получаем несколько последних цен
                    prices = []
                    for _ in range(5):
                        price = self.get_current_price(symbol)
                        if price:
                            prices.append(price)
                        time.sleep(0.1)

                    if len(prices) < 3:
                        return base_interval

                    # Рассчитываем волатильность как стандартное отклонение
                    mean_price = sum(prices) / len(prices)
                    variance = sum((p - mean_price) ** 2 for p in prices) / len(prices)
                    volatility = variance ** 0.5

                    # Нормализуем волатильность относительно цены
                    normalized_volatility = volatility / mean_price

                    # Адаптируем интервал на основе волатильности
                    if normalized_volatility > 0.01:  # Высокая волатильность (>1%)
                        return max(0.5, base_interval * 0.3)  # Быстрый режим
                    elif normalized_volatility > 0.005:  # Средняя волатильность (0.5-1%)
                        return base_interval * 0.7  # Умеренно быстрый
                    elif normalized_volatility < 0.001:  # Низкая волатильность (<0.1%)
                        return base_interval * 1.5  # Медленный режим
                    else:
                        return base_interval  # Обычный режим

                except Exception as e:
                    logger.warning(f"Пользователь {self.user_id}: Ошибка расчета волатильности для {symbol}: {str(e)}")
                    return base_interval
            else:
                # Используем переданную историю цен
                if len(price_history) < 3:
                    return base_interval

                mean_price = sum(price_history) / len(price_history)
                variance = sum((p - mean_price) ** 2 for p in price_history) / len(price_history)
                volatility = variance ** 0.5
                normalized_volatility = volatility / mean_price

                if normalized_volatility > 0.01:
                    return max(0.5, base_interval * 0.3)
                elif normalized_volatility > 0.005:
                    return base_interval * 0.7
                elif normalized_volatility < 0.001:
                    return base_interval * 1.5
                else:
                    return base_interval

        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка расчета адаптивного интервала для {symbol}: {str(e)}")
            return base_interval

    def calculate_current_pnl(self, symbol, side, entry_price, current_price, amount):
        """Рассчитывает текущий PnL позиции."""
        try:
            if side == 'buy':
                # Для длинной позиции: PnL = (текущая_цена - цена_входа) * количество
                pnl = (current_price - entry_price) * amount
            else:
                # Для короткой позиции: PnL = (цена_входа - текущая_цена) * количество
                pnl = (entry_price - current_price) * amount

            # Рассчитываем процент PnL от стоимости позиции
            position_value = entry_price * amount
            pnl_percentage = (pnl / position_value * 100) if position_value > 0 else 0.0

            return pnl, pnl_percentage
        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка расчета PnL для {symbol}: {str(e)}")
            return 0.0, 0.0

    def calculate_trailing_stop_from_pnl(self, symbol, side, entry_price, current_price, amount,
                                         trailing_percentage, highest_pnl=None, lowest_pnl=None, margin=None):
        """Рассчитывает трейлинг стоп на основе PnL по margin."""
        try:
            current_pnl = 0.0
            pnl_percentage = 0.0
            try:
                positions = self.futures_api.list_positions(settle='usdt')
                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        current_pnl = float(pos.unrealised_pnl)
                        if margin is None:
                            margin = float(pos.margin)
                        pnl_percentage = (current_pnl / margin * 100) if margin else 0.0
                        break
            except Exception as e:
                logger.error(f"Пользователь {self.user_id}: Ошибка получения PnL с биржи для {symbol}: {str(e)}")
                current_pnl, _ = self.calculate_current_pnl(symbol, side, entry_price, current_price, amount)
                pnl_percentage = (current_pnl / margin * 100) if margin else 0.0

            if current_pnl <= 0:
                return None, highest_pnl, lowest_pnl

            if highest_pnl is None or current_pnl > highest_pnl:
                highest_pnl = current_pnl
            if lowest_pnl is None or current_pnl < lowest_pnl:
                lowest_pnl = current_pnl

            if side == 'buy':
                stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
                stop_price = entry_price + (stop_pnl / amount)
            else:
                stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
                stop_price = entry_price - (stop_pnl / amount)

            if current_pnl <= stop_pnl:
                logger.debug(
                    f"⚠️ {symbol} ({side}) - Текущий PnL ({current_pnl:.2f}) <= стоп PnL ({stop_pnl:.2f}), стоп не обновляется")
                return None, highest_pnl, lowest_pnl

            highest_pnl_str = f"{highest_pnl:.2f}" if highest_pnl is not None else "None"
            lowest_pnl_str = f"{lowest_pnl:.2f}" if lowest_pnl is not None else "None"
            stop_pnl_str = f"{stop_pnl:.2f}" if 'stop_pnl' in locals() else "None"
            stop_price_str = f"{stop_price:.4f}" if 'stop_price' in locals() and stop_price is not None else "None"
            pnl_emoji = "🟢" if current_pnl >= 0 else "🔴"
            side_emoji = "📈" if side == 'buy' else "📉"

            # Форматируем процент с правильным знаком для логов
            pnl_percentage_sign = "+" if pnl_percentage >= 0 else ""
            logger.debug(f"📊 {side_emoji} {symbol} ({side.upper()}) - Расчет трейлинг-стопа\n"
                         f"💰 Текущий PnL: {pnl_emoji} {current_pnl:+.2f} USDT ({pnl_percentage_sign}{pnl_percentage:.2f}%)\n"
                         f"📈 Макс PnL: {highest_pnl_str} | 📉 Мин PnL: {lowest_pnl_str}\n"
                         f"🎯 Стоп PnL: {stop_pnl_str} | 🎯 Стоп цена: {stop_price_str}")

            return stop_price, highest_pnl, lowest_pnl

        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка расчета трейлинг стопа от PnL для {symbol}: {str(e)}")
            return None, highest_pnl, lowest_pnl

    def check_pnl_based_activation(self, symbol, side, entry_price, current_price, amount, trigger_profit_percentage,
                                   margin=None):
        """Проверяет активацию трейлинга на основе PnL по margin."""
        try:
            current_pnl = 0.0
            pnl_percentage = 0.0
            try:
                positions = self.futures_api.list_positions(settle='usdt')
                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        current_pnl = float(pos.unrealised_pnl)
                        if margin is None:
                            margin = float(pos.margin)
                        pnl_percentage = (current_pnl / margin * 100) if margin else 0.0
                        break
            except Exception as e:
                logger.error(f"Пользователь {self.user_id}: Ошибка получения PnL с биржи для {symbol}: {str(e)}")
                current_pnl, _ = self.calculate_current_pnl(symbol, side, entry_price, current_price, amount)
                pnl_percentage = (current_pnl / margin * 100) if margin else 0.0

            if pnl_percentage >= trigger_profit_percentage:
                pnl_emoji = "🟢" if current_pnl >= 0 else "🔴"
                logger.info(f"🟢 {symbol} ({side}) - Активация трейлинга по PnL: "
                            f"{pnl_emoji} {pnl_percentage:.2f}% >= {trigger_profit_percentage:.2f}%")
                return True, current_pnl, pnl_percentage

            return False, current_pnl, pnl_percentage

        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка проверки активации по PnL для {symbol}: {str(e)}")
            return False, 0.0, 0.0

    def check_pnl_based_stop_loss(self, symbol, side, entry_price, current_price, amount, stop_loss_percentage,
                                  margin=None):
        """Проверяет стоп-лосс на основе PnL по margin."""
        try:
            current_pnl = 0.0
            pnl_percentage = 0.0
            try:
                positions = self.futures_api.list_positions(settle='usdt')
                for pos in positions:
                    if pos.contract == symbol and (
                            (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                        current_pnl = float(pos.unrealised_pnl)
                        if margin is None:
                            margin = float(pos.margin)
                        pnl_percentage = (current_pnl / margin * 100) if margin else 0.0
                        break
            except Exception as e:
                logger.error(f"Пользователь {self.user_id}: Ошибка получения PnL с биржи для {symbol}: {str(e)}")
                current_pnl, _ = self.calculate_current_pnl(symbol, side, entry_price, current_price, amount)
                pnl_percentage = (current_pnl / margin * 100) if margin else 0.0

            if pnl_percentage <= -stop_loss_percentage:
                pnl_emoji = "🟢" if current_pnl >= 0 else "🔴"
                logger.info(f"🛑 {symbol} ({side}) - Стоп-лосс по PnL: "
                            f"{pnl_emoji} {pnl_percentage:.2f}% <= -{stop_loss_percentage:.2f}%")
                return True, current_pnl, pnl_percentage

            return False, current_pnl, pnl_percentage

        except Exception as e:
            logger.error(f"Пользователь {self.user_id}: Ошибка проверки стоп-лосса по PnL для {symbol}: {str(e)}")
            return False, 0.0, 0.0

def start_periodic_sync(user_id):
    while True:
        try:
            gate = GateIO(get_user_data(user_id))
            gate.sync_positions()
            time.sleep(CHECK_INTERVAL)  # Например, 5 секунд
        except Exception as e:
            logger.error(f"Пользователь {user_id}: Ошибка периодической синхронизации: {str(e)}")
            time.sleep(10)  # Ждем 10 секунд перед следующей попыткой

def update_signals_file():
    with open(SIGNALS_FILE, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    with open(SIGNALS_FILE, 'w', encoding='utf-8') as file:
        for line in lines:
            if line.strip() not in processed_signals:
                file.write(line)


# Обработка сигналов
def parse_signal(signal_line):
    logger.info(f"Обработка сигнала: {signal_line}")
    pattern = r'(🟢 buy|🔴 sell)\s+(\w+)/USDT\s+\(([1-9][0-9]?[mhdw])\)'
    match = re.search(pattern, signal_line, re.IGNORECASE)
    if match:
        action, symbol, timeframe = match.groups()
        # Генерируем уникальный ID для сигнала на основе содержимого и временной метки
        import hashlib
        import time
        signal_id = hashlib.md5(f"{action}_{symbol}_{timeframe}_{time.time()}".encode()).hexdigest()
        signal = {
            'action': 'buy' if 'buy' in action.lower() else 'sell',
            'symbol': f"{symbol.upper()}_USDT",
            'timeframe': timeframe,
            'signal_id': signal_id
        }
        logger.info(f"Сигнал распознан: {signal}")
        return signal
    logger.warning("Неверный формат сигнала")
    return None


processed_signals = set()


def monitor_signals_for_user(user_id):
    """Мониторит сигналы для пользователя и отправляет сообщения о причинах отказа"""
    user_data = get_user_data(user_id)
    if not user_data:
        bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: пользователь {user_id} не найден")
        return False
    if not user_data.get('is_trading'):
        bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: торговля не активна для пользователя {user_id}")
        return False
    if not user_data.get('api_key'):
        bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: API ключи не настроены для пользователя {user_id}")
        return False
    return True


def process_signals_from_file(user_id):
    last_modified = 0
    user_data = get_user_data(user_id)
    if not user_data or not user_data['api_key']:
        logger.error(f"Пользователь {user_id}: API ключи не настроены")
        bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: API ключи не настроены для пользователя {user_id}")
        return
    gate = GateIO(user_data)
    while user_data and user_data.get('is_trading'):
        try:
            current_modified = os.path.getmtime(SIGNALS_FILE)
            if current_modified != last_modified:
                last_modified = current_modified
                with open(SIGNALS_FILE, 'r', encoding='utf-8') as file:
                    signals = file.readlines()
                for signal in signals:
                    signal = signal.strip()
                    if signal and signal not in processed_signals:
                        parsed_signal = parse_signal(signal)
                        if parsed_signal:
                            # Проверяем состояние пользователя перед обработкой
                            if monitor_signals_for_user(user_id):
                                gate.handle_signal(parsed_signal)
                            processed_signals.add(signal)
                            update_signals_file()  # Удаляем обработанный сигнал из файла
                        else:
                            logger.warning(f"Неверный формат сигнала: {signal}")
                            bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: неверный формат сигнала {signal}")
                gate.sync_positions()
                user_data = get_user_data(user_id)
                time.sleep(CHECK_INTERVAL)
        except Exception as e:
            logger.error(f"Пользователь {user_id}: Ошибка обработки сигналов: {str(e)}")
            time.sleep(CHECK_INTERVAL)


def process_telegram_signal(signal_line, user_id):
    user_data = safe_get_user_data(user_id)
    if not user_data or not user_data.get('is_trading'):
        logger.info(f"Пользователь {user_id}: Торговля не активна")
        bot.send_message(GROUP_CHAT_ID, f"Сигнал не обработан: торговля не активна для пользователя {user_id}")
        return
    gate = GateIO(user_data)
    signal = parse_signal(signal_line)
    if signal and not check_daily_loss_limit(user_id) and not check_max_open_trades(user_id):
        try:
            symbol = signal['symbol']
            side = signal['action']
            timescale = signal['timeframe']
            if not gate.validate_symbol(symbol):
                logger.warning(f"Пользователь {user_id}: Символ {symbol} не поддерживается, сигнал отклонен")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал отклонен: {symbol} не поддерживается")
                return
            try:
                gate.futures_api.get_futures_contract(settle='usdt', contract=symbol)
            except Exception as e:
                logger.error(f"Пользователь {user_id}: Ошибка проверки символа {symbol}: {str(e)}, сигнал отклонен")
                bot.send_message(GROUP_CHAT_ID, f"Сигнал отклонен: {symbol} не доступен на бирже")
                return
            # Вызов place_order с учетом усреднения
            order_id, qty = gate.place_order(symbol, side, timescale)
            if order_id and qty:
                price = gate.get_current_price(symbol)
                if price:
                    # Для новой позиции (не усредненной) добавляем запись в базу
                    # УБРАЛИ дублирующий вызов add_trade, так как он уже происходит в place_order
                    pass
                    # existing_trades = get_open_trades_by_symbol_and_side(user_id, symbol, side)
                    # if not user_data['averaging_enabled'] or not existing_trades:
                    #     config = get_tp_config(user_id, timescale)
                    #     stop_price = price * (1 - config['stop_loss_percentage'] / 100 if side == 'buy' else 1 + config[
                    #         'stop_loss_percentage'] / 100)
                    #     # Получаем баланс при открытии позиции
                    #     balance_at_open = gate.get_balance_usdt()
                    #     trade_id = add_trade(user_id, symbol, side, price, qty, int(time.time()), "OPEN", timescale,
                    #                          current_stop_price=stop_price, open_order_id=order_id,
                    #                          average_entry_price=price,
                    #                          trailing_active=0, highest_price=price if side == 'buy' else None,
                    #                          lowest_price=price if side == 'sell' else None,
                    #                          balance_at_open=balance_at_open)
                    #     # Мониторинг трейлинг-стопа теперь запускается внутри place_order
                    #     # gate.trailing_stop_manager.start_monitoring(symbol, side)
        except Exception as e:
            logger.error(f"Пользователь {user_id}: Ошибка обработки Telegram сигнала: {str(e)}")
            bot.send_message(GROUP_CHAT_ID, f"Ошибка обработки сигнала для {symbol}")


def clean_old_trades(days=30):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cutoff = int(time.time()) - days * 86400
        cursor.execute("DELETE FROM trades WHERE timestamp < ? AND status = 'CLOSED'", (cutoff,))
        conn.commit()


schedule.every().day.do(clean_old_trades)


# Команды Telegram
@bot.message_handler(commands=['help'])
def help_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    help_text = (
        "📜 Доступные команды:\n"
        "/start - Настройка бота\n"
        "/stop - Остановить торговлю\n"
        "/balance - Показать баланс USDT\n"
        "/positions - Открытые позиции с PnL\n"
        "/sl [coin] - Статус стоп-лоссов и статистика\n"
        "/history - История сделок (до 10)\n"
        "/settings - Изменить настройки\n"
        "/tpconfig [timescale SL% TP% TL% PL%] - Настройка стоп-лосса/трейлинга\n"
        "/closeall - Закрыть все позиции\n"
        "/sellall - Продать все позиции\n"
        "/status - Статус позиций\n"
        "/close <coin> - Закрыть позиции по монете (например, /close btc)\n"
        "/report - Получить отчёт\n"
        "/import - Импорт оптимизированных настроек\n"
        "/export - Экспорт текущих настроек"

    )
    bot.send_message(message.chat.id, help_text)


@bot.message_handler(commands=['start'])
def start_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещён.")
        return

    user_data = get_user_data(user_id)

    # Если пользователь зарегистрирован
    if user_data and user_data.get('api_key') and user_data.get('api_secret'):
        # Получаем статус торговли
        is_trading = user_data.get('is_trading', 0)
        trading_status = "🟢 Активна" if is_trading else "🔴 Остановлена"

        # Получаем баланс
        gate = GateIO(user_data)
        balance = gate.get_balance_usdt()
        balance_text = f"{balance:.2f} USDT" if balance is not None else "Ошибка получения"

        # Получаем открытые позиции с PnL
        open_trades = get_open_trades_with_pnl(user_id)
        open_positions_count = len(open_trades) if open_trades else 0

        # Формируем информацию о настройках
        account_type = user_data.get('account_type', 'demo')
        leverage = user_data.get('leverage', 10)
        order_type = user_data.get('order_type', 'percentage')
        size_str = f"{user_data.get('qty_percentage', 5):.1f}%" if order_type == 'percentage' else f"{user_data.get('fixed_volume', 100):.2f} USDT"

        # Проверяем лимиты
        daily_loss_limit = user_data.get('daily_loss_limit', 3)
        max_open_trades = user_data.get('max_open_trades', 5)

        # Статус сообщение
        status_message = (
            f"<b>📊 Статус пользователя {user_id}</b>\n\n"
            f"<b>🔄 Торговля:</b> {trading_status}\n"
            f"<b>💰 Баланс:</b> {balance_text}\n"
            f"<b>📈 Открытые позиции:</b> {open_positions_count}/{max_open_trades}\n\n"
            f"<b>⚙️ Текущие настройки:</b>\n"
            f"• Тип счета: {account_type}\n"
            f"• Кредитное плечо: {leverage:.0f}x\n"
            f"• Режим маржи: {user_data.get('margin_mode', 'isolated')}\n"
            f"• Тип ордера: {order_type}\n"
            f"• Размер позиции: {size_str}\n"
            f"• Стоп-лосс: {user_data.get('initial_stop_percentage', 3):.1f}%\n"
            f"• Триггер трейлинга: {user_data.get('trigger_profit_percentage', 5):.1f}%\n"
            f"• Трейлинг-стоп: {user_data.get('trailing_percentage', 1):.1f}%\n"
            f"• Интервал трейлинга: {user_data.get('trailing_interval', 2)} сек\n"
            f"• Фиксация прибыли: {user_data.get('profit_lock_percentage', 2):.1f}%\n"
            f"• Дневной лимит убытков: {daily_loss_limit}\n"
            f"• Макс. позиций: {max_open_trades}\n\n"
        )

        # Добавляем информацию об открытых позициях
        if open_trades:
            # Рассчитываем общий PnL
            total_pnl = 0
            profitable_trades = 0
            for trade in open_trades:
                pnl = trade.get('pnl')
                if pnl is not None:
                    total_pnl += pnl
                    if pnl > 0:
                        profitable_trades += 1

            pnl_emoji = "🟢" if total_pnl > 0 else "🔴" if total_pnl < 0 else "⚪"
            status_message += f"<b>📋 Открытые позиции ({len(open_trades)}):</b>\n"
            status_message += f"<b>💰 Общий PnL: {pnl_emoji} {total_pnl:+.2f} USDT</b>\n"
            status_message += f"<b>📈 Прибыльных: {profitable_trades}/{len(open_trades)}</b>\n\n"

            for trade in open_trades[:5]:  # Показываем первые 5
                pnl = trade.get('pnl')
                current_price = trade.get('current_price')

                if pnl is not None:
                    pnl_text = f"{pnl:+.2f}"
                    pnl_emoji = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "⚪"
                else:
                    pnl_text = "N/A"
                    pnl_emoji = "⚪"

                price_info = f"@{current_price:.4f}" if current_price else "N/A"
                status_message += f"{pnl_emoji} {trade['symbol']} ({trade['side']}): {pnl_text} USDT | {price_info}\n"

            if len(open_trades) > 5:
                status_message += f"• ... и ещё {len(open_trades) - 5} позиций\n"
            status_message += "\n"

        # Меню действий
        if is_trading:
            status_message += (
                "<b>🎯 Выберите действие:</b>\n"
                "1️⃣ <b>Продолжить торговлю</b> — оставить как есть\n"
                "2️⃣ <b>Остановить торговлю</b> — приостановить бота\n"
                "3️⃣ <b>Изменить настройки</b> — перейти к /settings\n"
                "4️⃣ <b>Сбросить настройки</b> — удалить все данные\n\n"
                "Ответьте: '1', '2', '3' или '4'"
            )
        else:
            status_message += (
                "<b>🎯 Выберите действие:</b>\n"
                "1️⃣ <b>Начать торговлю</b> — запустить бота\n"
                "2️⃣ <b>Изменить настройки</b> — перейти к /settings\n"
                "3️⃣ <b>Сбросить настройки</b> — удалить все данные\n\n"
                "Ответьте: '1', '2' или '3'"
            )

        bot.send_message(message.chat.id, status_message, parse_mode='HTML')
        states[user_id] = "await_start_action"
        return

    # Если пользователь не зарегистрирован - стандартная регистрация
    bot.send_message(message.chat.id,
                     f"Пользователь {user_id}, добро пожаловать!\n"
                     "Перед началом работы необходимо пройти пошаговую настройку.\n\n"
                     "<b>1. Стратегия торговли</b>\n"
                     "- 🚀 Разгон депозита — агрессивно, быстрый рост и большие риски.\n"
                     "- ⚡ Скальпинг — частые короткие сделки, быстрые входы/выходы.\n"
                     "- 🛡 Уверенная торговля — минимальные риски, долгосрочный рост.\n"
                     "- 🧩 Своя стратегия — вы сами задаёте все параметры.\n\n"
                     "<b>Совет:</b> Новичкам лучше начать с 'уверенной торговли' или 'скальпинга'.\n\n"
                     "Ответьте: 'разгон', 'скальпинг', 'уверенная' или 'своя'.",
                     parse_mode='HTML'
                     )
    states[user_id] = "await_strategy_choice"
    user_reg_data[user_id] = {}


@bot.message_handler(func=lambda message: states.get(message.from_user.id) == "await_strategy_choice")
def handle_strategy_choice(message):
    user_id = message.from_user.id
    text = message.text.strip().lower()
    strategy_templates = {
        'скальпинг': {
            'leverage': 15, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
            'initial_stop_percentage': 4.0, 'trigger_profit_percentage': 6.0, 'profit_lock_percentage': 2.5,
            'trailing_percentage': 1.5, 'trailing_interval': 2, 'daily_loss_limit': 5, 'max_open_trades': 5
        },
        'разгон': {
            'leverage': 20, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
            'initial_stop_percentage': 5.0, 'trigger_profit_percentage': 10.0, 'profit_lock_percentage': 3.5,
            'trailing_percentage': 2.0, 'trailing_interval': 2, 'daily_loss_limit': 10, 'max_open_trades': 10
        },
        'уверенная': {
            'leverage': 10, 'margin_mode': 'isolated', 'order_type': 'percentage', 'qty_percentage': 5,
            'initial_stop_percentage': 3.5, 'trigger_profit_percentage': 5.0, 'profit_lock_percentage': 2.0,
            'trailing_percentage': 1.2, 'trailing_interval': 3, 'daily_loss_limit': 2, 'max_open_trades': 2
        }
    }
    if text in strategy_templates:
        user_reg_data[user_id]['strategy'] = text
        user_reg_data[user_id]['template'] = strategy_templates[text]
        params = strategy_templates[text]
        params_text = (
            f"<b>Шаблон для стратегии:</b> {text.capitalize()}  \n"
            f"- Кредитное плечо: <b>{params['leverage']}x</b>  \n"
            f"- Режим маржи: <b>{params['margin_mode']}</b>  \n"
            f"- Тип ордера: <b>{params['order_type']}</b>  \n"
            f"- Процент от баланса: <b>{params['qty_percentage']}%</b>  \n"
            f"- Стоп-лосс: <b>{params['initial_stop_percentage']}%</b>  \n"
            f"- Триггер трейлинга: <b>{params['trigger_profit_percentage']}%</b>  \n"
            f"- Фиксация прибыли: <b>{params['profit_lock_percentage']}%</b>  \n"
            f"- Трейлинг-стоп: <b>{params['trailing_percentage']}%</b>  \n"
            f"- Интервал трейлинга: <b>{params['trailing_interval']} сек</b>  \n"
            f"- Лимит убыточных сделок: <b>{params['daily_loss_limit']}</b>  \n"
            f"- Максимум открытых позиций: <b>{params['max_open_trades']}</b>  \n\n"
            "<b>Подтвердить эти параметры?</b>\nОтветьте 'да' или 'нет'."
        )
        states[user_id] = "await_strategy_confirm"
        bot.send_message(message.chat.id, params_text, parse_mode='HTML')
    elif text == 'своя':
        user_reg_data[user_id]['strategy'] = text
        # Переход к ручной настройке для своей стратегии
        bot.send_message(message.chat.id,
                         "<b>2. Тип счёта</b>\n"
                         "- 💰 <b>Реальный</b> — торговля настоящими средствами.\n"
                         "- 🧪 <b>Демо</b> — безопасное тестирование без риска.\n\n"
                         "<b>Совет:</b> Для начала рекомендуем выбрать 'демо', чтобы ознакомиться с ботом без риска потерь.\n\n"
                         "Ответьте 'реальный' или 'демо'.",
                         parse_mode='HTML'
                         )
        states[user_id] = "await_account_type_custom"
    else:
        bot.send_message(message.chat.id, "Пожалуйста, выберите: разгон, скальпинг, уверенная или своя.")


@bot.message_handler(func=lambda message: states.get(message.from_user.id) == "await_strategy_confirm")
def handle_strategy_confirm(message):
    user_id = message.from_user.id
    text = message.text.strip().lower()
    if text == 'да':
        # После подтверждения — переход к шагу выбора типа счёта
        bot.send_message(message.chat.id,
                         "<b>2. Тип счёта</b>\n"
                         "- 💰 <b>Реальный</b> — торговля настоящими средствами.\n"
                         "- 🧪 <b>Демо</b> — безопасное тестирование без риска.\n\n"
                         "<b>Совет:</b> Для начала рекомендуем выбрать 'демо', чтобы ознакомиться с ботом без риска потерь.\n\n"
                         "Ответьте 'реальный' или 'демо'.",
                         parse_mode='HTML'
                         )
        states[user_id] = "await_account_type_template"
    elif text == 'нет':
        bot.send_message(message.chat.id,
                         "Выберите стратегию заново: 'разгон', 'скальпинг', 'уверенная' или 'своя'.")
        states[user_id] = "await_strategy_choice"
    else:
        bot.send_message(message.chat.id, "Пожалуйста, ответьте 'да' или 'нет'.")


@bot.message_handler(commands=['stop'])
def stop_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    update_user_data(user_id, "is_trading", 0)
    bot.send_message(message.chat.id, f"Пользователь {user_id}: Торговля остановлена.")
    logger.info(f"Торговля остановлена для пользователя {user_id}")


@bot.message_handler(commands=['balance'])
def balance_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещён.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Настройте API ключи через /start.")
        return
    gate = GateIO(user_data)
    balance = gate.get_balance_usdt()
    if balance is not None:
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Баланс: {balance:.2f} USDT")
    else:
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Ошибка получения баланса.")


@bot.message_handler(commands=['sl'])
def sl_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Настройте API ключи через /start.")
        return
    gate = GateIO(user_data)
    args = message.text.strip().split()
    symbol = f"{args[1].upper()}_USDT" if len(args) > 1 else None
    trades = get_trades_by_symbol(user_id, symbol)
    if not trades:
        bot.send_message(message.chat.id, f"Нет открытых позиций{' для ' + symbol if symbol else ''}.")
        return
    response = f"🛑 Статус стоп-лоссов{' для ' + symbol if symbol else ''}:\n"
    total_sl_triggers = 0
    for trade in trades:
        response += (
            f"{trade['symbol']} ({trade['side']}):\n"
            f"- Стоп: {trade['current_stop_price']:.2f}\n"
            f"- Трейлинг: {'Активен' if trade['trailing_active'] else 'Не активен'}\n"
        )
        if trade['trailing_active']:
            total_sl_triggers += 1
    today = int(time.time() // 86400) * 86400
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if symbol:
            cursor.execute('''
                           SELECT COUNT(*)
                           FROM trades
                           WHERE user_id = ?
                             AND symbol = ?
                             AND status = 'CLOSED'
                             AND timestamp >= ?
                             AND close_reason IN ('stop_loss'
                               , 'trailing_stop')
                           ''', (user_id, symbol, today))
        else:
            cursor.execute('''
                           SELECT COUNT(*)
                           FROM trades
                           WHERE user_id = ?
                             AND status = 'CLOSED'
                             AND timestamp >= ?
                             AND close_reason IN ('stop_loss'
                               , 'trailing_stop')
                           ''', (user_id, today))
        sl_stats = cursor.fetchone()[0]
    response += f"\n📈 Статистика за сегодня:\n- Сработавшие стопы: {sl_stats}\n- Активные трейлинги: {total_sl_triggers}"
    bot.send_message(message.chat.id, response)


@bot.message_handler(commands=['history'])
def history_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Настройте API ключи через /start.")
        return
    trades = get_trade_history(user_id)
    if not trades:
        bot.send_message(message.chat.id, f"Пользователь {user_id}: История сделок пуста.")
        return
    response = f"📜 История сделок (до 10) для {user_id}:\n"
    for trade in trades:
        symbol = trade['symbol']
        side = trade['side']
        entry_price = trade['price']
        close_price = trade['close_price']
        amount = trade['amount']
        profit = trade.get('pnl', 0.0)
        fees = trade.get('fees', 0.0)
        margin = trade.get('margin', None)
        timestamp = datetime.fromtimestamp(trade['timestamp']).strftime('%Y-%m-%d %H:%M:%S')
        reason = trade['close_reason']
        if entry_price is None or close_price is None or amount is None:
            response += (
                f"{symbol} ({side})\n"
                f"- Данные некорректны (цена входа, цена выхода или объем отсутствуют)\n"
                f"- Причина: {reason}\n"
                f"- Время: {timestamp}\n\n"
            )
            continue
        # Для истории margin не всегда есть, поэтому считаем по стоимости позиции, если нет margin
        if margin is not None and margin > 0:
            profit_percentage = (profit / margin * 100)
        else:
            position_value = abs(amount * entry_price)
            profit_percentage = (profit / position_value * 100) if position_value > 0 else 0.0
        profit_label = "Прибыль" if profit >= 0 else "Убыток"
        response += (
            f"{symbol} ({side})\n"
            f"- Вход: {entry_price:.2f}\n"
            f"- Выход: {close_price:.2f}\n"
            f"- Кол-во: {amount:.4f}\n"
            f"- {profit_label}: {abs(profit):.2f} USDT ({profit_percentage:+.2f}%)\n"
            f"- Причина: {reason}\n"
            f"- Время: {timestamp}\n\n"
        )
    bot.send_message(message.chat.id, response)


@bot.message_handler(commands=['closeall'])
def closeall_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "🚫 Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"⚠️ Пользователь {user_id}: Настройте API ключи через /start.")
        return
    gate = GateIO(user_data)

    max_attempts = 3
    closed_count = 0
    failed = []
    total_pnl = 0.0

    for attempt in range(1, max_attempts + 1):
        positions = gate.futures_api.list_positions(settle='usdt')
        open_positions = [pos for pos in positions if pos.size != 0]
        if not open_positions:
            break
        for pos in open_positions:
            symbol = pos.contract
            side = 'buy' if pos.size > 0 else 'sell'
            qty = abs(float(pos.size)) * float(
                gate.futures_api.get_futures_contract(settle='usdt', contract=symbol).quanto_multiplier)
            entry_price = float(pos.entry_price)

            order_id, actual_qty = gate.close_position_enhanced(symbol, side, qty, reason="closeall_real")
            if order_id:
                # Получаем PnL с биржи
                total_profit = 0.0
                total_fees = 0.0
                try:
                    closed_positions = gate.futures_api.list_position_close(settle='usdt', contract=symbol)
                    for closed_pos in closed_positions:
                        if int(closed_pos.time) >= (int(time.time()) - 3600) and closed_pos.contract == symbol:
                            if (closed_pos.side == 'long' and side == 'buy') or (
                                    closed_pos.side == 'short' and side == 'sell'):
                                total_profit = float(closed_pos.pnl) if hasattr(closed_pos, 'pnl') else 0.0
                                total_fees = float(closed_pos.fee) if hasattr(closed_pos, 'fee') else 0.0
                                break
                except Exception as e:
                    logger.error(f"Пользователь {user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")
                    # Если не удалось получить с биржи, рассчитываем вручную
                    current_price = gate.get_current_price(symbol) or entry_price
                    if side == 'buy':
                        total_profit = (current_price - entry_price) * actual_qty
                    else:
                        total_profit = (entry_price - current_price) * actual_qty

                total_pnl += total_profit
                pnl_emoji = "🟢" if total_profit >= 0 else "🔴"
                pnl_text = "Прибыль" if total_profit >= 0 else "Убыток"

                # Рассчитываем процент прибыли по margin
                margin = 0
                try:
                    positions = gate.futures_api.list_positions(settle='usdt')
                    for pos in positions:
                        if pos.contract == symbol and (
                                (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                            margin = float(pos.margin)
                            break
                except:
                    pass
                profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0

                # Обновляем запись в базе, если она есть
                open_trades = get_open_trades_by_symbol_and_side(user_id, symbol, side)
                if open_trades:
                    trade = open_trades[0]
                    update_trade_status(trade['trade_id'], "CLOSED", close_price=current_price, close_order_id=order_id,
                                        close_reason="closeall_real", pnl=total_profit, fees=total_fees)
                else:
                    trade_id = add_trade(user_id, symbol, side, entry_price, actual_qty, int(time.time()), "CLOSED",
                                         '1h', balance_at_open=None, signal_id=None)
                    update_trade_status(trade_id, "CLOSED", close_price=current_price, close_order_id=order_id,
                                        close_reason="closeall_real", pnl=total_profit, fees=total_fees)

                # Получаем текущий баланс и баланс при открытии
                current_balance = gate.get_balance_usdt()

                # Получаем баланс при открытии из базы данных
                balance_at_open = None
                if open_trades:
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT balance_at_open FROM trades WHERE trade_id = ?",
                                       (open_trades[0]['trade_id'],))
                        row = cursor.fetchone()
                        if row is not None and row[0] is not None:
                            balance_at_open = row[0]

                # Изменение баланса равно PnL сделки
                balance_change = total_profit
                balance_change_percentage = (
                            balance_change / balance_at_open * 100) if balance_at_open is not None and balance_at_open > 0 else 0.0

                # Отправляем подробное сообщение с эмодзи
                side_emoji = "📈" if side == 'buy' else "📉"
                with message_lock:
                    msg_key = (user_id, symbol, side, 'close_real', int(time.time() // 60))
                    if msg_key not in sent_messages:
                        bot.send_message(message.chat.id,
                                         f"{side_emoji} Закрыта позиция {side} для {symbol}\n"
                                         f"💰 Вход: {entry_price:.4f} | Выход: {current_price:.4f}\n"
                                         f"{pnl_emoji} {pnl_text}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%)\n"
                                         f"💳 Баланс: {current_balance:.2f} USDT ({balance_change:+.2f} USDT, {balance_change_percentage:+.2f}%)\n"
                                         f"📋 Причина: Команда /closeall")
                        sent_messages.add(msg_key)
                closed_count += 1
            else:
                failed.append(f"{symbol} ({side})")
        if attempt < max_attempts:
            time.sleep(2)

    # Финальное сообщение
    if closed_count == 0:
        bot.send_message(message.chat.id, f"ℹ️ Пользователь {user_id}: Нет открытых позиций для закрытия.")
    else:
        total_emoji = "🟢" if total_pnl >= 0 else "🔴"
        total_text = "Общая прибыль" if total_pnl >= 0 else "Общий убыток"
        bot.send_message(message.chat.id,
                         f"✅ Пользователь {user_id}: Закрыто {closed_count} позиций.\n"
                         f"{total_emoji} {total_text}: {total_pnl:+.2f} USDT")
    if failed:
        bot.send_message(message.chat.id, "❌ Не удалось закрыть: " + ", ".join(set(failed)))
    send_open_positions_status(user_id, message.chat.id)


@bot.message_handler(commands=['sellall'])
def sellall_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "🚫 Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"⚠️ Пользователь {user_id}: Настройте API ключи через /start.")
        return
    gate = GateIO(user_data)

    # Получаем все позиции с биржи
    try:
        positions = gate.futures_api.list_positions(settle='usdt')
        closed_count = 0
        total_pnl = 0.0

        for pos in positions:
            if pos.size != 0:  # Если есть открытая позиция
                symbol = pos.contract
                side = 'buy' if pos.size > 0 else 'sell'
                qty = abs(float(pos.size)) * float(
                    gate.futures_api.get_futures_contract(settle='usdt', contract=symbol).quanto_multiplier)
                entry_price = float(pos.entry_price)

                # Закрываем позицию
                order_id, actual_qty = gate.close_position_enhanced(symbol, side, qty, reason="sellall")
                if order_id:
                    # Получаем PnL с биржи
                    total_profit = 0.0
                    total_fees = 0.0
                    try:
                        closed_positions = gate.futures_api.list_position_close(settle='usdt', contract=symbol)
                        for closed_pos in closed_positions:
                            if int(closed_pos.time) >= (int(time.time()) - 3600) and closed_pos.contract == symbol:
                                if (closed_pos.side == 'long' and side == 'buy') or (
                                        closed_pos.side == 'short' and side == 'sell'):
                                    total_profit = float(closed_pos.pnl) if hasattr(closed_pos, 'pnl') else 0.0
                                    total_fees = float(closed_pos.fee) if hasattr(closed_pos, 'fee') else 0.0
                                    break
                    except Exception as e:
                        logger.error(f"Пользователь {user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")
                        # Если не удалось получить с биржи, рассчитываем вручную
                        current_price = gate.get_current_price(symbol) or entry_price
                        if side == 'buy':
                            total_profit = (current_price - entry_price) * actual_qty
                        else:
                            total_profit = (entry_price - current_price) * actual_qty

                    total_pnl += total_profit
                    pnl_emoji = "🟢" if total_profit >= 0 else "🔴"
                    pnl_text = "Прибыль" if total_profit >= 0 else "Убыток"

                    # Рассчитываем процент прибыли по margin
                    margin = 0
                    try:
                        positions = gate.futures_api.list_positions(settle='usdt')
                        for pos in positions:
                            if pos.contract == symbol and (
                                    (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                                margin = float(pos.margin)
                                break
                    except:
                        pass
                    profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0

                    # Обновляем запись в базе, если она есть
                    open_trades = get_open_trades_by_symbol_and_side(user_id, symbol, side)
                    if open_trades:
                        trade = open_trades[0]
                        update_trade_status(trade['trade_id'], "CLOSED", close_price=current_price,
                                            close_order_id=order_id, close_reason="sellall", pnl=total_profit,
                                            fees=total_fees)
                    else:
                        trade_id = add_trade(user_id, symbol, side, entry_price, actual_qty, int(time.time()), "CLOSED",
                                             '1h', balance_at_open=None, signal_id=None)
                        update_trade_status(trade_id, "CLOSED", close_price=current_price, close_order_id=order_id,
                                            close_reason="sellall", pnl=total_profit, fees=total_fees)

                    # Получаем текущий баланс и баланс при открытии
                    current_balance = gate.get_balance_usdt()

                    # Получаем баланс при открытии из базы данных
                    balance_at_open = None
                    if open_trades:
                        with get_db_connection() as conn:
                            cursor = conn.cursor()
                            cursor.execute("SELECT balance_at_open FROM trades WHERE trade_id = ?",
                                           (open_trades[0]['trade_id'],))
                            row = cursor.fetchone()
                            if row is not None and row[0] is not None:
                                balance_at_open = row[0]

                    # Изменение баланса равно PnL сделки
                    balance_change = total_profit
                    balance_change_percentage = (
                                balance_change / balance_at_open * 100) if balance_at_open is not None and balance_at_open > 0 else 0.0

                    # Отправляем подробное сообщение с эмодзи
                    side_emoji = "📈" if side == 'buy' else "📉"
                    with message_lock:
                        msg_key = (user_id, symbol, side, 'close_sellall', int(time.time() // 60))
                        if msg_key not in sent_messages:
                            bot.send_message(message.chat.id,
                                             f"{side_emoji} Продана позиция {side} для {symbol}\n"
                                             f"💰 Вход: {entry_price:.4f} | Выход: {current_price:.4f}\n"
                                             f"{pnl_emoji} {pnl_text}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%)\n"
                                             f"💳 Баланс: {current_balance:.2f} USDT ({balance_change:+.2f} USDT, {balance_change_percentage:+.2f}%)\n"
                                             f"📋 Причина: Команда /sellall")
                            sent_messages.add(msg_key)
                    closed_count += 1
                else:
                    bot.send_message(message.chat.id, f"❌ Ошибка продажи {side} для {symbol}")

        if closed_count == 0:
            bot.send_message(message.chat.id, f"ℹ️ Пользователь {user_id}: Нет открытых позиций для продажи.")
        else:
            total_emoji = "🟢" if total_pnl >= 0 else "🔴"
            total_text = "Общая прибыль" if total_pnl >= 0 else "Общий убыток"
            bot.send_message(message.chat.id,
                             f"✅ Пользователь {user_id}: Продано {closed_count} позиций.\n"
                             f"{total_emoji} {total_text}: {total_pnl:+.2f} USDT")
        send_open_positions_status(user_id, message.chat.id)

    except Exception as e:
        logger.error(f"Пользователь {user_id}: Ошибка в команде /sellall: {str(e)}")
        bot.send_message(message.chat.id, f"❌ Ошибка при продаже позиций: {str(e)}")


@bot.message_handler(commands=['report'])
def report_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещён.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, "Настройте API-ключи.")
        return
    send_report(user_id)
    bot.send_message(message.chat.id, f"Пользователь {user_id}: Отчёт отправлен.")


@bot.message_handler(commands=['settings'])
def settings_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, f"Пользователь {user_id}: Настройте API ключи через /start.")
        return
    report_type = user_data.get('report_type', 'fixed')
    report_time = float(user_data.get('report_time', '09:00')) if report_type == 'interval' else user_data.get(
        'report_time', '09:00')
    report_display = f"ежедневно в {report_time}" if report_type == 'fixed' else f"каждые {float(report_time):.1f} часов"
    if user_data.get('order_type', 'percentage') == 'percentage':
        size_str = f"{user_data.get('qty_percentage', 5):.1f}%"
    else:
        size_str = f"{user_data.get('fixed_volume', 100):.2f} USDT"
    settings_message = (
        f"Пользователь {user_id}: Выберите, что изменить:\n"
        f"1. Gate.io API ключи (Текущие: {'настроены' if user_data.get('api_key') else 'не настроены'})\n"
        f"2. Кредитное плечо (Текущее: {user_data.get('leverage', 10):.0f}x)\n"
        f"3. Режим маржи (Текущий: {user_data.get('margin_mode', 'isolated')})\n"
        f"4. Тип ордера (Текущий: {'процент' if user_data.get('order_type', 'percentage') == 'percentage' else 'фиксированный объём'})\n"
        f"5. Размер позиции (Текущий: {size_str})\n"
        f"6. Начальный стоп-лосс (Текущий: -{user_data.get('initial_stop_percentage', 3):.1f}%)\n"
        f"7. Активация трейлинга (Текущий: +{user_data.get('trigger_profit_percentage', 5):.1f}%)\n"
        f"8. Фиксация прибыли (Текущий: +{user_data.get('profit_lock_percentage', 2):.1f}%)\n"
        f"9. Трейлинг-стоп (Текущий: {user_data.get('trailing_percentage', 1):.1f}%)\n"
        f"10. Тип счета (Текущий: {user_data.get('account_type', 'demo')})\n"
        f"11. Интервал трейлинга (Текущий: {user_data.get('trailing_interval', 2):.1f} сек)\n"
        f"12. Лимит убыточных сделок (Текущий: {user_data.get('daily_loss_limit', 3)})\n"
        f"13. Макс. открытых позиций (Текущий: {user_data.get('max_open_trades', 5)})\n"
        f"14. Время отчета (Текущее: {report_display})\n"
        f"15. Усреднение ордеров (Текущие: {'вкл' if user_data.get('averaging_enabled', False) else 'выкл'}, пауза: {user_data.get('averaging_pause', 300) / 60:.0f} мин)\n"
        f"16. Сбросить настройки\n"
        f"17. Начать торговлю"
    )
    bot.send_message(message.chat.id, settings_message)
    states[user_id] = "await_setting"
    # --- Применяем новые настройки к открытым позициям ---
    apply_tp_settings_to_open_trades(user_id)
    # --- конец применения ---


@bot.message_handler(commands=['tpconfig'])
def tpconfig_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещен.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, "Настройте API ключи через /start.")
        return
    args = message.text.strip().split()
    if len(args) == 1:
        configs = get_all_tp_configs(user_id)
        response = "📋 Настройки трейлинг-стопа и стоп-лосса:\n"
        if configs:
            for timescale, config in configs.items():
                pnl_based = config.get('pnl_based_trailing', False)
                response += (
                    f"\n🕐 Таймфрейм: {timescale}\n"
                    f"🛑 Стоп-лосс: {config['stop_loss_percentage']:.1f}% (по PnL)\n"
                    f"🎯 Триггер профита: {config['trigger_profit_percentage']:.1f}% (по PnL)\n"
                    f"📈 Трейлинг-стоп: {config['trailing_percentage']:.1f}%\n"
                    f"🔒 Фиксация прибыли: {config['profit_lock_percentage']:.1f}%\n"
                    f"💰 PnL-based trailing: {'✅ Включен' if pnl_based else '❌ Выключен'}\n"
                )
        else:
            response += "Настройки не заданы. Используются значения по умолчанию.\n"
        response += (
            "\nℹ Подсказка:\n"
            "/tpconfig <таймфрейм> <SL%> <TP%> <TL%> <PL%> [pnl]\n"
            "Пример: /tpconfig 1m 1.5 3.0 0.7 1.2 pnl\n"
            "💡 SL% - стоп-лосс по PnL, TP% - активация трейлинга по PnL\n"
            "/tpconfig reset\n"
            "/tpconfig"
        )
        bot.send_message(message.chat.id, response)
        return
    if args[1].lower() == 'reset':
        bot.send_message(message.chat.id, "Подтвердите сброс настроек /tpconfig, ответив 'Да':")
        states[user_id] = "await_tpconfig_reset_confirm"
        return
    try:
        if len(args) < 6 or len(args) > 7:
            bot.send_message(message.chat.id, "Формат: /tpconfig <timescale> <SL%> <TP%> <TL%> <PL%> [pnl]")
            return

        # Проверяем наличие параметра pnl
        pnl_based = False
        if len(args) == 7 and args[6].lower() == 'pnl':
            pnl_based = True

        timescale, sl, tp, tl, pl = args[1:6]
        sl, tp, tl, pl = map(float, [sl, tp, tl, pl])
        valid_timescale = ['1m', '5m', '15m', '30m', '1h', '4h']
        if timescale not in valid_timescale:
            bot.send_message(message.chat.id, f"Таймфрейм должен быть: {', '.join(valid_timescale)}")
            return
        if sl <= 0 or tp <= 0 or tl <= 0 or pl <= 0:
            bot.send_message(message.chat.id, "Значения должны быть больше 0")
            return
        set_tp_config(user_id, timescale, sl, tp, tl, pl, pnl_based)
        pnl_status = "✅ Включен" if pnl_based else "❌ Выключен"
        bot.send_message(message.chat.id,
                         f"Настройки для {timescale}:\nSL: {sl:.1f}%\nTP: {tp:.1f}%\nTL: {tl:.1f}%\nPL: {pl:.1f}%\nPnL-based: {pnl_status}")
        # --- Применяем новые настройки к открытым позициям ---
        open_trades = get_open_trades(user_id)
        for trade in open_trades:
            if trade['timescale'] == timescale and trade['status'] == 'OPEN':
                # Пересчитываем стоп-лосс и трейлинг-стоп
                entry_price = trade['average_entry_price'] or trade['price']
                side = trade['side']
                stop_price = entry_price * (1 - sl / 100 if side == 'buy' else 1 + sl / 100)
                trailing_price = entry_price * (1 + tp / 100 if side == 'buy' else 1 - tp / 100)
                update_trade_status(
                    trade['trade_id'], "OPEN",
                    current_stop_price=stop_price,
                    trailing_stop_price=trailing_price
                )
        # --- конец применения ---
    except ValueError:
        bot.send_message(message.chat.id, "Используйте числа для SL, TP, TL, PL")
    except Exception as e:
        logger.error(f"Ошибка в /tpconfig для {user_id}: {str(e)}")
        bot.send_message(message.chat.id, "Ошибка при настройке")


@bot.message_handler(commands=['import'])
def import_settings_command(message):
    """Команда импорта оптимизированных настроек"""
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "🚫 Доступ запрещён.")
        return
    
    bot.send_message(message.chat.id, 
                    "💾 ИМПОРТ ОПТИМИЗИРОВАННЫХ НАСТРОЕК\n\n"
                    "📁 Отправьте JSON-файл с оптимизированными настройками с бэктестера.\n"
                    "⚙️ Поддерживаемые форматы:\n"
                    "  • best_settings_all_*.json - Лучшие настройки для всех таймфреймов\n"
                    "  • top3_settings_*.json - ТОП-3 для конкретного таймфрейма\n"
                    "  • selected_settings_*.json - Конкретные выбранные настройки")
    
    # Устанавливаем состояние ожидания файла
    states[user_id] = "await_import_file"


@bot.message_handler(commands=['export'])
def export_settings_command(message):
    """Команда экспорта текущих настроек"""
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "🚫 Доступ запрещён.")
        return
    
    try:
        # Получаем все настройки пользователя
        configs = get_all_tp_configs(user_id)
        
        if not configs:
            bot.send_message(message.chat.id, "❌ Нет настроек для экспорта. Настройте параметры через /tpconfig.")
            return
        
        # Подготавливаем данные для экспорта
        export_data = {
            'export_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'export_type': 'current_settings',
            'user_id': user_id,
            'settings': {}
        }
        
        for timeframe, config in configs.items():
            export_data['settings'][timeframe] = {
                'params': {
                    'stop_loss_percentage': config['stop_loss_percentage'],
                    'trigger_profit_percentage': config['trigger_profit_percentage'], 
                    'trailing_percentage': config['trailing_percentage'],
                    'profit_lock_percentage': config['profit_lock_percentage']
                },
                'pnl_based_trailing': config.get('pnl_based_trailing', True),
                'source': 'current_bot_settings'
            }
        
        # Создаём файл
        filename = f"current_settings_user{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        # Отправляем файл пользователю
        with open(filename, 'rb') as f:
            bot.send_document(message.chat.id, f, 
                            caption=f"✅ Экспорт текущих настроек для {len(configs)} таймфреймов\n"
                                   f"📅 Время: {export_data['export_timestamp']}\n"
                                   f"🔄 Можно импортировать через /import")
        
        # Показываем краткую сводку
        summary = "📊 Экспортированные настройки:\n"
        for timeframe, config in configs.items():
            summary += f"  {timeframe}: SL={config['stop_loss_percentage']:.1f}% TP={config['trigger_profit_percentage']:.1f}% TL={config['trailing_percentage']:.1f}% PL={config['profit_lock_percentage']:.1f}%\n"
        
        bot.send_message(message.chat.id, summary)
        
        # Удаляем временный файл
        os.remove(filename)
        
    except Exception as e:
        logger.error(f"Ошибка экспорта настроек для пользователя {user_id}: {e}")
        bot.send_message(message.chat.id, f"❌ Ошибка экспорта: {e}")


@bot.message_handler(content_types=['document'], func=lambda message: states.get(message.from_user.id) == "await_import_file")
def handle_import_file(message):
    """Обработка загруженного файла с настройками"""
    user_id = message.from_user.id
    
    # Добавляем логирование для отладки
    logger.info(f"📁 Получен файл от пользователя {user_id}")
    logger.info(f"🔍 Состояние пользователя: {states.get(user_id)}")
    logger.info(f"🔐 Пользователь в ALLOWED_USERS: {user_id in ALLOWED_USERS}")
    
    if user_id not in ALLOWED_USERS:
        logger.warning(f"⛔ Отказ в доступе пользователю {user_id}")
        bot.send_message(message.chat.id, "🚫 Доступ запрещён.")
        return
    
    try:
        # Получаем информацию о файле
        logger.info(f"📎 Начинаем обработку файла...")
        file_info = bot.get_file(message.document.file_id)
        file_name = message.document.file_name
        logger.info(f"📄 Имя файла: {file_name}")
        
        # Проверяем расширение файла
        if not file_name.endswith('.json'):
            bot.send_message(message.chat.id, "❌ Поддерживаются только JSON-файлы.")
            states[user_id] = None
            return
        
        # Скачиваем файл
        downloaded_file = bot.download_file(file_info.file_path)
        
        # Парсим JSON
        settings_data = json.loads(downloaded_file.decode('utf-8'))
        
        # Определяем тип файла
        export_type = settings_data.get('export_type', 'unknown')
        
        bot.send_message(message.chat.id, f"🔍 Обрабатываем файл: {file_name}\nℹ️ Тип: {export_type}")
        
        if export_type == 'all_best':
            # Лучшие настройки для всех таймфреймов
            import_all_best_settings(user_id, settings_data, message.chat.id)
            
        elif export_type in ['timeframe_top3', 'specific_selection', 'current_settings']:
            # Остальные типы импорта
            import_other_settings(user_id, settings_data, message.chat.id, export_type)
            
        else:
            bot.send_message(message.chat.id, f"❌ Неизвестный тип файла: {export_type}")
        
    except json.JSONDecodeError:
        bot.send_message(message.chat.id, "❌ Ошибка чтения JSON-файла. Проверьте формат.")
    except Exception as e:
        logger.error(f"Ошибка импорта настроек для пользователя {user_id}: {e}")
        bot.send_message(message.chat.id, f"❌ Ошибка импорта: {e}")
    
    finally:
        # Очищаем состояние
        states[user_id] = None


def import_all_best_settings(user_id: int, settings_data: dict, chat_id: int):
    """Импорт лучших настроек для всех таймфреймов"""
    logger.info(f"📦 Начинаем импорт лучших настроек для пользователя {user_id}")
    settings = settings_data.get('settings', {})
    logger.info(f"📊 Найдено настроек: {len(settings)}")
    
    if not settings:
        bot.send_message(chat_id, "❌ Нет настроек для импорта.")
        return
    
    imported_count = 0
    summary = "💾 ИМПОРТ ЛУЧШИХ НАСТРОЕК:\n\n"
    
    for timeframe, data in settings.items():
        try:
            params = data['params']
            performance = data.get('performance', {})
            
            # Обновляем настройки в базе
            set_tp_config(user_id, timeframe, 
                         params['stop_loss_percentage'], 
                         params['trigger_profit_percentage'],
                         params['trailing_percentage'], 
                         params['profit_lock_percentage'],
                         pnl_based_trailing=True)  # Устанавливаем PnL-based по умолчанию
            
            imported_count += 1
            pnl = performance.get('total_pnl', 0)
            winrate = performance.get('winrate', 0)
            score = performance.get('optimization_score', 0)
            
            summary += f"✅ {timeframe}: SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.1f}% TL={params['trailing_percentage']:.1f}% PL={params['profit_lock_percentage']:.1f}%\n"
            summary += f"   📊 PnL: {pnl:+.2f} USDT | Винрейт: {winrate:.1f}% | Score: {score:.2f}\n\n"
            
        except Exception as e:
            logger.error(f"Ошибка импорта настроек для {timeframe}: {e}")
            summary += f"❌ {timeframe}: Ошибка импорта\n\n"
    
    summary += f"📈 Итог: импортировано {imported_count}/{len(settings)} таймфреймов\n"
    summary += "🔄 Новые настройки применяются к новым позициям\n"
    summary += "⚡ Перезапускаем потоки трейлинга для применения настроек..."
    
    bot.send_message(chat_id, summary)
    
    # ВАЖНО: Перезапускаем потоки трейлинга для применения новых настроек
    try:
        restart_trailing_threads_for_user(user_id)
        bot.send_message(chat_id, "✅ Потоки трейлинга перезапущены! Новые настройки активны для всех позиций.")
    except Exception as e:
        logger.error(f"Ошибка перезапуска потоков для пользователя {user_id}: {e}")
        bot.send_message(chat_id, f"⚠️ Настройки импортированы, но требуется ручной перезапуск бота: {e}")


def import_other_settings(user_id: int, settings_data: dict, chat_id: int, export_type: str):
    """Импорт других типов настроек"""
    try:
        summary = f"💾 ИМПОРТ НАСТРОЕК ({export_type}):\n\n"
        imported_count = 0
        
        if export_type == 'timeframe_top3':
            # ТОП-3 для конкретного таймфрейма - предлагаем выбор
            timeframe = settings_data.get('timeframe', 'unknown')
            top3_settings = settings_data.get('top3_settings', [])
            
            if not top3_settings:
                bot.send_message(chat_id, "❌ Нет настроек для импорта.")
                return
            
            # Показываем варианты для выбора
            choice_text = f"🎯 Выберите настройки для импорта (таймфрейм {timeframe}):\n\n"
            for i, setting in enumerate(top3_settings):
                rank = ["🥇", "🥈", "🥉"][i]
                params = setting['params']
                perf = setting['performance']
                choice_text += f"{rank} #{setting['rank']}. PnL: {perf['total_pnl']:+.2f} USDT\n"
                choice_text += f"   SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.1f}% TL={params['trailing_percentage']:.1f}% PL={params['profit_lock_percentage']:.1f}%\n"
            
            bot.send_message(chat_id, choice_text)
            
            # Устанавливаем состояние ожидания выбора
            states[user_id] = "await_top3_choice"
            user_top3_data[user_id] = top3_settings
            
            return
        
        elif export_type in ['specific_selection', 'current_settings']:
            # Конкретные выбранные настройки или текущие настройки
            settings = settings_data.get('settings', {})
            
            if not settings:
                bot.send_message(chat_id, "❌ Нет настроек для импорта.")
                return
            
            for timeframe, data in settings.items():
                try:
                    params = data['params']
                    performance = data.get('performance', {})
                    
                    # Обновляем настройки в базе
                    set_tp_config(user_id, timeframe, 
                                 params['stop_loss_percentage'], 
                                 params['trigger_profit_percentage'],
                                 params['trailing_percentage'], 
                                 params['profit_lock_percentage'],
                                 pnl_based_trailing=True)  # Устанавливаем PnL-based по умолчанию
                    
                    imported_count += 1
                    pnl = performance.get('total_pnl', 0)
                    winrate = performance.get('winrate', 0)
                    score = performance.get('optimization_score', 0)
                    
                    summary += f"✅ {timeframe}: SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.1f}% TL={params['trailing_percentage']:.1f}% PL={params['profit_lock_percentage']:.1f}%\n"
                    summary += f"   📊 PnL: {pnl:+.2f} USDT | Винрейт: {winrate:.1f}% | Score: {score:.2f}\n\n"
                    
                except Exception as e:
                    logger.error(f"Ошибка импорта настроек для {timeframe}: {e}")
                    summary += f"❌ {timeframe}: Ошибка импорта\n\n"
        
        summary += f"📈 Итог: импортировано {imported_count}/{len(settings)} таймфреймов\n"
        summary += "🔄 Новые настройки применяются к новым позициям"
        
        bot.send_message(chat_id, summary)
        
    except Exception as e:
        logger.error(f"Ошибка импорта настроек для пользователя {user_id}: {e}")
        bot.send_message(chat_id, f"❌ Ошибка импорта: {e}")


@bot.message_handler(content_types=['text'], chat_types=['group', 'supergroup'])
def handle_group_message(message):
    if message.chat.id != GROUP_CHAT_ID:
        return
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        return
    signal_line = message.text.strip()
    signal = parse_signal(signal_line)
    if signal:
        process_telegram_signal(signal_line, user_id)


@bot.message_handler(func=lambda message: message.from_user.id in states)
def handle_message(message):
    with lock:
        user_id = message.from_user.id
        if user_id not in ALLOWED_USERS:
            bot.send_message(message.chat.id, "Доступ запрещен.")
            return
        message_id = message.message_id
        if message_id in processed_messages:
            logger.warning(f"Сообщение {message_id} уже обработано.")
            return
        processed_messages.add(message_id)
        text = message.text.strip()
        text_lower = text.lower()
        state = states.get(user_id)
        if not state:
            if user_id in states:
                del states[user_id]
            return
        try:
            if state == "await_account_type_template":
                if text_lower in ['реальный', 'демо']:
                    account_type = 'real' if text_lower == 'реальный' else 'demo'
                    add_user(user_id)
                    update_user_data(user_id, "account_type", account_type)
                    bot.send_message(message.chat.id,
                                     "<b>3. Gate.io API ключ</b>\n"
                                     "Введите ваш API ключ от Gate.io.\n\n"
                                     "<b>Совет:</b> Создайте отдельный API-ключ с доступом только к торговле фьючерсами USDT. Не используйте ключи с доступом к выводу средств!\n",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_api_key_template"
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, выберите 'реальный' или 'демо'.")
            elif state == "await_account_type_custom":
                if text_lower in ['реальный', 'демо']:
                    account_type = 'real' if text_lower == 'реальный' else 'demo'
                    add_user(user_id)
                    update_user_data(user_id, "account_type", account_type)
                    bot.send_message(message.chat.id,
                                     "<b>3. Gate.io API ключ</b>\n"
                                     "Введите ваш API ключ от Gate.io.\n\n"
                                     "<b>Совет:</b> Создайте отдельный API-ключ с доступом только к торговле фьючерсами USDT. Не используйте ключи с доступом к выводу средств!\n",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_api_key_custom"
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, выберите 'реальный' или 'демо'.")
            elif state == "await_api_key_template":
                add_user(user_id)
                update_user_data(user_id, "api_key", text)
                bot.send_message(message.chat.id,
                                 "<b>4. Gate.io API секрет</b>\n"
                                 "Введите ваш секретный ключ (Secret) от Gate.io.\n\n"
                                 "<b>Совет:</b> Никому не сообщайте этот ключ!\n",
                                 parse_mode='HTML'
                                 )
                states[user_id] = "await_api_secret_template"
            elif state == "await_api_key_custom":
                add_user(user_id)
                update_user_data(user_id, "api_key", text)
                bot.send_message(message.chat.id,
                                 "<b>4. Gate.io API секрет</b>\n"
                                 "Введите ваш секретный ключ (Secret) от Gate.io.\n\n"
                                 "<b>Совет:</b> Никому не сообщайте этот ключ!\n",
                                 parse_mode='HTML'
                                 )
                states[user_id] = "await_api_secret_custom"
            elif state == "await_api_secret_template":
                add_user(user_id)
                update_user_data(user_id, "api_secret", text)
                user_data = get_user_data(user_id)
                gate = GateIO(user_data)
                if gate.check_permissions():
                    # Переход к выбору типа объёма
                    bot.send_message(message.chat.id,
                                     "<b>5. Тип объёма</b>\n"
                                     "Выберите тип расчёта объёма позиции: 'percentage' (процент от баланса) или 'fixed' (фиксированная сумма в USDT).\n\n"
                                     "<b>Совет:</b> Для новичков удобнее 'percentage'.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_order_type_template"
                else:
                    bot.send_message(message.chat.id,
                                     "Ошибка проверки Gate.io API ключей. Проверьте их и начните заново.")
                    states[user_id] = "await_account_type_template"
                    update_user_data(user_id, "api_key", None)
                    update_user_data(user_id, "api_secret", None)
            elif state == "await_api_secret_custom":
                add_user(user_id)
                update_user_data(user_id, "api_secret", text)
                user_data = get_user_data(user_id)
                gate = GateIO(user_data)
                if gate.check_permissions():
                    # Переход к ручной настройке параметров для своей стратегии
                    bot.send_message(message.chat.id,
                                     "<b>5. Кредитное плечо</b>\n"
                                     "Введите кредитное плечо (например, 10).\n\n"
                                     "<b>Совет:</b> Рекомендуем от 5 до 20 для начала.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_leverage_custom"
                else:
                    bot.send_message(message.chat.id,
                                     "Ошибка проверки Gate.io API ключей. Проверьте их и начните заново.")
                    states[user_id] = "await_account_type_custom"
                    update_user_data(user_id, "api_key", None)
                    update_user_data(user_id, "api_secret", None)
            elif state == "await_order_type_template":
                user_id = message.from_user.id
                text = message.text.strip().lower()
                params = user_reg_data[user_id]['template']
                if text in ['percentage', 'fixed']:
                    update_user_data(user_id, "order_type", text)
                    if text == 'percentage':
                        bot.send_message(message.chat.id,
                                         f"<b>6. Процент от баланса</b>\n"
                                         f"Введите процент от баланса для каждой сделки (по умолчанию {params['qty_percentage']}%).\n\n"
                                         f"<b>Совет:</b> Не превышайте 10% для одной сделки!",
                                         parse_mode='HTML'
                                         )
                        states[user_id] = "await_qty_percentage_template"
                    else:
                        bot.send_message(message.chat.id,
                                         "<b>6. Фиксированный объём</b>\n"
                                         "Введите сумму в USDT для каждой сделки (например, 100).\n\n"
                                         "<b>Совет:</b> Не рискуйте всей суммой сразу!",
                                         parse_mode='HTML'
                                         )
                        states[user_id] = "await_fixed_volume_template"
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, выберите 'percentage' или 'fixed'.")
            elif state == "await_qty_percentage_template":
                user_id = message.from_user.id
                try:
                    qty_percentage = float(message.text.strip())
                    if qty_percentage <= 0 or qty_percentage > 50:
                        bot.send_message(message.chat.id, "Процент должен быть от 0.1 до 50.")
                        return
                    update_user_data(user_id, "qty_percentage", qty_percentage)
                    # Применяем все остальные параметры шаблона
                    params = user_reg_data[user_id]['template']
                    for k, v in params.items():
                        if k not in ['qty_percentage', 'order_type']:
                            update_user_data(user_id, k, v)
                    # Финализация
                    bot.send_message(message.chat.id,
                                     "\n<b>Регистрация завершена!</b>\n\n"
                                     "Все параметры стратегии применены.\n"
                                     "\n<b>Начать торговлю?</b> (да/нет)\n"
                                     "\n<b>Сбросить настройки — /start или /reset</b>",
                                     parse_mode='HTML')
                    states[user_id] = "await_trade_start"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_fixed_volume_template":
                user_id = message.from_user.id
                try:
                    fixed_volume = float(message.text.strip())
                    if fixed_volume <= 0:
                        bot.send_message(message.chat.id, "Объём должен быть больше 0.")
                        return
                    update_user_data(user_id, "fixed_volume", fixed_volume)
                    update_user_data(user_id, "order_type", "fixed")
                    # Применяем все остальные параметры шаблона
                    params = user_reg_data[user_id]['template']
                    for k, v in params.items():
                        if k not in ['qty_percentage', 'order_type']:
                            update_user_data(user_id, k, v)
                    # Финализация
                    bot.send_message(message.chat.id,
                                     "\n<b>Регистрация завершена!</b>\n\n"
                                     "Все параметры стратегии применены.\n"
                                     "\n<b>Начать торговлю?</b> (да/нет)\n"
                                     "\n<b>Сбросить настройки — /start или /reset</b>",
                                     parse_mode='HTML')
                    states[user_id] = "await_trade_start"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 100).")
            elif state == "await_trade_start":
                if text_lower == 'да':
                    update_user_data(user_id, "is_trading", 1)
                    bot.send_message(message.chat.id, f"Пользователь {user_id}: Торговля начата!")
                    start_user_signals_thread(user_id)
                    del states[user_id]
                elif text_lower == 'нет':
                    bot.send_message(message.chat.id,
                                     f"Пользователь {user_id}: Торговля не начата. Используйте /start.")
                    del states[user_id]
                elif text_lower == 'сброс':
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Удалены данные пользователя {user_id}")
                    add_user(user_id)
                    bot.send_message(
                        message.chat.id,
                        f"Настройки сброшены.\n"
                        f"Выберите тип счета:\n"
                        f"- 💰 Реальный счет: для торговли реальными средствами 💵\n"
                        f"- 🧪 Демо счет: для тестирования 🧬\n"
                        f"Ответьте 'реальный' или 'демо'."
                    )
                    states[user_id] = "await_account_type_template"
                else:
                    bot.send_message(message.chat.id, "Ответьте 'Да', 'Нет' или 'Сброс'.")
            elif state == "await_leverage":
                try:
                    leverage = float(text)
                    if leverage < 1 or leverage > 100:
                        bot.send_message(message.chat.id, "Кредитное плечо от 1 до 100.")
                        return
                    update_user_data(user_id, "leverage", leverage)
                    bot.send_message(message.chat.id, "Выберите режим маржи: 'isolated' или 'cross':")
                    states[user_id] = "await_margin_mode_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 10).")
            elif state == "await_margin_mode_template":
                if text_lower in ['isolated', 'cross']:
                    update_user_data(user_id, "margin_mode", text_lower)
                    bot.send_message(message.chat.id, "Выберите тип ордера: 'percentage' или 'fixed':")
                    states[user_id] = "await_order_type_template"
                else:
                    bot.send_message(message.chat.id, "Выберите 'isolated' или 'cross'.")
            elif state == "await_order_type_template":
                if text_lower in ['percentage', 'fixed']:
                    update_user_data(user_id, "order_type", text_lower)
                    if text_lower == 'percentage':
                        bot.send_message(message.chat.id, "Введите процент от баланса (например, 5):")
                        states[user_id] = "await_qty_percentage_template"
                    else:
                        bot.send_message(message.chat.id, "Введите фиксированный объем в USDT (например, 100):")
                        states[user_id] = "await_fixed_volume_template"
                else:
                    bot.send_message(message.chat.id, "Выберите 'percentage' или 'fixed'.")
            elif state == "await_qty_percentage_template":
                try:
                    qty_percentage = float(text)
                    if qty_percentage <= 0 or qty_percentage > 50:
                        bot.send_message(message.chat.id, "Процент от 0.1 до 50.")
                        return
                    update_user_data(user_id, "qty_percentage", qty_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>8. Стоп-лосс</b>\n"
                                     "Введите значение стоп-лосса в процентах (например, 3).\n"
                                     "\n<b>Совет:</b> Стоп-лосс ограничивает убытки. Рекомендуем 2-5%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_initial_stop_percentage_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_initial_stop_percentage_template":
                try:
                    stop_percentage = float(text)
                    if stop_percentage <= 0 or stop_percentage > 100:
                        bot.send_message(message.chat.id, "Стоп-лосс от 0.1 до 100.")
                        return
                    update_user_data(user_id, "initial_stop_percentage", stop_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>9. Триггер трейлинга</b>\n"
                                     "Введите процент прибыли, при достижении которого активируется трейлинг-стоп (например, 5).\n"
                                     "\n<b>Совет:</b> Обычно 3-10%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trigger_profit_percentage_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 3).")
            elif state == "await_trigger_profit_percentage_template":
                try:
                    trigger_profit = float(text)
                    if trigger_profit <= 0:
                        bot.send_message(message.chat.id, "Процент активации должен быть больше 0.")
                        return
                    update_user_data(user_id, "trigger_profit_percentage", trigger_profit)
                    bot.send_message(message.chat.id,
                                     "<b>10. Фиксация прибыли</b>\n"
                                     "Введите процент прибыли для частичной фиксации (например, 2).\n"
                                     "\n<b>Совет:</b> Обычно 1-3%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_profit_lock_percentage_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_profit_lock_percentage_template":
                try:
                    profit_lock = float(text)
                    if profit_lock <= 0:
                        bot.send_message(message.chat.id, "Фиксация прибыли должна быть больше 0.")
                        return
                    update_user_data(user_id, "profit_lock_percentage", profit_lock)
                    bot.send_message(message.chat.id,
                                     "<b>11. Трейлинг-стоп</b>\n"
                                     "Введите процент трейлинга (например, 1).\n"
                                     "\n<b>Совет:</b> Обычно 0.5-2%. Чем меньше — тем ближе стоп к цене.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trailing_percentage_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 2).")
            elif state == "await_trailing_percentage_template":
                try:
                    trailing_percentage = float(text)
                    if trailing_percentage <= 0:
                        bot.send_message(message.chat.id, "Трейлинг-стоп должен быть больше 0.")
                        return
                    update_user_data(user_id, "trailing_percentage", trailing_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>12. Интервал трейлинга</b>\n"
                                     "Введите интервал обновления трейлинг-стопа в секундах (например, 3).\n"
                                     "\n<b>Совет:</b> Для большинства стратегий 2-5 секунд.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trailing_interval_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 1).")
            elif state == "await_trailing_interval_template":
                try:
                    trailing_interval = float(text)
                    if trailing_interval < 1:
                        bot.send_message(message.chat.id, "Интервал не менее 1 секунды.")
                        return
                    update_user_data(user_id, "trailing_interval", trailing_interval)
                    bot.send_message(message.chat.id, "Введите лимит убыточных сделок в день (например, 3):")
                    states[user_id] = "await_daily_loss_limit_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 3).")
            elif state == "await_daily_loss_limit_template":
                try:
                    daily_loss_limit = int(text)
                    if daily_loss_limit < 0:
                        bot.send_message(message.chat.id, "Лимит должен быть не менее 0.")
                        return
                    update_user_data(user_id, "daily_loss_limit", daily_loss_limit)
                    bot.send_message(message.chat.id, "Введите максимальное количество открытых позиций (например, 5):")
                    states[user_id] = "await_max_open_trades_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите целое число (например, 3).")
            elif state == "await_max_open_trades_template":
                try:
                    max_open_trades = int(text)
                    if max_open_trades < 1:
                        bot.send_message(message.chat.id, "Количество позиций должно быть не менее 1.")
                        return
                    update_user_data(user_id, "max_open_trades", max_open_trades)
                    bot.send_message(message.chat.id, "Выберите тип отчета: 'fixed' или 'interval':")
                    states[user_id] = "await_report_type_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите целое число (например, 5).")
            elif state == "await_report_type_template":
                if text_lower in ['fixed', 'interval']:
                    update_user_data(user_id, "report_type", text_lower)
                    if text_lower == 'fixed':
                        bot.send_message(message.chat.id, "Введите время отчета в формате ЧЧ:ММ (например, 00:00):")
                        states[user_id] = "await_fixed_time_template"
                    else:
                        bot.send_message(message.chat.id, "Введите интервал отчетов в часах (например, 6):")
                        states[user_id] = "await_report_time_template"
                else:
                    bot.send_message(message.chat.id, "Выберите 'fixed' или 'interval'.")
            elif state == "await_fixed_time_template":
                if re.match(r'^([0-1][0-9]|2[0-3]):[0-5][0-9]$', text):
                    update_user_data(user_id, "report_time", text)
                    bot.send_message(message.chat.id,
                                     "<b>17. Усреднение</b>\n"
                                     "Включить ли автоматическое усреднение позиции при повторном сигнале? Ответьте 'вкл' или 'выкл'.\n"
                                     "\n<b>Совет:</b> Усреднение может помочь выйти из просадки, но увеличивает риск!"
                                     )
                    states[user_id] = "await_averaging_enabled_template"
                else:
                    bot.send_message(message.chat.id, "Введите время в формате ЧЧ:ММ (например, 00:00).")
            elif state == "await_report_time_template":
                try:
                    interval = float(text)
                    if interval < 1 or interval > 24:
                        bot.send_message(message.chat.id, "Интервал от 1 до 24 часов.")
                        return
                    update_user_data(user_id, "report_time", str(interval))
                    bot.send_message(message.chat.id, "Включить усреднение? Ответьте 'вкл' или 'выкл':")
                    states[user_id] = "await_averaging_enabled_template"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 6).")
            elif state == "await_averaging_enabled_template":
                if text_lower in ['вкл', 'выкл']:
                    averaging_enabled = 1 if text_lower == 'вкл' else 0
                    update_user_data(user_id, "averaging_enabled", averaging_enabled)
                    if averaging_enabled:
                        bot.send_message(message.chat.id,
                                         "Введите паузу между усреднениями в минутах (например, 5).\n"
                                         "<b>Совет:</b> Не ставьте слишком маленькую паузу, чтобы не получить серию убыточных усреднений!"
                                         )
                        states[user_id] = "await_averaging_pause_template"
                    else:
                        bot.send_message(message.chat.id,
                                         "Усреднение выключено. Настройки сохранены.\nИспользуйте /start для запуска торговли.")
                        del states[user_id]
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, ответьте 'вкл' или 'выкл'.")
            elif state == "await_averaging_pause_template":
                try:
                    pause_minutes = float(text)
                    if pause_minutes < 1:
                        bot.send_message(message.chat.id, "Пауза должна быть не менее 1 минуты.")
                        return
                    pause_seconds = pause_minutes * 60
                    update_user_data(user_id, "averaging_pause", pause_seconds)
                    bot.send_message(message.chat.id,
                                     "Настройки усреднения сохранены.\nИспользуйте /start для запуска торговли.")
                    del states[user_id]
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_trading_decision":
                if text_lower == 'да':
                    update_user_data(user_id, "is_trading", 1)
                    bot.send_message(message.chat.id, f"Пользователь {user_id}: Торговля начата!")
                    start_user_signals_thread(user_id)
                    del states[user_id]
                elif text_lower == 'нет':
                    bot.send_message(message.chat.id,
                                     f"Пользователь {user_id}: Торговля не начата. Используйте /start.")
                    del states[user_id]
                elif text_lower == 'сброс':
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Удалены данные пользователя {user_id}")
                    add_user(user_id)
                    bot.send_message(
                        message.chat.id,
                        f"Настройки сброшены.\n"
                        f"Выберите тип счета:\n"
                        f"- 💰 Реальный счет: для торговли реальными средствами 💵\n"
                        f"- 🧪 Демо счет: для тестирования 🧬\n"
                        f"Ответьте 'реальный' или 'демо'."
                    )
                    states[user_id] = "await_account_type_template"
                else:
                    bot.send_message(message.chat.id, "Ответьте 'Да', 'Нет' или 'Сброс'.")

            elif state == "await_reset_confirm":
                if text_lower == 'да':
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Удалены данные пользователя {user_id}")
                    add_user(user_id)
                    bot.send_message(
                        message.chat.id,
                        f"Настройки сброшены.\n\nВыберите тип счета:\n- 💰 Реальный счет: для торговли реальными средствами 💵\n- 🧪 Демо счет: для тестирования 🧬\nОтветьте 'реальный' или 'демо'.",
                        parse_mode='HTML'
                    )
                    states[user_id] = "await_account_type"
                else:
                    bot.send_message(message.chat.id, "Сброс отменен.")
                    del states[user_id]
            elif state == "await_tpconfig_reset_confirm":
                if text_lower == 'да':
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Пользователь {user_id}: Настройки /tpconfig сброшены")
                    bot.send_message(message.chat.id, "Настройки /tpconfig сброшены.")
                    del states[user_id]
                else:
                    bot.send_message(message.chat.id, "Сброс /tpconfig отменен.")
                    del states[user_id]
            elif state == "await_leverage_custom":
                try:
                    leverage = float(text)
                    if leverage < 1 or leverage > 100:
                        bot.send_message(message.chat.id, "Кредитное плечо от 1 до 100.")
                        return
                    update_user_data(user_id, "leverage", leverage)
                    bot.send_message(message.chat.id,
                                     "<b>6. Режим маржи</b>\n"
                                     "Выберите режим маржи: 'isolated' или 'cross'.\n\n"
                                     "<b>Совет:</b> Рекомендуем 'isolated' для лучшего контроля рисков.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_margin_mode_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 10).")
            elif state == "await_margin_mode_custom":
                if text_lower in ['isolated', 'cross']:
                    update_user_data(user_id, "margin_mode", text_lower)
                    bot.send_message(message.chat.id,
                                     "<b>7. Тип ордера</b>\n"
                                     "Выберите тип ордера: 'percentage' (процент от баланса) или 'fixed' (фиксированная сумма в USDT).\n\n"
                                     "<b>Совет:</b> Для новичков удобнее 'percentage'.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_order_type_custom"
                else:
                    bot.send_message(message.chat.id, "Выберите 'isolated' или 'cross'.")
            elif state == "await_order_type_custom":
                if text_lower in ['percentage', 'fixed']:
                    update_user_data(user_id, "order_type", text_lower)
                    if text_lower == 'percentage':
                        bot.send_message(message.chat.id,
                                         "<b>8. Процент от баланса</b>\n"
                                         "Введите процент от баланса для каждой сделки (например, 5).\n\n"
                                         "<b>Совет:</b> Не превышайте 10% для одной сделки!",
                                         parse_mode='HTML'
                                         )
                        states[user_id] = "await_qty_percentage_custom"
                    else:
                        bot.send_message(message.chat.id,
                                         "<b>8. Фиксированный объём</b>\n"
                                         "Введите сумму в USDT для каждой сделки (например, 100).\n\n"
                                         "<b>Совет:</b> Не рискуйте всей суммой сразу!",
                                         parse_mode='HTML'
                                         )
                        states[user_id] = "await_fixed_volume_custom"
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, выберите 'percentage' или 'fixed'.")
            elif state == "await_qty_percentage_custom":
                try:
                    qty_percentage = float(text)
                    if qty_percentage <= 0 or qty_percentage > 50:
                        bot.send_message(message.chat.id, "Процент должен быть от 0.1 до 50.")
                        return
                    update_user_data(user_id, "qty_percentage", qty_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>9. Стоп-лосс</b>\n"
                                     "Введите значение стоп-лосса в процентах (например, 3).\n\n"
                                     "<b>Совет:</b> Стоп-лосс ограничивает убытки. Рекомендуем 2-5%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_initial_stop_percentage_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_fixed_volume_custom":
                try:
                    fixed_volume = float(text)
                    if fixed_volume <= 0:
                        bot.send_message(message.chat.id, "Объём должен быть больше 0.")
                        return
                    update_user_data(user_id, "fixed_volume", fixed_volume)
                    bot.send_message(message.chat.id,
                                     "<b>9. Стоп-лосс</b>\n"
                                     "Введите значение стоп-лосса в процентах (например, 3).\n\n"
                                     "<b>Совет:</b> Стоп-лосс ограничивает убытки. Рекомендуем 2-5%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_initial_stop_percentage_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 100).")
            elif state == "await_initial_stop_percentage_custom":
                try:
                    stop_percentage = float(text)
                    if stop_percentage <= 0 or stop_percentage > 100:
                        bot.send_message(message.chat.id, "Стоп-лосс от 0.1 до 100.")
                        return
                    update_user_data(user_id, "initial_stop_percentage", stop_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>10. Триггер трейлинга</b>\n"
                                     "Введите процент прибыли, при достижении которого активируется трейлинг-стоп (например, 5).\n\n"
                                     "<b>Совет:</b> Обычно 3-10%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trigger_profit_percentage_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 3).")
            elif state == "await_trigger_profit_percentage_custom":
                try:
                    trigger_profit = float(text)
                    if trigger_profit <= 0:
                        bot.send_message(message.chat.id, "Процент активации должен быть больше 0.")
                        return
                    update_user_data(user_id, "trigger_profit_percentage", trigger_profit)
                    bot.send_message(message.chat.id,
                                     "<b>11. Фиксация прибыли</b>\n"
                                     "Введите процент прибыли для частичной фиксации (например, 2).\n\n"
                                     "<b>Совет:</b> Обычно 1-3%.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_profit_lock_percentage_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_profit_lock_percentage_custom":
                try:
                    profit_lock = float(text)
                    if profit_lock <= 0:
                        bot.send_message(message.chat.id, "Фиксация прибыли должна быть больше 0.")
                        return
                    update_user_data(user_id, "profit_lock_percentage", profit_lock)
                    bot.send_message(message.chat.id,
                                     "<b>12. Трейлинг-стоп</b>\n"
                                     "Введите процент трейлинга (например, 1).\n\n"
                                     "<b>Совет:</b> Обычно 0.5-2%. Чем меньше — тем ближе стоп к цене.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trailing_percentage_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 2).")
            elif state == "await_trailing_percentage_custom":
                try:
                    trailing_percentage = float(text)
                    if trailing_percentage <= 0:
                        bot.send_message(message.chat.id, "Трейлинг-стоп должен быть больше 0.")
                        return
                    update_user_data(user_id, "trailing_percentage", trailing_percentage)
                    bot.send_message(message.chat.id,
                                     "<b>13. Интервал трейлинга</b>\n"
                                     "Введите интервал обновления трейлинг-стопа в секундах (например, 3).\n\n"
                                     "<b>Совет:</b> Для большинства стратегий 2-5 секунд.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_trailing_interval_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 1).")
            elif state == "await_trailing_interval_custom":
                try:
                    trailing_interval = float(text)
                    if trailing_interval < 1:
                        bot.send_message(message.chat.id, "Интервал не менее 1 секунды.")
                        return
                    update_user_data(user_id, "trailing_interval", trailing_interval)
                    bot.send_message(message.chat.id,
                                     "<b>14. Лимит убыточных сделок</b>\n"
                                     "Введите лимит убыточных сделок в день (например, 3).\n\n"
                                     "<b>Совет:</b> Помогает ограничить убытки в плохой день.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_daily_loss_limit_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 3).")
            elif state == "await_daily_loss_limit_custom":
                try:
                    daily_loss_limit = int(text)
                    if daily_loss_limit < 0:
                        bot.send_message(message.chat.id, "Лимит должен быть не менее 0.")
                        return
                    update_user_data(user_id, "daily_loss_limit", daily_loss_limit)
                    bot.send_message(message.chat.id,
                                     "<b>15. Максимум открытых позиций</b>\n"
                                     "Введите максимальное количество открытых позиций (например, 5).\n\n"
                                     "<b>Совет:</b> Не открывайте слишком много позиций одновременно.",
                                     parse_mode='HTML'
                                     )
                    states[user_id] = "await_max_open_trades_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите целое число (например, 3).")
            elif state == "await_max_open_trades_custom":
                try:
                    max_open_trades = int(text)
                    if max_open_trades < 1:
                        bot.send_message(message.chat.id, "Количество позиций должно быть не менее 1.")
                        return
                    update_user_data(user_id, "max_open_trades", max_open_trades)
                    bot.send_message(message.chat.id, "Выберите тип отчета: 'fixed' или 'interval':")
                    states[user_id] = "await_report_type_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите целое число (например, 5).")
            elif state == "await_report_type_custom":
                if text_lower in ['fixed', 'interval']:
                    update_user_data(user_id, "report_type", text_lower)
                    if text_lower == 'fixed':
                        bot.send_message(message.chat.id, "Введите время отчета в формате ЧЧ:ММ (например, 00:00):")
                        states[user_id] = "await_fixed_time_custom"
                    else:
                        bot.send_message(message.chat.id, "Введите интервал отчетов в часах (например, 6):")
                        states[user_id] = "await_report_time_custom"
                else:
                    bot.send_message(message.chat.id, "Выберите 'fixed' или 'interval'.")
            elif state == "await_fixed_time_custom":
                if re.match(r'^([0-1][0-9]|2[0-3]):[0-5][0-9]$', text):
                    update_user_data(user_id, "report_time", text)
                    bot.send_message(message.chat.id,
                                     "<b>17. Усреднение</b>\n"
                                     "Включить ли автоматическое усреднение позиции при повторном сигнале? Ответьте 'вкл' или 'выкл'.\n"
                                     "\n<b>Совет:</b> Усреднение может помочь выйти из просадки, но увеличивает риск!"
                                     )
                    states[user_id] = "await_averaging_enabled_custom"
                else:
                    bot.send_message(message.chat.id, "Введите время в формате ЧЧ:ММ (например, 00:00).")
            elif state == "await_report_time_custom":
                try:
                    interval = float(text)
                    if interval < 1 or interval > 24:
                        bot.send_message(message.chat.id, "Интервал от 1 до 24 часов.")
                        return
                    update_user_data(user_id, "report_time", str(interval))
                    bot.send_message(message.chat.id, "Включить усреднение? Ответьте 'вкл' или 'выкл':")
                    states[user_id] = "await_averaging_enabled_custom"
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 6).")
            elif state == "await_averaging_enabled_custom":
                if text_lower in ['вкл', 'выкл']:
                    averaging_enabled = 1 if text_lower == 'вкл' else 0
                    update_user_data(user_id, "averaging_enabled", averaging_enabled)
                    if averaging_enabled:
                        bot.send_message(message.chat.id,
                                         "Введите паузу между усреднениями в минутах (например, 5).\n"
                                         "<b>Совет:</b> Не ставьте слишком маленькую паузу, чтобы не получить серию убыточных усреднений!"
                                         )
                        states[user_id] = "await_averaging_pause_custom"
                    else:
                        bot.send_message(message.chat.id,
                                         "Усреднение выключено. Настройки сохранены.\nИспользуйте /start для запуска торговли.")
                        del states[user_id]
                else:
                    bot.send_message(message.chat.id, "Пожалуйста, ответьте 'вкл' или 'выкл'.")
            elif state == "await_averaging_pause_custom":
                try:
                    pause_minutes = float(text)
                    if pause_minutes < 1:
                        bot.send_message(message.chat.id, "Пауза должна быть не менее 1 минуты.")
                        return
                    pause_seconds = pause_minutes * 60
                    update_user_data(user_id, "averaging_pause", pause_seconds)
                    bot.send_message(message.chat.id,
                                     "Настройки усреднения сохранены.\nИспользуйте /start для запуска торговли.")
                    del states[user_id]
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число (например, 5).")
            elif state == "await_trade_start_custom":
                if text_lower == 'да':
                    update_user_data(user_id, "is_trading", 1)
                    bot.send_message(message.chat.id, f"Пользователь {user_id}: Торговля начата!")
                    start_user_signals_thread(user_id)
                    del states[user_id]
                elif text_lower == 'нет':
                    bot.send_message(message.chat.id,
                                     f"Пользователь {user_id}: Торговля не начата. Используйте /start.")
                    del states[user_id]
                elif text_lower == 'сброс':
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Удалены данные пользователя {user_id}")
                    add_user(user_id)
                    bot.send_message(
                        message.chat.id,
                        f"Настройки сброшены.\n"
                        f"Выберите тип счета:\n"
                        f"- 💰 Реальный счет: для торговли реальными средствами 💵\n"
                        f"- 🧪 Демо счет: для тестирования 🧬\n"
                        f"Ответьте 'реальный' или 'демо'."
                    )
                    states[user_id] = "await_account_type_template"
                else:
                    bot.send_message(message.chat.id, "Ответьте 'Да', 'Нет' или 'Сброс'.")
            elif state == "await_start_action":
                user_data = get_user_data(user_id)
                if not user_data:
                    bot.send_message(message.chat.id,
                                     f"Пользователь {user_id}: Ошибка получения данных. Попробуйте /start снова.")
                    del states[user_id]
                    return
                is_trading = user_data.get('is_trading', 0)

                if is_trading:
                    # Если торговля активна
                    if text_lower in ['1', 'один', 'продолжить']:
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Торговля продолжается. Используйте /status для просмотра позиций.")
                        del states[user_id]
                    elif text_lower in ['2', 'два', 'остановить']:
                        update_user_data(user_id, "is_trading", 0)
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Торговля остановлена. Используйте /start для возобновления.")
                        del states[user_id]
                    elif text_lower in ['3', 'три', 'настройки']:
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Переходим к настройкам. Используйте команду /settings")
                        del states[user_id]
                    elif text_lower in ['4', 'четыре', 'сброс']:
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Вы уверены, что хотите сбросить все настройки?\n"
                                         "Это удалит все данные пользователя. Ответьте 'да' для подтверждения.")
                        states[user_id] = "await_start_reset_confirm"
                    else:
                        bot.send_message(message.chat.id, "Пожалуйста, выберите: '1', '2', '3' или '4'")
                else:
                    # Если торговля не активна
                    if text_lower in ['1', 'один', 'начать']:
                        update_user_data(user_id, "is_trading", 1)
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Торговля запущена! Ожидайте сигналы.")
                        start_user_signals_thread(user_id)
                        del states[user_id]
                    elif text_lower in ['2', 'два', 'настройки']:
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Переходим к настройкам. Используйте команду /settings")
                        del states[user_id]
                    elif text_lower in ['3', 'три', 'сброс']:
                        bot.send_message(message.chat.id,
                                         f"Пользователь {user_id}: Вы уверены, что хотите сбросить все настройки?\n"
                                         "Это удалит все данные пользователя. Ответьте 'да' для подтверждения.")
                        states[user_id] = "await_start_reset_confirm"
                    else:
                        bot.send_message(message.chat.id, "Пожалуйста, выберите: '1', '2' или '3'")
            elif state == "await_start_reset_confirm":
                if text_lower in ['да', 'yes', 'y']:
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
                        cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
                        conn.commit()
                    logger.info(f"Удалены данные пользователя {user_id}")
                    add_user(user_id)
                    bot.send_message(
                        message.chat.id,
                        f"Пользователь {user_id}: Настройки сброшены.\n\n"
                        f"Выберите тип счета:\n"
                        f"- 💰 Реальный счет: для торговли реальными средствами 💵\n"
                        f"- 🧪 Демо счет: для тестирования 🧬\n"
                        f"Ответьте 'реальный' или 'демо'.",
                        parse_mode='HTML'
                    )
                    states[user_id] = "await_account_type_template"
                else:
                    bot.send_message(message.chat.id,
                                     f"Пользователь {user_id}: Сброс отменен. Используйте /start для возврата в главное меню.")
                    del states[user_id]
            elif state == "await_setting":
                try:
                    choice = int(text)
                    user_data = get_user_data(user_id)
                    settings_map = {
                        1: ("Gate.io API ключи", "Введите Gate.io API ключ:", "await_api_key_template"),
                        2: ("Кредитное плечо", "Введите кредитное плечо (например, 10):", "await_leverage"),
                        3: (
                        "Режим маржи", "Выберите режим маржи: 'isolated' или 'cross':", "await_margin_mode_template"),
                        4: (
                        "Тип ордера", "Выберите тип ордера: 'percentage' или 'fixed':", "await_order_type_template"),
                        5: ("Размер позиции",
                            f"Введите {'процент от баланса (например, 5)' if user_data.get('order_type', 'percentage') == 'percentage' else 'фиксированный объём в USDT (например, 100)'}:",
                            "await_qty_percentage_template" if user_data.get('order_type',
                                                                             'percentage') == 'percentage' else "await_fixed_volume_template"),
                        6: ("Стоп-лосс", "Введите начальный стоп-лосс в процентах (например, 3):",
                            "await_initial_stop_percentage_template"),
                        7: ("Триггер", "Введите процент активации трейлинга (например, 5):",
                            "await_trigger_profit_percentage_template"),
                        8: ("Фиксация прибыли", "Введите процент фиксации прибыли (например, 2):",
                            "await_profit_lock_percentage_template"),
                        9: ("Трейлинг-стоп", "Введите процент трейлинг-стопа (например, 1):",
                            "await_trailing_percentage_template"),
                        10: ("Тип счета", "Выберите тип счета: 'реальный' или 'демо':", "await_account_type_template"),
                        11: ("Интервал трейлинга", "Введите интервал трейлинга в секундах (например, 3):",
                             "await_trailing_interval_template"),
                        12: ("Лимит убыточных сделок", "Введите лимит убыточных сделок (например, 3):",
                             "await_daily_loss_limit_template"),
                        13: (
                        "Макс. открытых позиций", "Введите максимальное количество открытых позиций (например, 5):",
                        "await_max_open_trades_template"),
                        14: (
                        "Время отчета", "Выберите тип отчета: 'fixed' или 'interval':", "await_report_type_template"),
                        15: ("Усреднение", "Включить усреднение? Ответьте 'вкл' или 'выкл':",
                             "await_averaging_enabled_template"),
                        16: ("Сброс", "Подтвердите сброс, ответив 'Да':", "await_reset_confirm"),
                        17: ("Начать торговлю", None, None)
                    }
                    if choice in settings_map:
                        if choice == 17:
                            update_user_data(user_id, "is_trading", 1)
                            bot.send_message(message.chat.id, "Торговля запущена! Ожидайте сигналы.")
                            start_user_signals_thread(user_id)
                            del states[user_id]
                        else:
                            setting_name, prompt, next_state = settings_map[choice]
                            logger.info(f"Пользователь {user_id}: Выбрана настройка {setting_name}")
                            bot.send_message(message.chat.id, prompt)
                            states[user_id] = next_state
                    else:
                        bot.send_message(message.chat.id, "Выберите число от 1 до 17.")
                except ValueError:
                    bot.send_message(message.chat.id, "Введите число от 1 до 17.")
        except Exception as e:
            logger.error(f"Пользователь {user_id}: Ошибка обработки сообщения: {str(e)}")
            bot.send_message(message.chat.id, f"Ошибка: {str(e)}")
            del states[user_id]


# Функция для отправки отчетов
def send_report(user_id):
    from datetime import timezone, timedelta
    user_data = get_user_data(user_id)
    if not user_data or not user_data['api_key']:
        logger.warning(f"Пользователь {user_id}: Не настроены API ключи, отчет не отправлен")
        return
    gate = GateIO(user_data)
    balance = gate.get_balance_usdt()
    open_trades = get_open_trades(user_id)
    today = int(time.time() // 86400) * 86400
    cest = timezone(timedelta(hours=2))  # Часовой пояс CEST

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
                       SELECT close_reason, COUNT(*)
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                         AND timestamp >= ?
                       GROUP BY close_reason
                       ''', (user_id, today))
        close_reasons = {row[0] if row[0] is not None else 'Unknown': row[1] for row in cursor.fetchall()}

        cursor.execute('''
                       SELECT symbol, SUM(pnl), SUM(fees), COUNT(*)
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                         AND timestamp >= ?
                       GROUP BY symbol
                       ''', (user_id, today))
        symbol_stats = [
            {'symbol': row[0], 'pnl': row[1] or 0.0, 'fees': row[2] or 0.0, 'count': row[3]}
            for row in cursor.fetchall()
        ]
        symbol_stats.sort(key=lambda x: x['pnl'] - x['fees'], reverse=True)

        cursor.execute('''
                       SELECT SUM(pnl), SUM(fees), COUNT(*)
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                         AND timestamp >= ?
                       ''', (user_id, today))
        total_pnl, total_fees, closed_trades = cursor.fetchone()
        total_pnl = total_pnl or 0.0
        total_fees = total_fees or 0.0
        closed_trades = closed_trades or 0

        cursor.execute('''
                       SELECT timescale,
                              SUM(CASE WHEN pnl >= 0 THEN 1 ELSE 0 END) as profitable,
                              SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END)  as loss_making,
                              COUNT(*)                                  as total
                       FROM trades
                       WHERE user_id = ?
                         AND status = 'CLOSED'
                         AND timestamp >= ?
                       GROUP BY timescale
                       ''', (user_id, today))
        timeframe_stats = [
            {
                'timeframe': row[0] or 'Unknown',
                'profitable': row[1],
                'loss_making': row[2],
                'total': row[3],
                'winrate': (row[1] / row[3] * 100) if row[3] > 0 else 0.0
            }
            for row in cursor.fetchall()
        ]

        max_pnl_symbol = max_pnl = min_pnl_symbol = min_pnl = None
        if symbol_stats:
            cursor.execute('''
                           SELECT symbol, pnl - fees
                           FROM trades
                           WHERE user_id = ?
                             AND status = 'CLOSED'
                             AND timestamp >= ?
                           ORDER BY (pnl - fees) DESC LIMIT 1
                           ''', (user_id, today))
            max_row = cursor.fetchone()
            if max_row:
                max_pnl_symbol, max_pnl = max_row

            cursor.execute('''
                           SELECT symbol, pnl - fees
                           FROM trades
                           WHERE user_id = ?
                             AND status = 'CLOSED'
                             AND timestamp >= ?
                           ORDER BY (pnl - fees) ASC LIMIT 1
                           ''', (user_id, today))
            min_row = cursor.fetchone()
            if min_row:
                min_pnl_symbol, min_pnl = min_row

        initial_balance = (balance - total_pnl + total_fees) if balance is not None else None
        balance_change = ((
                                      balance - initial_balance) / initial_balance * 100) if initial_balance and initial_balance > 0 and balance is not None else None
        balance_change_usdt = (balance - initial_balance) if initial_balance and balance is not None else None

    total_result = total_pnl - total_fees
    total_result_label = "🟢 Прибыль" if total_result >= 0 else "🔴 Убыток"
    report = f"<b>📊 Отчет за {datetime.now(cest).strftime('%Y-%m-%d %H:%M:%S %Z')} для {user_id}</b>\n\n"
    report += f"<b>📌 Сводка дня</b>: {total_result_label} {abs(total_result):,.2f} USDT\n\n"

    report += "<b>💰 Баланс</b>\n"
    report += f"  Текущий баланс: {balance:,.2f} USDT\n" if balance is not None else "  Текущий баланс: Ошибка получения\n"
    report += f"  Изменение за день: {balance_change:+,.2f}% ({balance_change_usdt:+,.2f} USDT)\n" if balance_change is not None else "  Изменение за день: N/A\n"
    report += f"  Открытые позиции: {len(open_trades)}\n"
    report += f"  Закрытые сделки: {closed_trades}\n"
    report += f"  Всего сделок: {sum(stat['count'] for stat in symbol_stats)}\n\n"

    report += "<b>📈 Статистика за день</b>\n"
    if symbol_stats:
        for stat in symbol_stats:
            net_result = stat['pnl'] - stat['fees']
            result_label = "🟢 Прибыль" if net_result >= 0 else "🔴 Убыток"
            avg_pnl = net_result / stat['count'] if stat['count'] > 0 else 0.0
            symbol_escaped = stat['symbol'].replace('_', r'\_')
            report += f"  {symbol_escaped}:\n"
            report += f"    Количество сделок: {stat['count']}\n"
            report += f"    {result_label}: {abs(net_result):,.2f} USDT\n"
            report += f"    Средний PNL: {avg_pnl:+,.2f} USDT\n"
            report += "  ---------\n"
        report = report.rstrip("---------\n")
        if max_pnl is not None and max_pnl_symbol:
            max_pnl_symbol_escaped = max_pnl_symbol.replace('_', r'\_')
            report += f"\n  Лучшая сделка: {max_pnl_symbol_escaped} ({max_pnl:+,.2f} USDT)\n"
        if min_pnl is not None and min_pnl_symbol:
            min_pnl_symbol_escaped = min_pnl_symbol.replace('_', r'\_')
            report += f"  Худшая сделка: {min_pnl_symbol_escaped} ({min_pnl:+,.2f} USDT)\n"
    else:
        report += "  Нет закрытых сделок.\n"
    report += f"\n  Итог: {total_result_label} {abs(total_result):,.2f} USDT (комиссии: {total_fees:,.2f} USDT)\n\n"

    report += "<b>📅 Статистика по таймфреймам</b>\n"
    if timeframe_stats:
        for stat in timeframe_stats:
            timeframe_escaped = stat['timeframe'].replace('_', r'\_')
            report += f"  {timeframe_escaped}:\n"
            report += f"    Прибыльных сделок: {stat['profitable']}\n"
            report += f"    Убыточных сделок: {stat['loss_making']}\n"
            report += f"    Винрейт: {stat['winrate']:.2f}%\n\n"
    else:
        report += "  Нет данных по таймфреймам.\n\n"

    report += "<b>⛔ Причины закрытия</b>\n"
    for reason, count in close_reasons.items():
        reason_label = {
            'stop_loss': 'Стоп-лосс',
            'trailing_stop': 'Трейлинг-стоп',
            'manual': 'Вручную',
            'closed_on_exchange': 'Закрыто на бирже',
            'manual_no_db': 'Вручную (без базы)',
            'Unknown': 'Неизвестно'
        }.get(reason, reason)
        reason_label_escaped = reason_label.replace('_', r'\_')
        report += f"  {reason_label_escaped}: {count}\n"
    if not close_reasons:
        report += "  Нет закрытий.\n\n"

    report += "<b>⚙ Текущие настройки</b>\n"
    report += f"  Плечо: {user_data.get('leverage', 10):.0f}x\n"
    report += f"  Тип ордера: {'Процент' if user_data.get('order_type', 'percentage') == 'percentage' else 'Фиксированный'}\n"
    report += f"  Стоп-лосс: {user_data.get('initial_stop_percentage', 3):.1f}%\n"
    report += f"  Трейлинг: {user_data.get('trigger_profit_percentage', 5):.1f}% / {user_data.get('trailing_percentage', 1):.1f}%\n\n"

    max_length = 4000
    if len(report) > max_length:
        messages = []
        current_message = ""
        for line in report.split('\n'):
            if len(current_message) + len(line) + 1 > max_length:
                messages.append(current_message.strip())
                current_message = ""
            current_message += line + '\n'
        if current_message:
            messages.append(current_message.strip())
        for msg in messages:
            bot.send_message(GROUP_CHAT_ID, msg, parse_mode='HTML')
    else:
        bot.send_message(GROUP_CHAT_ID, report, parse_mode='HTML')
    logger.info(f"Пользователь {user_id}: Отчет отправлен")

    # --- ДОБАВЛЕНО: для интервального режима пересоздаём таймер ---
    user_data = get_user_data(user_id)
    if user_data and user_data.get('report_type', 'fixed') != 'fixed':
        update_report_schedule(user_id)


# Планировщик отчетов
def schedule_reports():
    while True:
        try:
            for user_id in ALLOWED_USERS:
                user_data = get_user_data(user_id)
                if not user_data or not user_data.get('is_trading', False):
                    continue
                update_report_schedule(user_id)
            schedule.run_pending()
            time.sleep(60)
        except Exception as e:
            logger.error(f"Ошибка в планировщике отчетов: {str(e)}")
            time.sleep(60)


def update_report_schedule(user_id):
    user_data = get_user_data(user_id)
    if not user_data or not user_data.get('is_trading', False):
        return
    schedule.clear(f"report_{user_id}")
    report_type = user_data.get('report_type', 'fixed')
    report_time = user_data.get('report_time', '09:00')
    if report_type == 'fixed':
        schedule.every().day.at(report_time).do(send_report, user_id=user_id).tag(f"report_{user_id}")
    else:
        try:
            interval = float(report_time)
            # Для интервального режима: планируем только один запуск через interval часов
            schedule.every(interval).hours.do(send_report, user_id=user_id).tag(f"report_{user_id}")
        except ValueError:
            logger.error(f"Пользователь {user_id}: Неверный интервал отчета: {report_time}")


@bot.message_handler(commands=['status', 'positions'])
def status_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "Доступ запрещён.")
        return
    user_data = get_user_data(user_id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, "Настройте API-ключи через /start.")
        return
    gate = GateIO(user_data)
    balance = gate.get_balance_usdt()
    try:
        positions = gate.futures_api.list_positions(settle='usdt')
    except Exception:
        positions = []
    response = f"📊 Статус для {user_id} ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}):\n"
    response += f"Свободный баланс: {balance:.2f} USDT\n\n" if balance is not None else "Свободный баланс: Ошибка получения\n\n"
    if not positions or all(getattr(pos, 'size', 0) == 0 for pos in positions):
        response += "Нет открытых позиций.\n"
    else:
        response += "Открытые позиции:\n"
        for pos in positions:
            if getattr(pos, 'size', 0) != 0:
                symbol = pos.contract
                side = 'buy' if pos.size > 0 else 'sell'
                margin = float(pos.margin)
                entry_price = Decimal(str(pos.entry_price)).quantize(Decimal('0.000001'))
                current_price = gate.get_current_price(symbol)
                current_price = Decimal(str(current_price)).quantize(Decimal('0.000001')) if current_price else 0
                pnl = float(getattr(pos, 'unrealised_pnl', 0))
                result_label = "Прибыль" if pnl >= 0 else "Убыток"
                pnl_percent = (pnl / margin * 100) if margin > 0 else 0.0
                response += (
                    f"{symbol} ({side}):\n"
                    f"  Сумма в ордере: {margin:.2f} USDT\n"
                    f"  Цена входа: {entry_price:.6f}\n"
                    f"  Текущая цена: {current_price:.6f}\n"
                    f"  {result_label}: {abs(pnl):.2f} USDT ({pnl_percent:+.2f}%)\n\n"
                )
    bot.send_message(message.chat.id, response.strip())


@bot.message_handler(commands=['close'])
def close_command(message):
    user_id = message.from_user.id
    if user_id not in ALLOWED_USERS:
        bot.send_message(message.chat.id, "🚫 Доступ запрещён.")
        return
    user_data = safe_get_user_data(user_id, message.chat.id)
    if not user_data or not user_data.get('api_key'):
        bot.send_message(message.chat.id, "⚠️ Настройте API-ключи.")
        return
    args = message.text.strip().split()
    if len(args) != 2:
        bot.send_message(message.chat.id, "📝 Формат: /close <symbol> (например, /close btc)")
        logger.warning(f"Пользователь {user_id}: Неверный формат команды /close: {message.text}")
        return
    symbol = f"{args[1].upper()}_USDT"
    gate = GateIO(user_data)
    if not gate.validate_symbol(symbol):
        bot.send_message(message.chat.id, f"❌ Символ {symbol} не поддерживается.")
        return

    # Проверяем позиции на бирже
    try:
        positions = gate.futures_api.list_positions(settle='usdt')
        for pos in positions:
            if pos.contract == symbol and pos.size != 0:
                side = 'buy' if pos.size > 0 else 'sell'
                qty = abs(float(pos.size)) * float(
                    gate.futures_api.get_futures_contract(settle='usdt', contract=symbol).quanto_multiplier)
                entry_price = float(pos.entry_price)

                # Проверяем, есть ли сделка в базе
                open_trades = get_open_trades_by_symbol_and_side(user_id, symbol, side)
                if open_trades:
                    trade = open_trades[0]
                    order_id, actual_qty = gate.close_position_enhanced(symbol, side, qty, reason="manual")
                    if order_id:
                        current_price = gate.get_current_price(symbol) or trade['average_entry_price'] or trade['price']

                        # Получаем PnL с биржи
                        total_profit = 0.0
                        total_fees = 0.0
                        try:
                            closed_positions = gate.futures_api.list_position_close(settle='usdt', contract=symbol)
                            for closed_pos in closed_positions:
                                if int(closed_pos.time) >= (int(time.time()) - 3600) and closed_pos.contract == symbol:
                                    if (closed_pos.side == 'long' and side == 'buy') or (
                                            closed_pos.side == 'short' and side == 'sell'):
                                        total_profit = float(closed_pos.pnl) if hasattr(closed_pos, 'pnl') else 0.0
                                        total_fees = float(closed_pos.fee) if hasattr(closed_pos, 'fee') else 0.0
                                        break
                        except Exception as e:
                            logger.error(f"Пользователь {user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")
                            # Если не удалось получить с биржи, рассчитываем вручную
                            if side == 'buy':
                                total_profit = (current_price - entry_price) * actual_qty
                            else:
                                total_profit = (entry_price - current_price) * actual_qty

                        pnl_emoji = "🟢" if total_profit >= 0 else "🔴"
                        pnl_text = "Прибыль" if total_profit >= 0 else "Убыток"

                        # Рассчитываем процент прибыли по margin
                        margin = 0
                        try:
                            positions = gate.futures_api.list_positions(settle='usdt')
                            for pos in positions:
                                if pos.contract == symbol and (
                                        (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                                    margin = float(pos.margin)
                                    break
                        except:
                            pass
                        profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0

                        update_trade_status(trade['trade_id'], "CLOSED", close_price=current_price,
                                            close_order_id=order_id, close_reason="manual", pnl=total_profit,
                                            fees=total_fees)

                        # Получаем текущий баланс и баланс при открытии
                        current_balance = gate.get_balance_usdt()

                        # Получаем баланс при открытии из базы данных
                        balance_at_open = None
                        if open_trades:
                            with get_db_connection() as conn:
                                cursor = conn.cursor()
                                cursor.execute("SELECT balance_at_open FROM trades WHERE trade_id = ?",
                                               (open_trades[0]['trade_id'],))
                                row = cursor.fetchone()
                                if row is not None and row[0] is not None:
                                    balance_at_open = row[0]

                        # Рассчитываем изменение баланса
                        balance_change = 0.0
                        # Изменение баланса равно PnL сделки
                        balance_change = total_profit
                        balance_change_percentage = (
                                    balance_change / balance_at_open * 100) if balance_at_open is not None and balance_at_open > 0 else 0.0

                        # Отправляем подробное сообщение с эмодзи
                        side_emoji = "📈" if side == 'buy' else "📉"
                        with message_lock:
                            msg_key = (user_id, symbol, side, 'close_manual', int(time.time() // 60))
                            if msg_key not in sent_messages:
                                bot.send_message(message.chat.id,
                                                 f"{side_emoji} Закрыта позиция {side} для {symbol}\n"
                                                 f"💰 Вход: {entry_price:.4f} | Выход: {current_price:.4f}\n"
                                                 f"{pnl_emoji} {pnl_text}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%)\n"
                                                 f"💳 Баланс: {current_balance:.2f} USDT ({balance_change:+.2f} USDT, {balance_change_percentage:+.2f}%)\n"
                                                 f"📋 Причина: Команда /close")
                                sent_messages.add(msg_key)
                    else:
                        bot.send_message(message.chat.id, f"❌ Ошибка закрытия {side} для {symbol}")
                else:
                    # Позиция на бирже, но не в базе — закрываем напрямую
                    order_id, actual_qty = gate.close_position_enhanced(symbol, side, qty, reason="manual_no_db")
                    if order_id:
                        current_price = gate.get_current_price(symbol) or entry_price

                        # Получаем PnL с биржи
                        total_profit = 0.0
                        total_fees = 0.0
                        try:
                            closed_positions = gate.futures_api.list_position_close(settle='usdt', contract=symbol)
                            for closed_pos in closed_positions:
                                if int(closed_pos.time) >= (int(time.time()) - 3600) and closed_pos.contract == symbol:
                                    if (closed_pos.side == 'long' and side == 'buy') or (
                                            closed_pos.side == 'short' and side == 'sell'):
                                        total_profit = float(closed_pos.pnl) if hasattr(closed_pos, 'pnl') else 0.0
                                        total_fees = float(closed_pos.fee) if hasattr(closed_pos, 'fee') else 0.0
                                        break
                        except Exception as e:
                            logger.error(f"Пользователь {user_id}: Ошибка получения прибыли для {symbol}: {str(e)}")
                            # Если не удалось получить с биржи, рассчитываем вручную
                            if side == 'buy':
                                total_profit = (current_price - entry_price) * actual_qty
                            else:
                                total_profit = (entry_price - current_price) * actual_qty

                        pnl_emoji = "🟢" if total_profit >= 0 else "🔴"
                        pnl_text = "Прибыль" if total_profit >= 0 else "Убыток"

                        # Рассчитываем процент прибыли по margin
                        margin = 0
                        try:
                            positions = gate.futures_api.list_positions(settle='usdt')
                            for pos in positions:
                                if pos.contract == symbol and (
                                        (pos.size > 0 and side == 'buy') or (pos.size < 0 and side == 'sell')):
                                    margin = float(pos.margin)
                                    break
                        except:
                            pass
                        profit_percentage = (total_profit / margin * 100) if margin > 0 else 0.0

                        # Создаём запись о закрытии для лога
                        trade_id = add_trade(
                            user_id, symbol, side, entry_price, actual_qty, int(time.time()), "CLOSED", '1h',
                            close_reason="manual_no_db", signal_id=None
                        )
                        # Обновляем статус с дополнительными данными
                        update_trade_status(trade_id, "CLOSED", close_price=current_price, close_order_id=order_id,
                                            pnl=total_profit, fees=total_fees)

                        # Получаем текущий баланс
                        current_balance = gate.get_balance_usdt()

                        # Для позиций, которых не было в базе, не можем получить баланс при открытии
                        # Изменение баланса равно PnL сделки
                        balance_change = total_profit

                        # Отправляем подробное сообщение с эмодзи
                        side_emoji = "📈" if side == 'buy' else "📉"
                        with message_lock:
                            msg_key = (user_id, symbol, side, 'close_manual_no_db', int(time.time() // 60))
                            if msg_key not in sent_messages:
                                bot.send_message(message.chat.id,
                                                 f"{side_emoji} Закрыта позиция {side} для {symbol} (позиция не была в базе)\n"
                                                 f"💰 Вход: {entry_price:.4f} | Выход: {current_price:.4f}\n"
                                                 f"{pnl_emoji} {pnl_text}: {total_profit:+.2f} USDT ({profit_percentage:+.2f}%)\n"
                                                 f"💳 Баланс: {current_balance:.2f} USDT ({balance_change:+.2f} USDT)\n"
                                                 f"📋 Причина: Команда /close")
                                sent_messages.add(msg_key)
                    else:
                        bot.send_message(message.chat.id, f"❌ Ошибка закрытия {side} для {symbol}")
                return
        bot.send_message(message.chat.id, f"ℹ️ Нет открытых позиций для {symbol} на бирже.")
    except Exception as e:
        logger.error(f"Пользователь {user_id}: Ошибка проверки позиций для {symbol}: {str(e)}")
        bot.send_message(message.chat.id, f"❌ Ошибка проверки позиций для {symbol}: {str(e)}")
    send_open_positions_status(user_id, message.chat.id)


def start_trailing_for_all_open_positions(user_id):
    user_data = get_user_data(user_id)
    if not user_data or not user_data['api_key']:
        return
    open_trades = get_open_trades(user_id)
    for trade in open_trades:
        symbol = trade['symbol']
        side = trade['side']
        # Проверяем, не запущен ли уже трейлинг для этой позиции
        thread_key = (user_id, symbol, side)
        if not is_thread_alive(user_id, 'trailing', thread_key):
            start_user_trailing_thread(user_id, symbol, side)


def send_open_positions_status(user_id, chat_id=None):
    user_data = get_user_data(user_id)
    if not user_data or not user_data['api_key']:
        return
    gate = GateIO(user_data)
    open_trades = get_open_trades(user_id)
    if not open_trades:
        msg = "📊 Нет открытых позиций."
        if chat_id:
            bot.send_message(chat_id, msg)
        else:
            bot.send_message(GROUP_CHAT_ID, msg)
        return

    # Создаем красивый заголовок с разделителями
    separator = "═" * 60
    msg = f"\n{separator}\n"
    msg += f"📊 Статус для {user_id} ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}):\n"
    msg += f"💰 Свободный баланс: {gate.get_balance_usdt():.2f} USDT\n\n"
    msg += f"📈 Открытые позиции:\n"

    for i, trade in enumerate(open_trades, 1):
        symbol = trade['symbol']
        side = trade['side']
        entry_price = trade['average_entry_price'] or trade['price']
        amount = trade['amount']
        stop_price = trade.get('current_stop_price')
        trailing_active = trade.get('trailing_active', 0)
        trailing_stop_price = trade.get('trailing_stop_price')
        original_stop_price = trade.get('original_stop_price')
        timescale = trade.get('timescale', '1h')

        try:
            current_price = gate.get_current_price(symbol)
        except Exception:
            current_price = None

        pnl = None
        if current_price is not None and entry_price is not None and amount is not None:
            if side == 'buy':
                pnl = (current_price - entry_price) * amount
            else:
                pnl = (entry_price - current_price) * amount

        # Получаем конфигурацию для расчета цены активации трейлинга
        config = get_tp_config(user_id, timescale)
        trigger_price = None
        if config and entry_price:
            trigger_price = entry_price * (
                1 + config['trigger_profit_percentage'] / 100 if side == 'buy'
                else 1 - config['trigger_profit_percentage'] / 100
            )

        # Добавляем эмодзи для лучшей читаемости
        side_emoji = "📈" if side == 'buy' else "📉"
        pnl_emoji = "🟢" if pnl and pnl >= 0 else "🔴" if pnl else "⚪"
        trailing_emoji = "🟢" if trailing_active else "🔴"

        msg += f"{i}. {side_emoji} {symbol} ({side}):\n"
        msg += f"   💰 Сумма в ордере: {amount:.2f} USDT\n"
        msg += f"   🎯 Цена входа: {entry_price:.6f}\n"
        msg += f"   📊 Текущая цена: {current_price:.6f}\n" if current_price is not None else "   📊 Текущая цена: ?\n"

        if pnl is not None:
            msg += f"   {pnl_emoji} {'Прибыль' if pnl >= 0 else 'Убыток'}: {pnl:+.2f} USDT\n"

        if stop_price is not None:
            msg += f"   🛑 Стоп-лосс: {stop_price:.6f}\n"
        if trailing_stop_price is not None:
            msg += f"   🎯 Трейлинг-стоп: {trailing_stop_price:.6f}\n"
        if trigger_price is not None:
            msg += f"   ⚡ Цена активации трейлинга: {trigger_price:.6f}\n"
        if trailing_active:
            msg += f"   {trailing_emoji} Трейлинг: Активен\n"
            trailing_status_text = "Активен"
        else:
            msg += f"   {trailing_emoji} Трейлинг: Неактивен (ожидает активации)\n"
            trailing_status_text = "Неактивен (ожидает активации)"
        msg += "\n"

        # Дублируем в консоль
        logger.info(
            f"Позиция {i}: {side_emoji} {symbol} ({side}) | Сумма: {amount:.2f} USDT | Вход: {entry_price:.6f} | "
            f"Текущая: {current_price if current_price is not None else '?'} | Стоп-лосс: {stop_price if stop_price is not None else '?'} | "
            f"Трейлинг-стоп: {trailing_stop_price if trailing_stop_price is not None else '?'} | "
            f"Цена активации трейлинга: {trigger_price if trigger_price is not None else '?'} | "
            f"Трейлинг: {trailing_status_text}")

    msg += f"{separator}"

    if chat_id:
        bot.send_message(chat_id, msg)
    else:
        bot.send_message(GROUP_CHAT_ID, msg)


# === КОНТРОЛЬ И ПЕРЕЗАПУСК ПОТОКОВ ===
def get_thread_status(user_id, thread_type, thread_key=None):
    """
    Получает статус потока для пользователя.
    """
    if user_id not in thread_status:
        return 'stopped'

    if thread_type == 'trailing':
        if 'trailing' not in thread_status[user_id]:
            return 'stopped'
        return thread_status[user_id]['trailing'].get(thread_key, 'stopped')
    else:
        return thread_status[user_id].get(thread_type, 'stopped')


def set_thread_status(user_id, thread_type, status, thread_key=None):
    """
    Устанавливает статус потока для пользователя.
    """
    if user_id not in thread_status:
        thread_status[user_id] = {}

    if thread_type == 'trailing':
        if 'trailing' not in thread_status[user_id]:
            thread_status[user_id]['trailing'] = {}
        thread_status[user_id]['trailing'][thread_key] = status
    else:
        thread_status[user_id][thread_type] = status


def is_thread_alive(user_id, thread_type, thread_key=None):
    """
    Проверяет, жив ли поток.
    """
    if user_id not in user_threads:
        return False

    if thread_type == 'trailing':
        if 'trailing' not in user_threads[user_id]:
            return False
        thread = user_threads[user_id]['trailing'].get(thread_key)
    else:
        thread = user_threads[user_id].get(thread_type)

    return thread is not None and thread.is_alive()


def start_user_signals_thread(user_id):
    """
    Запускает поток обработки сигналов для пользователя.
    """
    if is_thread_alive(user_id, 'signals'):
        logger.info(f"Поток сигналов для пользователя {user_id} уже активен")
        return

    thread = Thread(target=process_signals_from_file, args=(user_id,), daemon=True)
    thread.start()

    if user_id not in user_threads:
        user_threads[user_id] = {}
    user_threads[user_id]['signals'] = thread
    set_thread_status(user_id, 'signals', 'running')
    logger.info(f"Запущен поток сигналов для пользователя {user_id}")


def start_user_sync_thread(user_id):
    """
    Запускает поток синхронизации для пользователя.
    """
    if is_thread_alive(user_id, 'sync'):
        logger.info(f"Поток синхронизации для пользователя {user_id} уже активен")
        return

    thread = Thread(target=start_periodic_sync, args=(user_id,), daemon=True)
    thread.start()

    if user_id not in user_threads:
        user_threads[user_id] = {}
    user_threads[user_id]['sync'] = thread
    set_thread_status(user_id, 'sync', 'running')
    logger.info(f"Запущен поток синхронизации для пользователя {user_id}")


def start_user_trailing_thread(user_id, symbol, side):
    """
    Запускает трейлинг для конкретной позиции пользователя.
    """
    thread_key = (user_id, symbol, side)

    # Проверяем, не запущен ли уже трейлинг для этой позиции
    if is_thread_alive(user_id, 'trailing', thread_key):
        logger.info(f"Трейлинг для {symbol} ({side}) пользователя {user_id} уже активен")
        return

    user_data = get_user_data(user_id)
    if not user_data or not user_data['api_key']:
        logger.warning(f"Не удалось запустить трейлинг для пользователя {user_id}: нет API ключей")
        return

    gate = GateIO(user_data)
    
    # Используем новый менеджер трейлинг-стопа
    gate.trailing_stop_manager.start_monitoring(symbol, side)

    # Обновляем user_threads для отслеживания состояния
    if user_id not in user_threads:
        user_threads[user_id] = {}
    if 'trailing' not in user_threads[user_id]:
        user_threads[user_id]['trailing'] = {}
        
    # Создаем поток-наблюдатель, который будет проверять состояние трейлинга
    import threading
    import time
    
    def trailing_observer():
        """Наблюдатель за состоянием трейлинга"""
        try:
            # Пока трейлинг активен в TrailingStopManager, поток жив
            while True:
                # Проверяем, активен ли трейлинг в менеджере
                if hasattr(gate, 'trailing_stop_manager') and gate.trailing_stop_manager:
                    if thread_key in gate.trailing_stop_manager.trailing_threads:
                        thread = gate.trailing_stop_manager.trailing_threads[thread_key]
                        if thread.is_alive():
                            time.sleep(1)  # Проверяем каждую секунду
                            continue
                
                # Если трейлинг завершен, выходим из цикла
                break
        except Exception as e:
            logger.error(f"Ошибка в наблюдателе трейлинга для {symbol} ({side}): {e}")
    
    thread = threading.Thread(target=trailing_observer, daemon=True)
    thread.start()
    
    user_threads[user_id]['trailing'][thread_key] = thread
    set_thread_status(user_id, 'trailing', 'running', thread_key)
    
    logger.info(f"Запущен трейлинг для {symbol} ({side}) пользователя {user_id}")


def restart_trailing_threads_for_user(user_id):
    """Перезапускает только потоки трейлинга для пользователя после импорта новых настроек"""
    try:
        user_data = get_user_data(user_id)
        if not user_data or not user_data.get('is_trading'):
            logger.info(f"Пользователь {user_id} не торгует, пропускаем перезапуск трейлингов")
            return
        
        logger.info(f"🔄 Перезапуск потоков трейлинга для пользователя {user_id}...")
        
        # Останавливаем все текущие потоки трейлинга
        if user_id in user_threads and 'trailing' in user_threads[user_id]:
            active_threads = list(user_threads[user_id]['trailing'].keys())
            for thread_key in active_threads:
                try:
                    thread = user_threads[user_id]['trailing'][thread_key]
                    if thread.is_alive():
                        logger.info(f"Останавливаем поток трейлинга: {thread_key}")
                        # Потоки демоны, они завершаются сами
                        pass
                    del user_threads[user_id]['trailing'][thread_key]
                except Exception as e:
                    logger.error(f"Ошибка остановки потока {thread_key}: {e}")
        
        # Получаем все открытые позиции и запускаем новые потоки с новыми настройками
        open_trades = get_open_trades(user_id)
        restarted_count = 0
        
        for trade in open_trades:
            symbol = trade['symbol']
            side = trade['side']
            thread_key = (user_id, symbol, side)
            
            logger.info(f"Запускаем новый поток трейлинга для {symbol} ({side}) с новыми настройками")
            start_user_trailing_thread(user_id, symbol, side)
            restarted_count += 1
        
        logger.info(f"✅ Перезапущено {restarted_count} потоков трейлинга для пользователя {user_id}")
        
    except Exception as e:
        logger.error(f"Ошибка перезапуска потоков трейлинга для пользователя {user_id}: {e}")
        raise e


def restart_user_threads(user_id):
    """
    Умно перезапускает потоки пользователя только если они неактивны.
    """
    try:
        user_data = get_user_data(user_id)
        if not user_data or not user_data.get('is_trading'):
            logger.info(f"Пользователь {user_id} не торгует, пропускаем перезапуск потоков")
            return

        # Проверяем и перезапускаем поток сигналов
        if not is_thread_alive(user_id, 'signals'):
            logger.info(f"Перезапуск потока сигналов для пользователя {user_id}")
            start_user_signals_thread(user_id)

        # Проверяем и перезапускаем поток синхронизации
        if not is_thread_alive(user_id, 'sync'):
            logger.info(f"Перезапуск потока синхронизации для пользователя {user_id}")
            start_user_sync_thread(user_id)

        # Проверяем и перезапускаем потоки трейлинга для всех открытых позиций
        open_trades = get_open_trades(user_id)
        for trade in open_trades:
            symbol = trade['symbol']
            side = trade['side']
            thread_key = (user_id, symbol, side)

            if not is_thread_alive(user_id, 'trailing', thread_key):
                logger.info(f"Перезапуск потока трейлинга для {symbol} ({side}) пользователя {user_id}")
                start_user_trailing_thread(user_id, symbol, side)

        # Очищаем неактивные потоки трейлинга
        if user_id in user_threads and 'trailing' in user_threads[user_id]:
            active_trades = {(trade['symbol'], trade['side']) for trade in open_trades}
            for thread_key in list(user_threads[user_id]['trailing'].keys()):
                if len(thread_key) == 3:  # (user_id, symbol, side)
                    _, symbol, side = thread_key
                    if (symbol, side) not in active_trades:
                        # Позиция закрыта, удаляем поток
                        if thread_key in user_threads[user_id]['trailing']:
                            del user_threads[user_id]['trailing'][thread_key]
                        if user_id in thread_status and 'trailing' in thread_status[user_id]:
                            if thread_key in thread_status[user_id]['trailing']:
                                del thread_status[user_id]['trailing'][thread_key]
                        logger.info(f"Удален неактивный поток трейлинга для {symbol} ({side}) пользователя {user_id}")

        logger.info(f"Проверка потоков для пользователя {user_id} завершена")

    except Exception as e:
        logger.error(f"Ошибка при перезапуске потоков пользователя {user_id}: {str(e)}\n{traceback.format_exc()}")


def get_threads_status_report():
    """
    Возвращает отчет о статусе всех потоков.
    """
    report = "📊 Статус потоков:\n"
    for user_id in ALLOWED_USERS:
        user_data = get_user_data(user_id)
        if user_data and user_data.get('is_trading'):
            report += f"\n👤 Пользователь {user_id}:\n"

            # Сигналы
            signals_status = "🟢 Активен" if is_thread_alive(user_id, 'signals') else "🔴 Неактивен"
            report += f"  📡 Сигналы: {signals_status}\n"

            # Синхронизация
            sync_status = "🟢 Активен" if is_thread_alive(user_id, 'sync') else "🔴 Неактивен"
            report += f"  🔄 Синхронизация: {sync_status}\n"

            # Трейлинг
            if user_id in user_threads and 'trailing' in user_threads[user_id]:
                trailing_count = len([t for t in user_threads[user_id]['trailing'].values() if t.is_alive()])
                report += f"  🎯 Трейлинг: {trailing_count} активных потоков\n"
            else:
                report += f"  🎯 Трейлинг: 0 активных потоков\n"

    return report


def monitor_and_restart_threads():
    """
    Каждые 3 минуты проверяет и перезапускает потоки для всех пользователей.
    """
    import threading
    import time
    while True:
        try:
            logger.info("🔄 Начинаю проверку потоков...")
            for user_id in ALLOWED_USERS:
                user_data = get_user_data(user_id)
                if user_data and user_data.get('is_trading'):
                    restart_user_threads(user_id)

            # Логируем статус потоков
            status_report = get_threads_status_report()
            logger.info(f"Проверка потоков завершена:\n{status_report}")

        except Exception as e:
            logger.error(f"Ошибка в мониторинге потоков: {str(e)}\n{traceback.format_exc()}")

        time.sleep(180)  # 3 минуты

@bot.message_handler(func=lambda message: states.get(message.from_user.id) == "await_reset_confirm")
def handle_reset_confirm(message):
    user_id = message.from_user.id
    text = message.text.strip().lower()
    if text == 'да':
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
            cursor.execute("DELETE FROM trades WHERE user_id = ?", (user_id,))
            cursor.execute("DELETE FROM tp_config WHERE user_id = ?", (user_id,))
            conn.commit()
        logger.info(f"Пользователь {user_id}: выполнен полный сброс через /reset (с подтверждением)")
        # Очищаем user_reg_data и состояние
        if user_id in user_reg_data:
            del user_reg_data[user_id]
        states[user_id] = "await_account_type_template"
        bot.send_message(
            message.chat.id,
            f"Настройки сброшены.\n\nВыберите тип счета:\n- 💰 Реальный счет: для торговли реальными средствами 💵\n- 🧪 Демо счет: для тестирования 🧬\nОтветьте 'реальный' или 'демо'.",
            parse_mode='HTML'
        )
    elif text == 'нет':
        bot.send_message(message.chat.id, "Сброс отменён.")
        if user_id in states:
            del states[user_id]
    else:
        bot.send_message(message.chat.id, "Пожалуйста, ответьте 'да' для подтверждения или 'нет' для отмены.")



# Запуск бота и планировщика
if __name__ == "__main__":
    # Создание необходимых файлов при запуске
    create_required_files()

    while True:
        try:
            # Запуск планировщика отчетов
            Thread(target=schedule_reports, daemon=True).start()

            # Запуск контроля и перезапуска потоков
            Thread(target=monitor_and_restart_threads, daemon=True).start()

            # Запуск обработки сигналов и трейлинга для каждого пользователя
            for user_id in ALLOWED_USERS:
                user_data = get_user_data(user_id)
                if user_data and user_data['is_trading']:
                    start_user_signals_thread(user_id)
                    start_user_sync_thread(user_id)
                    start_trailing_for_all_open_positions(user_id)

            logger.info("Бот запущен")
            bot.polling(none_stop=True, timeout=60)
        except Exception as e:
            logger.error(f"Ошибка запуска бота: {str(e)}")
            time.sleep(10)  # Ждем 10 секунд перед перезапуском
            logger.info("Попытка перезапуска бота")


# === ОБРАБОТЧИКИ /reset ===
@bot.message_handler(commands=['reset'])
def reset_command(message):
    user_id = message.from_user.id
    bot.send_message(
        message.chat.id,
        "Вы уверены, что хотите полностью сбросить все настройки и начать регистрацию заново?\n\n<b>Ответьте 'да' для подтверждения или 'нет' для отмены.</b>",
        parse_mode='HTML'
    )
    states[user_id] = "await_reset_confirm"
