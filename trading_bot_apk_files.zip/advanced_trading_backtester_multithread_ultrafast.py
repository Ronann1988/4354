#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import itertools
from typing import Dict, List, Tuple, Optional
import logging
import ccxt
import time
import sys
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import threading
from functools import partial
import multiprocessing
import os

# Импортируем компоненты из торгового бота для использования его логики
try:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from traiding_bot import GateIO, get_tp_config, get_user_data, TrailingStopManager
    HAS_TRADING_BOT = True
    print("✅ Логика торгового бота доступна для использования")
    
    # После импорта устанавливаем уровень логирования на INFO
    logging.getLogger('trading-bot').setLevel(logging.INFO)
    logging.getLogger().setLevel(logging.INFO)
    
except ImportError as e:
    HAS_TRADING_BOT = False
    GateIO = None
    get_tp_config = None
    get_user_data = None
    TrailingStopManager = None
    print(f"⚠️ Логика торгового бота недоступна: {e}")

try:
    import yfinance as yf
    HAS_YFINANCE = True
except ImportError:
    HAS_YFINANCE = False
    logging.warning("yfinance не установлен. Будет использоваться только CCXT. Работа в стандартном режиме")

# 🚀 ULTRA FAST BACKTESTER PATCH - Решение проблем с API
try:
    from ultra_fast_backtester import ApiBypassManager
    HAS_ULTRA_FAST = True
    print("✅ Ultra Fast Backtester активирован!")
except ImportError:
    HAS_ULTRA_FAST = False
    ApiBypassManager = None
    print("⚠️ Работаем в стандартном режиме")

# Настройка логирования - только INFO и выше, без DEBUG
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('advanced-trading-backtester')

# Настройка логирования - только INFO и выше, без DEBUG
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('advanced-trading-backtester')

# Устанавливаем уровень логирования для всех существующих логгеров
logging.getLogger('trading-bot').setLevel(logging.INFO)


# Отфильтровываем DEBUG сообщения от торгового бота
class InfoFilter(logging.Filter):
    def filter(self, record):
        return record.levelno >= logging.INFO


# Применяем фильтр ко всем логгерам
for handler in logging.root.handlers:
    handler.addFilter(InfoFilter())

class ProgressBar:
    """Класс для отображения красивой полосы прогресса"""
    
    def __init__(self, total: int, prefix: str = '', suffix: str = '', length: int = 50, fill: str = '█', empty: str = '░'):
        self.total = total
        self.prefix = prefix
        self.suffix = suffix
        self.length = length
        self.fill = fill
        self.empty = empty
        self.current = 0
        self.start_time = time.time()
        self.last_update_time = 0  # Для контроля частоты обновлений
    
    def update(self, current: Optional[int] = None, message: str = '', force_update: bool = False):
        """Обновить полосу прогресса"""
        if current is not None:
            self.current = current
        else:
            self.current += 1
        
        # Контроль частоты обновлений (не чаще чем каждые 0.1 секунды)
        current_time = time.time()
        if not force_update and (current_time - self.last_update_time) < 0.1 and self.current < self.total:
            return
        
        self.last_update_time = current_time
        
        # Исправляем ошибку деления на ноль
        if self.total == 0:
            percent = 100.0
            filled_length = self.length
        else:
            percent = min(100, (self.current / self.total) * 100)
            filled_length = int(self.length * self.current // self.total)
        
        bar = self.fill * filled_length + self.empty * (self.length - filled_length)
        
        # Расчет времени
        elapsed = current_time - self.start_time
        if self.current > 0 and self.total > 0:
            eta = elapsed * (self.total - self.current) / self.current
            eta_str = f" ETA:{int(eta)}s" if eta > 1 else ""
        else:
            eta_str = ""
        
        # Формирование более компактной строки прогресса
        if message:
            # Ограничиваем длину сообщения
            short_message = message[:15] if len(message) > 15 else message
            progress_line = f'\r{self.prefix} |{bar}| {percent:.1f}% ({self.current}/{self.total}){eta_str} {short_message}'
        else:
            progress_line = f'\r{self.prefix} |{bar}| {percent:.1f}% ({self.current}/{self.total}){eta_str}'
        
        # Ограничиваем максимальную длину строки до 100 символов
        max_length = 100
        if len(progress_line) > max_length:
            progress_line = progress_line[:max_length-3] + '...'
        
        # Очищаем линию до фиксированной длины
        if len(progress_line) < max_length:
            progress_line += ' ' * (max_length - len(progress_line))
        
        sys.stdout.write(progress_line)
        sys.stdout.flush()
    
    def finish(self, message: str = 'Завершено!'):
        """Завершить полосу прогресса"""
        elapsed = time.time() - self.start_time
        
        # Принудительно обновляем до 100%
        self.update(self.total, message, force_update=True)
        print(f'\n✅ {message} Время выполнения: {elapsed:.1f}s')

class MultiThreadBacktester:
    """Продвинутый бэктестер торгового бота с реальными историческими данными и многопоточностью"""
    
    def __init__(self, config_file: str, signals_file: str):
        """Инициализация бэктестера"""
        self.config = self.load_config(config_file)
        self.signals = self.load_signals(signals_file)
        self.results = {}
        self.exchange = self.init_exchange()
        
        # Настройки стратегий (добавляем для совместимости с order_chart_generator)
        self.strategies_config = self.config.get('strategies', {
            'BB': {
                'width_lookback_period': 15,
                'num_std_dev': 2.0
            },
            'EMA': {
                'ema_period1': 3,
                'ema_period2': 20
            },
            'VOLUM': {
                'volume_average_window': 20
            },
            'STOH': {
                'stoch_k': 14,
                'stoch_d': 3
            }
        })
        
        # Настройки многопоточности
        self.max_workers = min(8, multiprocessing.cpu_count())  # Максимум 8 потоков
        self.data_cache = {}  # Кэш для исторических данных
        self.cache_lock = threading.Lock()  # Блокировка для потокобезопасности
        
        # Инициализация отслеживания сгенерированных графиков
        self.generated_trades_hash = self._load_generated_trades_hash()
        
        logger.debug("🚀 Продвинутый торговый бэктестер инициализирован")
        logger.debug(f"📊 Начальный баланс: {self.config['backtest']['initial_balance']} USDT")
        logger.debug(f"📈 Сигналов загружено: {len(self.signals)}")
        logger.debug(f"🧠 Используется {self.max_workers} потоков для обработки")
    
    def load_config(self, config_file: str) -> Dict:
        """Загрузка конфигурации"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Ошибка загрузки конфигурации: {e}")
            raise
    
    def init_exchange(self):
        """Инициализация биржи для получения исторических данных (Ultra Fast версия)"""
        
        # 🚀 ULTRA FAST: Если есть API bypass, биржи не критичны
        if HAS_ULTRA_FAST:
            logger.info("🚀 Ultra Fast режим: биржи опциональны")
        
        try:
            # Пробуем разные биржи, но не падаем если недоступны
            exchanges = [
                ('gateio', ccxt.gateio),
                ('binance', ccxt.binance),
                ('bybit', ccxt.bybit),
                ('okx', ccxt.okx)
            ]
            
            for name, exchange_class in exchanges:
                try:
                    exchange = exchange_class({
                        'rateLimit': 2000,  # Увеличиваем лимит для стабильности
                        'enableRateLimit': True,
                        'timeout': 15000,   # Уменьшаем таймаут
                        'options': {
                            'defaultType': 'spot'
                        }
                    })
                    # Быстрая проверка без load_markets (может быть заблокирован)
                    logger.info(f"✅ Биржа {name.upper()} подключена")
                    return exchange
                except Exception as ex:
                    logger.warning(f"⚠️ {name} недоступна: {str(ex)[:100]}...")
                    continue
            
            if HAS_ULTRA_FAST:
                logger.info("🚀 Биржи недоступны, но Ultra Fast решит проблему!")
            else:
                logger.error("❌ Биржи недоступны и нет Ultra Fast модуля")
            
            return None
            
        except Exception as e:
            logger.error(f"Ошибка инициализации бирж: {e}")
            return None
    
    def load_signals(self, signals_file: str) -> List[Dict]:
        """Загрузка сигналов из файла с улучшенным парсингом"""
        signals = []
        try:
            with open(signals_file, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                        
                    try:
                        # Пример строки: "Стратегия: BB Направление: Buy Символ: ETH/USDT Время: 2025-09-20 16:35:00 (1m)"
                        # Разбиваем по ключевым словам
                        
                        # Ищем стратегию
                        strategy = None
                        if 'Стратегия:' in line:
                            strategy_part = line.split('Стратегия:')[1].split('Направление:')[0].strip()
                            strategy = strategy_part
                        
                        # Ищем направление
                        direction = None
                        if 'Направление:' in line:
                            direction_part = line.split('Направление:')[1].split('Символ:')[0].strip()
                            direction = direction_part.lower()
                            # Нормализуем направление
                            if direction in ['buy', 'покупка', 'long']:
                                direction = 'buy'
                            elif direction in ['sell', 'продажа', 'short']:
                                direction = 'sell'
                        
                        # Ищем символ
                        symbol = None
                        if 'Символ:' in line:
                            symbol_part = line.split('Символ:')[1].split('Время:')[0].strip()
                            symbol = symbol_part
                        
                        # Ищем время и таймфрейм
                        timestamp = None
                        timeframe = None
                        if 'Время:' in line:
                            time_part = line.split('Время:')[1].strip()
                            # Пример: "2025-09-20 16:35:00 (1m)"
                            if '(' in time_part and ')' in time_part:
                                time_str = time_part.split('(')[0].strip()
                                timeframe = time_part.split('(')[1].split(')')[0].strip()
                                
                                try:
                                    timestamp = datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
                                except ValueError:
                                    # Пробуем другие форматы
                                    try:
                                        timestamp = datetime.strptime(time_str, '%d.%m.%Y %H:%M:%S')
                                    except ValueError:
                                        timestamp = datetime.strptime(time_str, '%Y-%m-%d %H:%M')
                        
                        # Проверяем, что все нужные данные получены
                        if strategy and direction and symbol and timestamp and timeframe:
                            signals.append({
                                'strategy': strategy,
                                'direction': direction,
                                'symbol': symbol,
                                'timestamp': timestamp,
                                'timeframe': timeframe
                            })
                            logger.debug(f"Парсинг сигнала: {strategy} {direction} {symbol} {timestamp} {timeframe}")
                        else:
                            logger.warning(f"Неполные данные в строке {line_num}: {line}")
                            logger.debug(f"strategy={strategy}, direction={direction}, symbol={symbol}, timestamp={timestamp}, timeframe={timeframe}")
                            
                    except Exception as e:
                        logger.warning(f"Ошибка парсинга строки {line_num}: {line} - {e}")
                        continue
            
            logger.debug(f"✅ Загружено {len(signals)} сигналов")
            
            # Выводим пример первого сигнала для отладки
            if signals:
                first_signal = signals[0]
                logger.debug(f"Пример сигнала: {first_signal['strategy']} | {first_signal['direction']} | {first_signal['symbol']} | {first_signal['timestamp']} | {first_signal['timeframe']}")
            
            return signals
            
        except Exception as e:
            logger.error(f"Ошибка загрузки сигналов: {e}")
            return []
    
    def _load_generated_trades_hash(self):
        """Загрузка хэшей сгенерированных графиков из файла"""
        try:
            if os.path.exists('generated_trades_hash.json'):
                with open('generated_trades_hash.json', 'r', encoding='utf-8') as f:
                    hash_list = json.load(f)
                    return set(hash_list)
            else:
                return set()
        except Exception as e:
            logger.warning(f"Ошибка загрузки generated_trades_hash: {e}")
            return set()
    
    def _save_generated_trades_hash(self):
        """Сохранение хэшей сгенерированных графиков в файл"""
        try:
            with open('generated_trades_hash.json', 'w', encoding='utf-8') as f:
                json.dump(list(self.generated_trades_hash), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"Ошибка сохранения generated_trades_hash: {e}")
    
    def fetch_historical_data(self, symbol: str, timeframe: str, start_time: Optional[datetime] = None, end_time: Optional[datetime] = None, show_progress: bool = True, days_limit: Optional[int] = None) -> Optional[pd.DataFrame]:
        """Получение исторических данных (Ultra Fast версия)
        
        Args:
            symbol: Символ для получения данных
            timeframe: Таймфрейм данных
            start_time: Начальное время (опционально)
            end_time: Конечное время (опционально)
            show_progress: Показывать прогресс выполнения
            days_limit: Ограничение по количеству дней назад от текущего времени (опционально)
        """
        # Если указан days_limit, вычисляем start_time и end_time
        if days_limit is not None:
            end_time = datetime.now()
            start_time = end_time - timedelta(days=days_limit)
        
        # Проверяем, что start_time и end_time определены
        if start_time is None or end_time is None:
            raise ValueError("Должны быть указаны start_time и end_time или days_limit")
        
        # 🚀 ULTRA FAST: Пробуем сначала наш обход API
        if HAS_ULTRA_FAST and ApiBypassManager is not None:
            try:
                if not hasattr(self, 'api_bypass') or self.api_bypass is None:
                    self.api_bypass = ApiBypassManager()
                
                data = self.api_bypass.get_data_with_fallback(symbol, timeframe, start_time, end_time)
                if data is not None and not data.empty:
                    if show_progress:
                        print(f"🚀 Ultra Fast: {symbol} {timeframe} ({len(data)} баров)")
                    return data
            except Exception as e:
                if show_progress:
                    print(f"⚠️ Ultra Fast временно недоступен: {e}")
        
        # Резервные методы (оригинальный код)
        if self.exchange:
            data = self.fetch_data_ccxt(symbol, timeframe, start_time, end_time, show_progress)
            if data is not None and not data.empty:
                return data
        
        if show_progress:
            print(f"\n🔄 Переход на резервные источники...")
        data = self.fetch_data_yfinance(symbol, timeframe, start_time, end_time)
        if data is not None and not data.empty:
            if show_progress:
                print(f"✅ Yahoo Finance: ({len(data)} баров)")
            return data
        
        if show_progress:
            print(f"\n🧪 Генерирую реалистичные данные для {symbol}...")
        synthetic_data = self.generate_synthetic_data(symbol, timeframe, start_time, end_time)
        if show_progress and synthetic_data is not None:
            print(f"✅ Синтетические данные: ({len(synthetic_data)} баров)")
        return synthetic_data
    
    def fetch_data_ccxt(self, symbol: str, timeframe: str, start_time: datetime, end_time: datetime, show_progress: bool = True) -> Optional[pd.DataFrame]:
        """Получение данных через CCXT"""
        if not self.exchange:
            return None
            
        try:
            # Нормализуем символ для разных бирж
            normalized_symbol = self.normalize_symbol(symbol)
            
            # Проверяем, что символ существует на бирже
            if hasattr(self.exchange, 'markets') and self.exchange.markets and normalized_symbol not in self.exchange.markets:
                if show_progress:
                    logger.warning(f"⚠️ Символ {normalized_symbol} не найден на бирже")
                return None
            
            # Конвертация времени в миллисекунды
            start_ms = int(start_time.timestamp() * 1000)
            end_ms = int(end_time.timestamp() * 1000)
            
            all_data = []
            current_since = start_ms
            max_attempts = 10  # Максимум 10 попыток
            attempts = 0
            progress = None
            current_request = 0
            
            if show_progress:
                # Оцениваем количество запросов
                time_diff = end_ms - start_ms
                timeframe_ms = {
                    '1m': 60 * 1000,
                    '5m': 5 * 60 * 1000,
                    '15m': 15 * 60 * 1000,
                    '30m': 30 * 60 * 1000,
                    '1h': 60 * 60 * 1000
                }.get(timeframe, 5 * 60 * 1000)
                
                estimated_requests = max(1, min(10, time_diff // (1000 * timeframe_ms)))
                progress = ProgressBar(
                    total=estimated_requests,
                    prefix=f'📈 Загрузка {normalized_symbol} ({timeframe})',
                    length=30
                )
            
            while current_since < end_ms and attempts < max_attempts:
                try:
                    # Добавляем паузу между запросами
                    if attempts > 0:
                        time.sleep(2)
                    
                    ohlcv = self.exchange.fetch_ohlcv(
                        symbol=normalized_symbol, 
                        timeframe=timeframe, 
                        since=current_since, 
                        limit=1000
                    )
                    
                    if not ohlcv:
                        if show_progress and progress:
                            progress.update(message='Пустой ответ')
                        break
                    
                    all_data.extend(ohlcv)
                    current_since = ohlcv[-1][0] + 1
                    
                    if show_progress and progress:
                        current_request += 1
                        progress.update(current_request, f'Загружено {len(all_data)} свечей')
                    
                    if ohlcv[-1][0] >= end_ms:
                        break
                        
                except Exception as e:
                    attempts += 1
                    if show_progress and progress:
                        if attempts < max_attempts:
                            progress.update(message=f'Ошибка, повтор {attempts}/{max_attempts}')
                        else:
                            progress.update(message=f'Макс. попыток достигнуто')
                    if attempts >= max_attempts:
                        break
                    time.sleep(5)  # Пауза перед повторной попыткой
            
            if show_progress and progress:
                if all_data:
                    progress.finish(f'Загружено {len(all_data)} свечей')
                else:
                    progress.finish('Нет данных')
            
            if not all_data:
                return None
            
            # Создание DataFrame
            df = pd.DataFrame(all_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Удаление дубликатов и сортировка
            df = df[~df.index.duplicated(keep='last')].sort_index()
            
            # Фильтрация по времени
            df = df[(df.index >= start_time) & (df.index <= end_time)]
            
            # Ensure we return a DataFrame, not a Series
            if isinstance(df, pd.DataFrame):
                return df
            else:
                return pd.DataFrame(df)
            
        except Exception as e:
            if show_progress:
                logger.warning(f"Ошибка получения данных через CCXT для {symbol}: {e}")
            return None
    
    def normalize_symbol(self, symbol: str) -> str:
        """Нормализация символа для разных бирж"""
        try:
            # Преобразуем ETH/USDT -> ETH/USDT (оставляем как есть)
            if '/' in symbol:
                return symbol.upper()
            
            # Если нет слэша, пробуем добавить USDT
            if symbol.upper().endswith('USDT'):
                return symbol.upper()
            else:
                return f"{symbol.upper()}/USDT"
                
        except Exception as e:
            logger.warning(f"Ошибка нормализации символа {symbol}: {e}")
            return symbol
    
    def fetch_data_yfinance(self, symbol: str, timeframe: str, start_time: datetime, end_time: datetime) -> Optional[pd.DataFrame]:
        """Альтернативное получение данных через yfinance"""
        if not HAS_YFINANCE:
            return None
            
        try:
            import yfinance as yf
            
            # Преобразуем символ для Yahoo Finance
            if symbol == 'ETH/USDT':
                yf_symbol = 'ETH-USD'
            elif symbol == 'BTC/USDT':
                yf_symbol = 'BTC-USD'
            else:
                # Общая конвертация
                yf_symbol = symbol.replace('/USDT', '-USD').replace('/', '-')
            
            # Преобразуем таймфрейм
            if timeframe == '1m':
                interval = '1m'
            elif timeframe == '5m':
                interval = '5m'
            elif timeframe == '15m':
                interval = '15m'
            elif timeframe == '30m':
                interval = '30m'
            elif timeframe == '1h':
                interval = '1h'
            else:
                logger.warning(f"Неподдерживаемый таймфрейм для yfinance: {timeframe}")
                return None
            
            # Получаем данные
            ticker = yf.Ticker(yf_symbol)
            df = ticker.history(
                start=start_time.strftime('%Y-%m-%d %H:%M:%S'),
                end=end_time.strftime('%Y-%m-%d %H:%M:%S'),
                interval=interval
            )
            
            if df.empty:
                logger.warning(f"Пустой ответ от yfinance для {yf_symbol}")
                return None
            
            # Преобразуем в нужный формат
            df = df.rename(columns={
                'Open': 'open',
                'High': 'high', 
                'Low': 'low',
                'Close': 'close',
                'Volume': 'volume'
            })
            
            # Оставляем только нужные колонки
            df = df[['open', 'high', 'low', 'close', 'volume']]
            
            logger.info(f"Загружены данные через yfinance для {yf_symbol} ({len(df)} баров)")
            
            # Ensure we return a DataFrame, not a Series
            if isinstance(df, pd.DataFrame):
                return df
            else:
                return pd.DataFrame(df)
            
        except Exception as e:
            logger.warning(f"Ошибка получения данных через yfinance: {e}")
            return None
    
    def generate_synthetic_data(self, symbol: str, timeframe: str, start_time: datetime, end_time: datetime) -> Optional[pd.DataFrame]:
        """Генерация синтетических данных для тестирования (детерминистичная)"""
        try:
            # Определяем интервал в минутах
            timeframe_minutes = {
                '1m': 1,
                '5m': 5,
                '15m': 15,
                '30m': 30,
                '1h': 60
            }.get(timeframe, 5)
            
            # Генерируем временные метки
            timestamps = []
            current_time = start_time
            while current_time <= end_time:
                timestamps.append(current_time)
                current_time += timedelta(minutes=timeframe_minutes)
            
            if not timestamps:
                return None
            
            # Базовая цена для разных символов
            if 'ETH' in symbol.upper():
                base_price = 2500.0
            elif 'BTC' in symbol.upper():
                base_price = 45000.0
            else:
                base_price = 100.0
            
            # Создаем детерминистичный seed на основе параметров
            seed_string = f"{symbol}_{timeframe}_{start_time.strftime('%Y%m%d_%H%M')}_{len(timestamps)}"
            import hashlib
            seed = int(hashlib.md5(seed_string.encode()).hexdigest()[:8], 16) % (2**31)
            
            # Генерируем свечи с детерминистичными движениями
            data = []
            current_price = base_price
            
            # Устанавливаем детерминистичный seed
            np.random.seed(seed)
            
            for i, timestamp in enumerate(timestamps):
                # Генерируем случайное изменение цены (-1% до +1%)
                price_change = np.random.normal(0, 0.005)  # Около 0.5% волатильность
                current_price *= (1 + price_change)
                
                # Генерируем OHLC
                open_price = current_price
                
                # High и Low для свечи
                high_variation = np.random.uniform(0.001, 0.01)  # 0.1% - 1%
                low_variation = np.random.uniform(0.001, 0.01)
                
                high_price = open_price * (1 + high_variation)
                low_price = open_price * (1 - low_variation)
                
                # Close может быть любым между low и high
                close_price = np.random.uniform(low_price, high_price)
                current_price = close_price  # Обновляем для следующей свечи
                
                # Объем
                volume = np.random.uniform(1000, 10000)
                
                data.append({
                    'open': open_price,
                    'high': high_price,
                    'low': low_price,
                    'close': close_price,
                    'volume': volume
                })
            
            # Создаем DataFrame
            df = pd.DataFrame(data, index=timestamps)
            df.index.name = 'timestamp'
            
            logger.info(f"Сгенерированы детерминистичные данные для {symbol} ({len(df)} баров, seed: {seed})")
            return df
            
        except Exception as e:
            logger.error(f"Ошибка генерации синтетических данных: {e}")
            return None
    
    def fetch_historical_data_parallel(self, data_requests: List[Tuple], show_progress: bool = True) -> Dict[str, pd.DataFrame]:
        """Параллельная загрузка исторических данных
        
        Args:
            data_requests: Список запросов (symbol, timeframe, start_time, end_time, cache_key)
            show_progress: Показывать прогресс
        
        Returns:
            Словарь с данными {cache_key: DataFrame}
        """
        results = {}
        
        if show_progress:
            print(f"\n🚀 Начинаем параллельную загрузку {len(data_requests)} наборов данных...")
            progress = ProgressBar(
                total=len(data_requests),
                prefix='📈 Загрузка данных',
                length=40
            )
        else:
            progress = None
        
        def load_single_dataset(request):
            """Загрузка одного набора данных с проверкой кэша"""
            symbol, timeframe, start_time, end_time, cache_key = request
            
            # Проверим кэш
            with self.cache_lock:
                if cache_key in self.data_cache:
                    return cache_key, self.data_cache[cache_key]
            
            # Загружаем данные
            data = self.fetch_historical_data(symbol, timeframe, start_time, end_time, show_progress=False)
            
            # Сохраняем в кэш
            if data is not None:
                with self.cache_lock:
                    self.data_cache[cache_key] = data
            
            return cache_key, data
        
        # Параллельная загрузка
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(load_single_dataset, request): request for request in data_requests}
            
            completed = 0
            for future in as_completed(futures):
                try:
                    cache_key, data = future.result()
                    if data is not None:
                        results[cache_key] = data
                    
                    completed += 1
                    if show_progress and progress is not None:
                        request = futures[future]
                        progress.update(completed, f'{request[0]} {request[1]}')
                        
                except Exception as e:
                    logger.warning(f"Ошибка загрузки данных: {e}")
        
        if show_progress and progress is not None:
            progress.finish(f'Загружено {len(results)} наборов данных!')
        
        return results

    def process_signal_batch(self, signal_batch: List[Dict], params: Dict, lookahead_hours: int = 24) -> List[Dict]:
        """Обработка пакета сигналов в одном потоке"""
        batch_results = []
        
        for signal in signal_batch:
            symbol = signal['symbol']
            timeframe = signal['timeframe']
            start_time = signal['timestamp']
            end_time = start_time + timedelta(hours=lookahead_hours)
            cache_key = f"{symbol}_{timeframe}_{start_time.strftime('%Y%m%d_%H%M')}"
            
            # Проверяем кэш
            historical_data = None
            with self.cache_lock:
                if cache_key in self.data_cache:
                    historical_data = self.data_cache[cache_key]
            
            if historical_data is None:
                historical_data = self.fetch_historical_data(symbol, timeframe, start_time, end_time, show_progress=False)
                if historical_data is not None:
                    with self.cache_lock:
                        self.data_cache[cache_key] = historical_data
            
            if historical_data is not None and not historical_data.empty:
                trade_result = self.simulate_trade_with_real_data(signal, params, historical_data)
                if trade_result:
                    # Добавляем дополнительную информацию для отладки
                    trade_result['signal_id'] = f"{symbol}_{timeframe}_{start_time.strftime('%Y%m%d_%H%M')}"
                    trade_result['data_length'] = len(historical_data)
                    batch_results.append({
                        'signal': signal,
                        'result': trade_result
                    })
        
        return batch_results
    
    def generate_parameter_combinations(self, timeframe=None) -> List[Dict]:
        """Генерация комбинаций параметров для оптимизации с поддержкой отдельных настроек для каждого таймфрейма"""
        opt_config = self.config.get('optimization', {})
        
        # Получаем выбранный подход к оптимизации
        optimization_approach = opt_config.get('approach', 2)  # По умолчанию Стандартная (2)
        
        # Определяем количество комбинаций в зависимости от подхода
        approach_settings = {
            1: {"name": "Быстрая", "combinations": 100, "description": "Минимальное количество комбинаций для тестирования"},
            2: {"name": "Стандартная", "combinations": 500, "description": "Рекомендуемое количество комбинаций"},
            3: {"name": "Точная", "combinations": 1000, "description": "Высокая точность оптимизации"},
            4: {"name": "Полная", "combinations": 12960000, "description": "Максимальная точность оптимизации"}
        }
        
        selected_approach = approach_settings.get(optimization_approach, approach_settings[2])
        max_combinations = selected_approach["combinations"]
        
        print(f"🎯 Выбран подход к оптимизации: {selected_approach['name']} ({max_combinations:,} комбинаций)")
        
        # Выбираем параметры в зависимости от таймфрейма
        if timeframe and 'timeframe_configs' in opt_config and timeframe in opt_config['timeframe_configs']:
            # Используем специфичные настройки для таймфрейма
            timeframe_config = opt_config['timeframe_configs'][timeframe]
            params = timeframe_config['parameters']
            print(f"🎯 Используются оптимизированные параметры для {timeframe}: {timeframe_config.get('description', '')}")
        elif 'legacy_parameters' in opt_config:
            # Используем legacy параметры как fallback
            params = opt_config['legacy_parameters']
            print(f"⚠️ Используются общие параметры (legacy) для {timeframe or 'replay'}")
        else:
            # Старый формат конфигурации
            params = opt_config.get('parameters', {})
            print(f"⚠️ Используются старые параметры для {timeframe or 'replay'}")
        
        combinations = []
        
        # Ограничиваем количество комбинаций для быстрой работы
        stop_losses = np.arange(params['stop_loss_percentage']['min'], 
                               params['stop_loss_percentage']['max'] + params['stop_loss_percentage']['step'], 
                               params['stop_loss_percentage']['step'])
        
        trigger_profits = np.arange(params['trigger_profit_percentage']['min'], 
                                  params['trigger_profit_percentage']['max'] + params['trigger_profit_percentage']['step'], 
                                  params['trigger_profit_percentage']['step'])
        
        trailings = np.arange(params['trailing_percentage']['min'], 
                            params['trailing_percentage']['max'] + params['trailing_percentage']['step'], 
                            params['trailing_percentage']['step'])
        
        profit_locks = np.arange(params['profit_lock_percentage']['min'], 
                               params['profit_lock_percentage']['max'] + params['profit_lock_percentage']['step'], 
                               params['profit_lock_percentage']['step'])
        
        print(f"📊 Диапазоны параметров для {timeframe or 'replay'} (PnL-based как в оригинальном боте):")
        print(f"   SL: {params['stop_loss_percentage']['min']:.1f}%-{params['stop_loss_percentage']['max']:.1f}% (шаг {params['stop_loss_percentage']['step']:.1f}%) - от margin")
        print(f"   TP: {params['trigger_profit_percentage']['min']:.1f}%-{params['trigger_profit_percentage']['max']:.1f}% (шаг {params['trigger_profit_percentage']['step']:.1f}%) - от margin")
        print(f"   TL: {params['trailing_percentage']['min']:.1f}%-{params['trailing_percentage']['max']:.1f}% (шаг {params['trailing_percentage']['step']:.1f}%) - от макс PnL")
        print(f"   PL: {params['profit_lock_percentage']['min']:.1f}%-{params['profit_lock_percentage']['max']:.1f}% (шаг {params['profit_lock_percentage']['step']:.1f}%) - от margin")
        
        valid_combinations = 0
        total_combinations = 0
        
        # Генерируем комбинации (без плеча - оно фиксированное)
        for stop_loss in stop_losses:
            for trigger_profit in trigger_profits:
                for trailing in trailings:
                    for profit_lock in profit_locks:
                        total_combinations += 1
                        
                        # Добавляем интеллектуальную фильтрацию:
                        # 1. Профит лок должен быть меньше триггера прибыли
                        if profit_lock >= trigger_profit:
                            continue
                        # 2. Трейлинг должен быть меньше стоп-лосса
                        if trailing >= stop_loss:
                            continue
                        # 3. Таке Профит должен быть больше Трейлинга
                        if trigger_profit < trailing:
                            continue
                        # 4. Исключаем слишком агрессивные комбинации
                        if stop_loss < 0.4 and trigger_profit < 0.3:
                            continue
                        # 5. Стоп-лосс не должен быть слишком большим относительно TP
                        if stop_loss > trigger_profit * 3.0:
                            continue
                        
                        valid_combinations += 1
                        combinations.append({
                            'stop_loss_percentage': round(stop_loss, 2),
                            'trigger_profit_percentage': round(trigger_profit, 2),
                            'trailing_percentage': round(trailing, 2),
                            'profit_lock_percentage': round(profit_lock, 2)
                        })
        
        # Если комбинаций больше, чем нужно для выбранного подхода, выбираем случайную выборку
        if len(combinations) > max_combinations:
            import random
            combinations = random.sample(combinations, max_combinations)
            print(f"🎯 Выбрано случайных {max_combinations} комбинаций из {len(combinations)} доступных")
        else:
            # Перемешиваем для случайного порядка тестирования
            import random
            random.shuffle(combinations)
        
        logger.info(f"🔧 Сгенерировано {len(combinations)} валидных комбинаций из {total_combinations} возможных")
        print(f"✅ Сгенерировано {len(combinations)} валидных комбинаций из {total_combinations} возможных")
        print(f"🧠 Исключено {total_combinations - len(combinations)} нелогичных комбинаций")
        
        return combinations
    
    def _simulate_trade_with_trading_bot_logic(self, signal: Dict, params: Dict, historical_data: pd.DataFrame) -> Optional[Dict]:
        """Симуляция сделки с использованием логики торгового бота"""
        try:
            # Создаем фиктивные пользовательские данные для тестирования
            user_data = {
                'user_id': 1,
                'api_key': 'test_key',
                'api_secret': 'test_secret',
                'account_type': 'demo',
                'leverage': self.config['trading'].get('leverage', 10.0),
                'margin_mode': 'isolated',
                'order_type': 'percentage',
                'qty_percentage': self.config['trading']['position_size_percentage'],
                'fixed_volume': 100.0,
                'initial_stop_percentage': params['stop_loss_percentage'],
                'trigger_profit_percentage': params['trigger_profit_percentage'],
                'profit_lock_percentage': params['profit_lock_percentage'],
                'trailing_percentage': params['trailing_percentage'],
                'trailing_interval': 3.0,
                'daily_loss_limit': 3,
                'max_open_trades': 5,
                'is_trading': 1,
                'report_type': 'fixed',
                'report_time': '00:00',
                'averaging_enabled': 0,
                'averaging_pause': 300.0
            }
            
            # Создаем экземпляр GateIO (из торгового бота)
            if HAS_TRADING_BOT and GateIO:
                gateio = GateIO(user_data)
                
                # Здесь мы бы вызвали функцию обработки сигнала из торгового бота
                # Но для бэктеста мы симулируем обработку сигнала
                
                # Получаем исторические данные для сигнала
                direction = signal['direction'].lower()
                symbol = signal['symbol']
                timeframe = signal['timeframe']
                signal_time = signal['timestamp']
                
                # Цена входа - используем цену закрытия свечи (как в оригинальном боте)
                entry_candle = None
                for timestamp, candle in historical_data.iterrows():
                    if isinstance(timestamp, datetime):
                        candle_start = timestamp
                    else:
                        candle_start = pd.to_datetime(str(timestamp))
                    
                    # Определяем конец свечи на основе таймфрейма
                    if timeframe == '1m':
                        candle_end = candle_start + timedelta(minutes=1)
                    elif timeframe == '5m':
                        candle_end = candle_start + timedelta(minutes=5)
                    elif timeframe == '15m':
                        candle_end = candle_start + timedelta(minutes=15)
                    elif timeframe == '30m':
                        candle_end = candle_start + timedelta(minutes=30)
                    elif timeframe == '1h':
                        candle_end = candle_start + timedelta(hours=1)
                    else:
                        candle_end = candle_start + timedelta(minutes=5)
                    
                    # Проверяем, попадает ли сигнал в интервал [начало, конец)
                    if candle_start <= signal_time < candle_end:
                        entry_candle = candle
                        break
                
                if entry_candle is None:
                    return None
                
                entry_price = float(entry_candle['close'])
                
                # Расчет размера позиции (как в боте)
                position_size = self.config['backtest']['initial_balance'] * (
                    self.config['trading']['position_size_percentage'] / 100
                )
                leverage = self.config['trading'].get('leverage', 1.0)
                leveraged_size = position_size * leverage
                
                # Расчет стоп-лосса (как в боте)
                if direction == 'buy':
                    stop_loss_price = entry_price * (1 - params['stop_loss_percentage'] / 100)
                else:
                    stop_loss_price = entry_price * (1 + params['stop_loss_percentage'] / 100)
                
                # Симуляция трейдинга (как в боте)
                result = self._simulate_trading_with_bot_logic(
                    signal, params, entry_price, stop_loss_price, 
                    leveraged_size, historical_data
                )
                
                return result
            
            return None
            
        except Exception as e:
            logger.error(f"Ошибка симуляции сделки с логикой бота: {e}")
            return None
    
    def _simulate_trading_with_bot_logic(self, signal: Dict, params: Dict, entry_price: float, 
                                      stop_loss_price: float, position_size: float, 
                                      historical_data: pd.DataFrame) -> Optional[Dict]:
        """Симуляция трейдинга с логикой торгового бота"""
        try:
            direction = signal['direction'].lower()
            symbol = signal['symbol']
            signal_time = signal['timestamp']
            
            current_price = entry_price
            highest_pnl = 0.0
            lowest_pnl = 0.0
            
            trailing_activated = False
            close_reason = None
            exit_timestamp = None
            
            # Рассчитываем margin (как в боте)
            leverage = self.config['trading'].get('leverage', 1.0)
            margin = position_size / leverage
            
            # Функция расчета PnL (как в боте)
            def calculate_pnl(price: float) -> float:
                amount = position_size / entry_price
                if direction == 'buy':
                    return (price - entry_price) * amount
                else:
                    return (entry_price - price) * amount
            
            # Функция расчета PnL процента (как в боте)
            def calculate_pnl_percentage(pnl_usdt: float) -> float:
                return (pnl_usdt / margin * 100) if margin > 0 else 0.0
            
            # Проходим по данным (как в боте)
            for timestamp, candle in historical_data.iterrows():
                if timestamp <= signal_time:
                    continue
                    
                h = float(candle['high'])
                l = float(candle['low'])
                c = float(candle['close'])
                
                # Проверяем high, low, close цены
                prices_to_check = [h, l, c]
                for price in prices_to_check:
                    current_price = price
                    current_pnl = calculate_pnl(current_price)
                    current_pnl_pct = calculate_pnl_percentage(current_pnl)
                    
                    # Обновляем максимальный и минимальный PnL
                    if current_pnl > highest_pnl:
                        highest_pnl = current_pnl
                    if current_pnl < lowest_pnl:
                        lowest_pnl = current_pnl
                    
                    # Проверка стоп-лосса (как в боте)
                    if self.check_pnl_based_stop_loss(current_pnl_pct, params['stop_loss_percentage']):
                        close_reason = 'stop_loss'
                        exit_timestamp = timestamp
                        break
                    
                    # Активация трейлинга (как в боте)
                    if not trailing_activated and self.check_pnl_based_activation(current_pnl_pct, params['trigger_profit_percentage']):
                        trailing_activated = True
                    
                    # Обновление трейлинг-стопа (как в боте)
                    if trailing_activated and current_pnl > 0:
                        stop_pnl = self.calculate_trailing_stop_from_pnl(highest_pnl, params['trailing_percentage'])
                        if current_pnl <= stop_pnl:
                            close_reason = 'trailing_stop'
                            exit_timestamp = timestamp
                            break
                
                if close_reason:
                    break
            
            if close_reason:
                return {
                    'entry_price': entry_price,
                    'exit_price': current_price,
                    'entry_time': signal_time,
                    'exit_time': exit_timestamp,
                    'net_pnl': calculate_pnl(current_price),
                    'close_reason': close_reason,
                    'trailing_activated': trailing_activated
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Ошибка симуляции трейдинга: {e}")
            return None
    
    def simulate_trade_with_real_data(self, signal: Dict, params: Dict, historical_data: pd.DataFrame) -> Optional[Dict]:
        """Симуляция сделки с реальными историческими данными, используя логику торгового бота"""
        # Если доступна логика торгового бота, используем её
        if HAS_TRADING_BOT:
            return self._simulate_trade_with_trading_bot_logic(signal, params, historical_data)
        
        # Иначе используем оригинальную логику
        direction = signal['direction'].lower()
        symbol = signal['symbol']
        timeframe = signal['timeframe']
        
        # Вход точно по времени сигнала (как в оригинальном боте)
        signal_time = signal['timestamp']
        
        # Находим свечу, которая содержит время сигнала
        entry_candle = None
        for timestamp, candle in historical_data.iterrows():
            # Проверяем, попадает ли сигнал в эту свечу
            if isinstance(timestamp, datetime):
                candle_start = timestamp
            else:
                # Convert to string first, then to datetime
                candle_start = pd.to_datetime(str(timestamp))
            # Определяем конец свечи на основе таймфрейма
            if timeframe == '1m':
                candle_end = candle_start + timedelta(minutes=1)
            elif timeframe == '5m':
                candle_end = candle_start + timedelta(minutes=5)
            elif timeframe == '15m':
                candle_end = candle_start + timedelta(minutes=15)
            elif timeframe == '30m':
                candle_end = candle_start + timedelta(minutes=30)
            elif timeframe == '1h':
                candle_end = candle_start + timedelta(hours=1)
            else:
                candle_end = candle_start + timedelta(minutes=5)  # По умолчанию
            
            # Проверяем, попадает ли сигнал в интервал [начало, конец)
            if candle_start <= signal_time < candle_end:
                entry_candle = candle
                break
        
        if entry_candle is None:
            return None
        
        # Цена входа - используем цену закрытия свечи (как в оригинальном боте)
        entry_price = float(entry_candle['close'])
        
        # Расчет размера позиции
        position_size = self.config['backtest']['initial_balance'] * (self.config['trading']['position_size_percentage'] / 100)
        leverage = self.config['trading'].get('leverage', 1.0)  # Фиксированное плечо из конфига
        leveraged_size = position_size * leverage
        
        # Расчет стоп-лосса
        if direction == 'buy':
            stop_loss_price = entry_price * (1 - params['stop_loss_percentage'] / 100)
        else:
            stop_loss_price = entry_price * (1 + params['stop_loss_percentage'] / 100)
        
        # Симуляция трейлинг-стопа на реальных данных
        return self.simulate_trailing_stop_real_data(
            signal, params, entry_price, stop_loss_price, leveraged_size, direction, historical_data, signal_time
        )
    
    def check_pnl_based_activation(self, current_pnl_pct: float, trigger_profit_percentage: float) -> bool:
        """Проверяет активацию трейлинга на основе PnL по margin (как в оригинальном боте)."""
        if current_pnl_pct >= trigger_profit_percentage:
            return True
        return False
    
    def calculate_trailing_stop_from_pnl(self, highest_pnl: float, trailing_percentage: float) -> float:
        """Рассчитывает трейлинг стоп на основе PnL по margin (как в оригинальном боте)."""
        # В оригинальном боте: stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
        stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
        return stop_pnl
    
    def check_pnl_based_stop_loss(self, current_pnl_pct: float, stop_loss_percentage: float) -> bool:
        """Проверяет стоп-лосс на основе PnL по margin (как в оригинальном боте)."""
        if current_pnl_pct <= -stop_loss_percentage:
            return True
        return False
    
    def simulate_trailing_stop_real_data(self, signal: Dict, params: Dict, entry_price: float, 
                                        stop_loss_price: float, position_size: float, direction: str,
                                        historical_data: pd.DataFrame, signal_time: datetime) -> Optional[Dict]:
        """Симуляция трейлинг-стопа на реальных данных с PnL-based логикой точно как в оригинальном боте"""
        
        signal_time = signal['timestamp']
        
        # Получаем данные после сигнала
        future_data = historical_data[historical_data.index > signal_time]
        
        if future_data.empty:
            return None
        
        current_price = entry_price
        highest_pnl = 0.0  # Максимальный PnL в USDT (как в оригинальном боте)
        lowest_pnl = 0.0   # Минимальный PnL в USDT (как в оригинальном боте)
        
        trailing_activated = False
        trailing_stop_price = None
        profit_lock_price = None
        close_reason = None
        exit_timestamp = signal_time + timedelta(hours=24)
        
        # Рассчитываем margin - это основная сумма позиции БЕЗ плеча (как в оригинальном боте)
        leverage = self.config['trading'].get('leverage', 1.0)
        margin = position_size / leverage  # margin = основная сумма до применения плеча
        
        # Функция расчета PnL точно как в оригинальном боте - через amount (размер позиции)
        def calculate_pnl(current_price: float) -> float:
            # В оригинальном боте: current_pnl, _ = self.calculate_current_pnl(symbol, side, entry_price, current_price, amount)
            # amount = это размер позиции в монетах (position_size / entry_price)
            amount = position_size / entry_price
            if direction == 'buy':
                return (current_price - entry_price) * amount
            else:
                return (entry_price - current_price) * amount
        
        # Функция расчета PnL процента от margin точно как в оригинальном боте
        def calculate_pnl_percentage(pnl_usdt: float) -> float:
            # В оригинальном боте: pnl_percentage = (current_pnl / margin * 100) if margin else 0.0
            return (pnl_usdt / margin * 100) if margin > 0 else 0.0
        
        # Проходим по каждой свече после сигнала
        for timestamp, candle in future_data.iterrows():
            o = float(candle['open']) if 'open' in candle else current_price
            h = float(candle['high'])
            l = float(candle['low'])
            c = float(candle['close'])
            
            # Выбор вероятного порядка движения внутри свечи
            if c >= o:
                path = ['open', 'high', 'low', 'close']
            else:
                path = ['open', 'low', 'high', 'close']
            
            close_reason = None
            
            # Проходим по каждой точке внутри свечи
            for node in path:
                if node == 'open':
                    current_price = o
                elif node == 'high':
                    current_price = h
                elif node == 'low':
                    current_price = l
                elif node == 'close':
                    current_price = c
                
                # Рассчитываем текущий PnL точно как в оригинальном боте
                current_pnl = calculate_pnl(current_price)
                current_pnl_pct = calculate_pnl_percentage(current_pnl)
                
                # Обновляем максимальный и минимальный PnL точно как в оригинальном боте
                if current_pnl > highest_pnl:
                    highest_pnl = current_pnl
                if current_pnl < lowest_pnl:
                    lowest_pnl = current_pnl
                
                # 1. ПРОВЕРКА СТОП-ЛОССА (как в check_pnl_based_stop_loss)
                # В оригинальном боте: if pnl_percentage <= -stop_loss_percentage:
                if self.check_pnl_based_stop_loss(current_pnl_pct, params['stop_loss_percentage']):
                    close_reason = 'stop_loss'
                    break
                
                # 2. АКТИВАЦИЯ ТРЕЙЛИНГА (как в check_pnl_based_activation)
                # В оригинальном боте: if pnl_percentage >= trigger_profit_percentage:
                if not trailing_activated and self.check_pnl_based_activation(current_pnl_pct, params['trigger_profit_percentage']):
                    trailing_activated = True
                    logger.debug(f"🟢 Активация трейлинга по PnL: {current_pnl_pct:.2f}% >= {params['trigger_profit_percentage']:.2f}%")
                
                # 3. ОБНОВЛЕНИЕ ТРЕЙЛИНГ-СТОПА (точно как в calculate_trailing_stop_from_pnl)
                if trailing_activated and current_pnl > 0:
                    # В оригинальном боте: stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
                    stop_pnl = self.calculate_trailing_stop_from_pnl(highest_pnl, params['trailing_percentage'])
                    
                    # В оригинальном боте: if current_pnl <= stop_pnl:
                    if current_pnl <= stop_pnl:
                        close_reason = 'trailing_stop'
                        logger.debug(f"🟡 Трейлинг-стоп сработал: текущий PnL ({current_pnl:.2f}) <= стоп PnL ({stop_pnl:.2f})")
                        break
                
                # 4. PROFIT LOCK (PnL-based как в оригинальном боте) - ИЗМЕНЕНО: теперь не влияет на закрытие ордера
                # В оригинальном боте profit lock работает как дополнительная защита, но в тестере мы его отключаем
                # Для тестирования мы просто отслеживаем достижение уровня, но не закрываем позицию
                # Это позволит оценить эффективность других стратегий без влияния PL на ордер
                # Тем не менее, мы можем отслеживать достижение уровня для аналитики
                if current_pnl_pct >= params['profit_lock_percentage']:
                    logger.debug(f"🔒 Profit Lock достигнут: {current_pnl_pct:.2f}% >= {params['profit_lock_percentage']:.2f}%")
                    # Не закрываем позицию, просто логируем достижение уровня
                
                if close_reason:
                    break
            
            if close_reason:
                exit_timestamp = timestamp
                break
        
        # Если позиция не закрылась, закрываем по времени
        if close_reason is None:
            close_reason = 'time_exit'
        
        # Финальный расчет PnL
        final_pnl = calculate_pnl(current_price)
        
        # Комиссии
        commission = position_size * self.config['backtest']['commission'] * 2
        
        return {
            'entry_price': entry_price,
            'exit_price': current_price,
            'pnl': final_pnl,
            'commission': commission,
            'net_pnl': final_pnl - commission,
            'close_reason': close_reason,
            'trailing_activated': trailing_activated,
            'highest_pnl': highest_pnl,
            'lowest_pnl': lowest_pnl,
            'entry_time': signal_time,
            'exit_time': exit_timestamp,
            'pnl_percentage': calculate_pnl_percentage(final_pnl)
        }
    
    def test_parameters_parallel(self, timeframe_signals: Dict[str, List[Dict]], combinations: List[Dict], lookahead_hours: int = 24) -> List[Dict]:
        """Параллельное тестирование комбинаций параметров"""
        all_results = []
        
        print(f"\n🧠 Начинаем параллельное тестирование {len(combinations)} комбинаций параметров...")
        progress = ProgressBar(
            total=len(combinations),
            prefix='🔬 Оптимизация',
            length=30
        )
        
        def test_single_combination(params_try):
            """Тестирование одной комбинации параметров"""
            total_pnl_try = 0.0
            total_trades_try = 0
            winning_trades_try = 0
            trailing_activations_try = 0
            trades_details = []
            
            # Тестируем параметры на всех сигналах
            for timeframe, signals in timeframe_signals.items():
                for signal in signals:
                    symbol = signal['symbol']
                    tf = signal['timeframe']
                    start_time = signal['timestamp']
                    end_time = start_time + timedelta(hours=lookahead_hours)
                    cache_key = f"{symbol}_{tf}_{start_time.strftime('%Y%m%d_%H%M')}"
                    
                    # Проверяем кэш
                    historical_data = None
                    with self.cache_lock:
                        if cache_key in self.data_cache:
                            historical_data = self.data_cache[cache_key]
                    
                    if historical_data is None:
                        historical_data = self.fetch_historical_data(symbol, tf, start_time, end_time, show_progress=False)
                        if historical_data is not None:
                            with self.cache_lock:
                                self.data_cache[cache_key] = historical_data
                    
                    if historical_data is None or historical_data.empty:
                        continue
                        
                    tr = self.simulate_trade_with_real_data(signal, params_try, historical_data)
                    if tr:
                        total_pnl_try += tr['net_pnl']
                        total_trades_try += 1
                        if tr['net_pnl'] > 0:
                            winning_trades_try += 1
                        if tr.get('trailing_activated'):
                            trailing_activations_try += 1
                        
                        trades_details.append({
                            'symbol': symbol,
                            'timeframe': tf,
                            'pnl': tr['net_pnl'],
                            'close_reason': tr.get('close_reason')
                        })
            
            # Формируем результат
            if total_trades_try > 0:
                winrate_try = (winning_trades_try / total_trades_try) * 100
                avg_pnl_try = total_pnl_try / total_trades_try
                trailing_rate_try = (trailing_activations_try / total_trades_try) * 100
                
                return {
                    'params': params_try.copy(),
                    'total_pnl': total_pnl_try,
                    'winrate': winrate_try,
                    'avg_pnl': avg_pnl_try,
                    'total_trades': total_trades_try,
                    'winning_trades': winning_trades_try,
                    'trailing_rate': trailing_rate_try,
                    'trades_details': trades_details
                }
            
            return None
        
        # Параллельное тестирование
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(test_single_combination, combo): combo for combo in combinations}
            
            completed = 0
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result is not None:
                        all_results.append(result)
                    
                    completed += 1
                    combo = futures[future]
                    progress.update(completed, f'SL{combo["stop_loss_percentage"]:.1f}%')
                    
                except Exception as e:
                    logger.warning(f"Ошибка тестирования параметров: {e}")
        
        progress.finish(f'Протестировано {len(all_results)} комбинаций!')
        return all_results
    
    def run_replay_multithread(self):
        """Многопоточный режим последовательного проигрывания всех сигналов"""
        logger.info("🚀 Запускаем режим MULTITHREAD REPLAY: параллельный прогон всех сигналов")

        # Параметры из конфигурации
        rp = self.config.get('replay', {})
        params = {
            'stop_loss_percentage': float(rp.get('stop_loss_percentage', 1.0)),
            'trigger_profit_percentage': float(rp.get('trigger_profit_percentage', 0.5)),
            'trailing_percentage': float(rp.get('trailing_percentage', 0.5)),
            'profit_lock_percentage': float(rp.get('profit_lock_percentage', 0.25)),
        }
        lookahead_hours = int(rp.get('lookahead_hours', 24))

        # Предварительная загрузка данных параллельно
        print("\n🚀 Начинаем предварительную загрузку данных...")
        
        # Создаем список запросов для параллельной загрузки
        data_requests = []
        unique_requests = set()
        
        for signal in self.signals:
            symbol = signal['symbol']
            timeframe = signal['timeframe']
            start_time = signal['timestamp']
            end_time = start_time + timedelta(hours=lookahead_hours)
            cache_key = f"{symbol}_{timeframe}_{start_time.strftime('%Y%m%d_%H%M')}"
            
            request_key = (symbol, timeframe, start_time.strftime('%Y%m%d_%H%M'))
            if request_key not in unique_requests:
                unique_requests.add(request_key)
                data_requests.append((symbol, timeframe, start_time, end_time, cache_key))
        
        # Параллельная загрузка всех нужных данных
        self.fetch_historical_data_parallel(data_requests, show_progress=True)
        
        # Обработка сигналов параллельно
        print("\n🧠 Обработка сигналов многопоточно...")
        
        # Разбиваем сигналы на пакеты
        batch_size = max(1, len(self.signals) // self.max_workers)
        signal_batches = [self.signals[i:i + batch_size] for i in range(0, len(self.signals), batch_size)]
        
        all_trades = []
        progress = ProgressBar(
            total=len(self.signals),
            prefix='📈 Обработка сигналов',
            length=40
        )
        
        processed_signals = 0
        
        # Параллельная обработка пакетов
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(self.process_signal_batch, batch, params, lookahead_hours): batch for batch in signal_batches}
            
            for future in as_completed(futures):
                try:
                    batch_results = future.result()
                    all_trades.extend(batch_results)
                    
                    batch = futures[future]
                    processed_signals += len(batch)
                    progress.update(processed_signals, f'Обработано {len(all_trades)} сделок')
                    
                except Exception as e:
                    logger.warning(f"Ошибка обработки пакета сигналов: {e}")
        
        # Выводим детальную диагностику для отладки
        print(f"\n🔍 ДИАГНОСТИКА МНОГОПОТОЧНОГО РЕЖИМА:")
        print(f"   📊 Всего обработано сигналов: {len(self.signals)}")
        print(f"   ✅ Успешных сделок: {len(all_trades)}")
        print(f"   🗂️ Уникальных наборов данных в кэше: {len(self.data_cache)}")
        
        # Проверим несколько первых сделок для сравнения
        if len(all_trades) >= 3:
            print(f"\n🔬 ПЕРВЫЕ 3 СДЕЛКИ (для сравнения с обычным режимом):")
            for i, trade_data in enumerate(all_trades[:3]):
                signal = trade_data['signal']
                result = trade_data['result']
                print(f"   {i+1}. {signal['symbol']} {signal['timeframe']} | Entry: {result.get('entry_price', 'N/A'):.4f} | PnL: {result.get('net_pnl', 0):.4f} | {result.get('close_reason', 'unknown')}")
        
        # Обработка результатов
        total_pnl = 0.0
        total_trades = 0
        winning_trades = 0
        trailing_activations = 0
        win_rate = 0.0  # Initialize win_rate to fix potential unbound variable
        trailing_rate = 0.0  # Initialize trailing_rate to fix potential unbound variable
        per_trade = []
        
        for trade_data in all_trades:
            signal = trade_data['signal']
            trade_result = trade_data['result']
            
            total_trades += 1
            total_pnl += trade_result['net_pnl']
            if trade_result['net_pnl'] > 0:
                winning_trades += 1
            if trade_result.get('trailing_activated'):
                trailing_activations += 1
            
            per_trade.append({
                'symbol': signal['symbol'],
                'timeframe': signal['timeframe'],
                'direction': signal['direction'],  # Добавляем направление сделки
                'strategy': signal.get('strategy', 'Unknown'),  # Добавляем стратегию
                'entry_time': trade_result.get('entry_time'),
                'exit_time': trade_result.get('exit_time'),
                'entry_price': trade_result.get('entry_price'),
                'exit_price': trade_result.get('exit_price'),
                'net_pnl': trade_result.get('net_pnl'),
                'close_reason': trade_result.get('close_reason'),
                'trailing_activated': trade_result.get('trailing_activated'),
            })

        # Вывод сводки
        print("\n" + "=" * 80)
        print("📊 РЕЗУЛЬТАТЫ MULTITHREAD REPLAY ПРОГОНА")
        print("=" * 80)
        if total_trades > 0:
            win_rate = (winning_trades / total_trades) * 100.0
            trailing_rate = (trailing_activations / total_trades) * 100.0
            avg_pnl = total_pnl / total_trades
            
            # Разделяем прибыльные и убыточные сделки
            profitable_trades = [t for t in per_trade if t['net_pnl'] > 0]
            losing_trades = [t for t in per_trade if t['net_pnl'] <= 0]
            
            print(f"💰 Общая прибыль: {total_pnl:.2f} USDT")
            print(f"📈 Винрейт: {win_rate:.1f}%")
            print(f"📊 Средняя прибыль на сделку: {avg_pnl:.2f} USDT")
            print(f"🎯 Активация трейлинга: {trailing_rate:.1f}%")
            print(f"🧠 Многопоточность: {self.max_workers} потоков")
            print(f"⚙️ Ускорение: до ~{self.max_workers}x по сравнению с однопоточным режимом")
            
            if profitable_trades:
                best_trade = max(profitable_trades, key=lambda x: x['net_pnl'])
                worst_profitable = min(profitable_trades, key=lambda x: x['net_pnl'])
                print(f"\n💚 Прибыльные сделки ({len(profitable_trades)}):")
                print(f"   Лучшая: PnL={best_trade['net_pnl']:.2f} USDT ({best_trade['symbol']} {best_trade['timeframe']})")
                print(f"   Худшая: PnL={worst_profitable['net_pnl']:.2f} USDT ({worst_profitable['symbol']} {worst_profitable['timeframe']})")
            
            if losing_trades:
                best_losing = max(losing_trades, key=lambda x: x['net_pnl'])  # наименьший убыток
                worst_losing = min(losing_trades, key=lambda x: x['net_pnl'])  # наибольший убыток
                print(f"\n❤️ Убыточные сделки ({len(losing_trades)}):")
                print(f"   Наименьший убыток: PnL={best_losing['net_pnl']:.2f} USDT ({best_losing['symbol']} {best_losing['timeframe']})")
                print(f"   Наибольший убыток: PnL={worst_losing['net_pnl']:.2f} USDT ({worst_losing['symbol']} {worst_losing['timeframe']})")
            
            # Статистика по причинам закрытия
            close_reasons = {}
            for trade in per_trade:
                reason = trade['close_reason']
                if reason not in close_reasons:
                    close_reasons[reason] = 0
                close_reasons[reason] += 1
            
            print(f"\n🔒 Breakdown по причинам закрытия:")
            for reason, count in close_reasons.items():
                percentage = (count / total_trades) * 100
                print(f"   {reason}: {count} ({percentage:.1f}%)")
                
        else:
            print("❌ Не было выполнено ни одной сделки")

        print("⚙️ ИСПОЛЬЗОВАННЫЕ НАСТРОЙКИ (PnL-based как в оригинальном боте):")
        print(f"   🛑 Стоп-лосс: {params['stop_loss_percentage']:.2f}% (от margin)")
        print(f"   🎯 Триггер прибыли: {params['trigger_profit_percentage']:.2f}% (от margin)")
        print(f"   📈 Трейлинг: {params['trailing_percentage']:.2f}% (от макс PnL)")
        print(f"   🔒 Блокировка прибыли: {params['profit_lock_percentage']:.2f}% (от margin)")
        print(f"   ⚡ Плечо: {self.config['trading'].get('leverage', 1.0):.1f}x (фиксированное)")
        print(f"   🧠 Потоков: {self.max_workers}")

        # Генерация графиков ордеров, если доступна
        self._generate_order_charts(per_trade)

        # Если включена оптимизация в replay, прогоняем оптимизацию по таймфреймам из сигналов
        if self.config.get('replay', {}).get('optimize', False):
            self.run_parallel_optimization(total_pnl, win_rate, trailing_rate, total_trades, lookahead_hours)
        
        # Показываем меню после завершения бэктеста
        self.show_post_backtest_menu(per_trade)
    
    def show_post_backtest_menu(self, per_trade):
        """Показывает меню после завершения бэктеста"""
        # Инициализируем множество уже сгенерированных сделок как атрибут класса
        # Используем хэши сделок для более надежного отслеживания
        if not hasattr(self, 'generated_trades_hash'):
            self.generated_trades_hash = set()
            print("DEBUG: initialized generated_trades_hash as empty set")
        else:
            print(f"DEBUG: loaded existing generated_trades_hash with {len(self.generated_trades_hash)} items")
        
        while True:
            print("\n==================================================")
            print("📊 Бэктест завершен!")
            print("==================================================")
            print("Выберите действие:")
            print("1. Сгенерировать графики ордеров")
            print("2. Экспортировать оптимальные настройки")
            print("3. Вернуться в главное меню")
            print("4. Выход")
            print("==================================================")
            
            # Создаем хэши для всех сделок
            trade_hashes = []
            for i, trade in enumerate(per_trade):
                # Создаем уникальный хэш для каждой сделки на основе ключевых параметров
                trade_hash = hash((trade['entry_time'], trade['symbol'], round(trade['entry_price'], 6)))
                trade_hashes.append(trade_hash)
            
            # Определяем оставшиеся сделки для генерации
            remaining_indices = [i for i, trade_hash in enumerate(trade_hashes) if trade_hash not in self.generated_trades_hash]
            remaining_count = len(remaining_indices)
            
            print(f"DEBUG: total trades={len(per_trade)}, remaining trades={remaining_count}")
            print(f"DEBUG: generated_trades_hash count={len(self.generated_trades_hash)}")
            
            try:
                choice = input("Введите номер (1-4): ").strip()
                
                if choice == '1':
                    # Сначала спрашиваем, какие графики генерировать
                    print("\n📊 Выберите тип графиков для генерации:")
                    print("1. Стандартные графики ордеров")
                    print("2. Сравнительные графики ордеров (оптимальные настройки)")
                    
                    while True:
                        try:
                            chart_choice = input("Введите номер (1-2): ").strip()
                            if chart_choice in ['1', '2']:
                                break
                            else:
                                print("Пожалуйста, введите 1 или 2")
                        except ValueError:
                            print("Пожалуйста, введите корректное число")
                    
                    if chart_choice == '1':
                        # Генерация стандартных графиков ордеров
                        try:
                            from order_chart_generator import ChartGenerator
                            chart_generator = ChartGenerator(self)
                            
                            if remaining_count <= 0:
                                print("✅ Все графики уже сгенерированы")
                                continue
                            
                            print(f"\n📊 Осталось сгенерировать графиков: {remaining_count}")
                            
                            # Спрашиваем, сколько графиков сгенерировать
                            count = 0  # Инициализируем переменную
                            cancelled = False  # Флаг для отслеживания отмены
                            
                            while True:
                                try:
                                    count_input = input(f"Сколько графиков сгенерировать? (0 - нет, Enter - все оставшиеся ({remaining_count}), или введите число от 1 до {remaining_count}): ").strip()
                                    if count_input == "0":
                                        print("⏭️ Генерация графиков отменена")
                                        cancelled = True
                                        break
                                    elif count_input == "":
                                        count = remaining_count
                                        break
                                    else:
                                        count = int(count_input)
                                        if 1 <= count <= remaining_count:
                                            break
                                        else:
                                            print(f"Пожалуйста, введите число от 1 до {remaining_count}")
                                except ValueError:
                                    print("Пожалуйста, введите корректное число")
                            
                            # Если пользователь не отменил генерацию
                            if not cancelled:
                                # Генерируем графики для оставшихся сделок
                                indices_to_generate = remaining_indices[:count]
                                trades_to_generate = [per_trade[i] for i in indices_to_generate]
                                chart_generator.generate_all_order_charts(trades_to_generate, count=count)
                                
                                # Обновляем множество сгенерированных сделок
                                added_count = 0
                                for i in indices_to_generate:
                                    trade_hash = trade_hashes[i]
                                    if trade_hash not in self.generated_trades_hash:
                                        self.generated_trades_hash.add(trade_hash)
                                        added_count += 1
                                
                                # Сохраняем обновленное множество
                                self._save_generated_trades_hash()
                                
                                print(f"✅ Сгенерировано {count} графиков.")
                                print(f"DEBUG: added {added_count} new trades to generated_trades_hash, total now {len(self.generated_trades_hash)}")
                                
                                # Если все графики сгенерированы
                                if len(self.generated_trades_hash) >= len(per_trade):
                                    print("🎉 Все графики успешно сгенерированы!")
                        except ImportError:
                            print("⚠️ Модуль order_chart_generator не найден")
                        except Exception as e:
                            print(f"❌ Ошибка при генерации графиков: {e}")
                            import traceback
                            traceback.print_exc()
                    else:
                        # Генерация сравнительных графиков ордеров с оптимальными настройками
                        try:
                            from otim_order_chart_generator import OtimChartGenerator
                            otim_chart_generator = OtimChartGenerator(self)
                            
                            if remaining_count <= 0:
                                print("✅ Все графики уже сгенерированы")
                                continue
                            
                            print(f"\n📊 Осталось сгенерировать графиков: {remaining_count}")
                            
                            # Спрашиваем, сколько графиков сгенерировать
                            count = 0  # Инициализируем переменную
                            cancelled = False  # Флаг для отслеживания отмены
                            
                            while True:
                                try:
                                    count_input = input(f"Сколько графиков сгенерировать? (0 - нет, Enter - все оставшиеся ({remaining_count}), или введите число от 1 до {remaining_count}): ").strip()
                                    if count_input == "0":
                                        print("⏭️ Генерация графиков отменена")
                                        cancelled = True
                                        break
                                    elif count_input == "":
                                        count = remaining_count
                                        break
                                    else:
                                        count = int(count_input)
                                        if 1 <= count <= remaining_count:
                                            break
                                        else:
                                            print(f"Пожалуйста, введите число от 1 до {remaining_count}")
                                except ValueError:
                                    print("Пожалуйста, введите корректное число")
                            
                            # Если пользователь не отменил генерацию
                            if not cancelled:
                                # Генерируем графики для оставшихся сделок
                                indices_to_generate = remaining_indices[:count]
                                trades_to_generate = [per_trade[i] for i in indices_to_generate]
                                otim_chart_generator.generate_all_order_charts(trades_to_generate, count=count)
                                
                                # Обновляем множество сгенерированных сделок
                                added_count = 0
                                for i in indices_to_generate:
                                    trade_hash = trade_hashes[i]
                                    if trade_hash not in self.generated_trades_hash:
                                        self.generated_trades_hash.add(trade_hash)
                                        added_count += 1
                                
                                # Сохраняем обновленное множество
                                self._save_generated_trades_hash()
                                
                                print(f"✅ Сгенерировано {count} графиков с оптимальными настройками.")
                                print(f"DEBUG: added {added_count} new trades to generated_trades_hash, total now {len(self.generated_trades_hash)}")
                                
                                # Если все графики сгенерированы
                                if len(self.generated_trades_hash) >= len(per_trade):
                                    print("🎉 Все графики успешно сгенерированы!")
                        except ImportError:
                            print("⚠️ Модуль otim_order_chart_generator не найден")
                        except Exception as e:
                            print(f"❌ Ошибка при генерации графиков: {e}")
                            import traceback
                            traceback.print_exc()
                elif choice == '2':
                    # Экспорт оптимальных настроек
                    if hasattr(self, 'timeframe_results') and self.timeframe_results:
                        self.offer_export_best_settings(self.timeframe_results)
                    else:
                        print("❌ Нет результатов оптимизации для экспорта")
                        print("💡 Подсказка: Запустите бэктест с оптимизацией параметров, чтобы получить настройки для экспорта")
                elif choice == '3':
                    # Вернуться в главное меню
                    print("↩️ Возвращаемся в главное меню...")
                    # Удаляем временный файл с настройками
                    self._cleanup_temp_settings()
                    return  # Это правильно возвращает из функции в главное меню
                elif choice == '4':
                    # Выход
                    print("👋 До свидания!")
                    # Удаляем временный файл с настройками
                    self._cleanup_temp_settings()
                    import sys
                    sys.exit(0)  # Корректный выход из программы
                else:
                    print("❌ Неверный выбор. Попробуйте снова.")
            except KeyboardInterrupt:
                print("\n👋 До свидания!")
                import sys
                sys.exit(0)  # Корректный выход при прерывании Ctrl+C
            except Exception as e:
                print(f"❌ Ошибка: {e}")
                import traceback
                traceback.print_exc()

    def _generate_order_charts(self, trades_data):
        """Генерация графиков ордеров после бэктеста"""
        print(f"🔍 [DEBUG] Вызов generate_order_charts с {len(trades_data) if trades_data else 0} сделками")  # Debug line
        try:
            # Проверяем, доступен ли ChartGenerator
            from order_chart_generator import ChartGenerator
            chart_generator = ChartGenerator(self)
            print("✅ [DEBUG] ChartGenerator успешно импортирован и создан")  # Debug line
            
            # Спрашиваем пользователя, хочет ли он сгенерировать графики
            print("\n📊 Хотите сгенерировать графики ордеров? (1 - Да, 2 - Нет)")
            while True:
                try:
                    response = int(input("Введите 1 или 2: ").strip())
                    if response in [1, 2]:
                        break
                    else:
                        print("Пожалуйста, введите 1 или 2")
                except ValueError:
                    print("Пожалуйста, введите число 1 или 2")
            
            if response == 1:
                print("📈 [DEBUG] Пользователь выбрал генерацию графиков")  # Debug line
                # Генерируем все графики (передаем count=None, чтобы функция сама спросила)
                chart_generator.generate_all_order_charts(trades_data, count=None)
                print("✅ [DEBUG] Генерация графиков завершена")  # Debug line
            else:
                print("⏭️ [DEBUG] Пользователь отказался от генерации графиков")  # Debug line
        except ImportError as e:
            print(f"⚠️ Модуль order_chart_generator не найден. Генерация графиков ордеров будет недоступна. Ошибка: {e}")
        except Exception as e:
            print(f"❌ Ошибка при генерации графиков ордеров: {e}")
            import traceback
            traceback.print_exc()

    def apply_testing_method_settings(self, testing_method: str):
        """Применяет настройки в зависимости от выбранного метода тестирования"""
        if testing_method == 'fast_optimization':
            # Быстрая оптимизация - базовые настройки для скорости
            self.config.setdefault('testing', {})['slippage_enabled'] = False
            self.config.setdefault('testing', {})['microstructure_enabled'] = False
            self.config.setdefault('testing', {})['intrabar_steps'] = 1
            print("⚙️ Настройки: Быстрая оптимизация (без проскальзывания)")
        elif testing_method == 'detailed_validation':
            # Детальная валидация - добавляем реалистичные эффекты
            self.config.setdefault('testing', {})['slippage_enabled'] = True
            self.config.setdefault('testing', {})['microstructure_enabled'] = True
            self.config.setdefault('testing', {})['intrabar_steps'] = 15
            self.config.setdefault('testing', {})['slippage_percent'] = 0.02  # 0.02%
            print("⚙️ Настройки: Детальная валидация (с проскальзыванием и микроструктурой)")
        elif testing_method == 'final_validation':
            # Финальная проверка - максимальная точность
            self.config.setdefault('testing', {})['slippage_enabled'] = True
            self.config.setdefault('testing', {})['microstructure_enabled'] = True
            self.config.setdefault('testing', {})['intrabar_steps'] = 30
            self.config.setdefault('testing', {})['monte_carlo_enabled'] = True
            self.config.setdefault('testing', {})['monte_carlo_scenarios'] = 100
            self.config.setdefault('testing', {})['slippage_percent'] = 0.03  # 0.03%
            print("⚙️ Настройки: Финальная проверка (максимальная точность + Monte Carlo)")
        elif testing_method == 'full_pipeline':
            # Автоматический конвейер - будем менять настройки поэтапно
            print("⚙️ Настройки: Автоматический конвейер (настройки меняются на каждом этапе)")

    def run_parallel_optimization(self, original_pnl: float, original_winrate: float, original_trailing_rate: float, original_trades: int, lookahead_hours: int = 24):
        """Параллельная оптимизация параметров по таймфреймам"""
        print("\n" + "=" * 80)
        print("🧠 MULTITHREAD REPLAY-ОПТИМИЗАЦИЯ ПАРАМЕТРОВ")
        print("=" * 80)
        
        # Группируем сигналы по таймфреймам
        timeframe_signals = {}
        for signal in self.signals:
            tf = signal['timeframe']
            if tf not in timeframe_signals:
                timeframe_signals[tf] = []
            timeframe_signals[tf].append(signal)
        
        print(f"📊 Найдены таймфреймы в сигналах: {', '.join(timeframe_signals.keys())}")
        print(f"🧠 Каждый таймфрейм будет оптимизирован параллельно на {self.max_workers} потоках")
        
        # Временно отключаем логи для чистого вывода
        original_level = logger.level
        logger.setLevel(logging.ERROR)
        
        timeframe_results = {}
        overall_best_pnl = -float('inf')
        overall_best_result = None
        overall_best_timeframe = None
        
        try:
            # Оптимизируем каждый таймфрейм отдельно
            for timeframe, signals in timeframe_signals.items():
                print(f"\n🎯 ОПТИМИЗАЦИЯ ТАЙМФРЕЙМА {timeframe} ({len(signals)} сигналов)")
                print("-" * 60)
                
                combinations = self.generate_parameter_combinations(timeframe)
                
                # Используем все комбинации для тестирования
                test_combinations = combinations
                print(f"🧠 Используем {self.max_workers} потоков для тестирования {len(test_combinations)} комбинаций")
                
                # Параллельное тестирование комбинаций
                tf_signals_dict = {timeframe: signals}
                all_results = self.test_parameters_parallel(tf_signals_dict, test_combinations, lookahead_hours)
                
                # УЛУЧШЕННАЯ ЛОГИКА ОПТИМИЗАЦИИ
                # 1. Фильтруем только прибыльные или близкие к безубыточности результаты
                profitable_results = [r for r in all_results if r['total_pnl'] >= -1.0]  # Убыток не более 1 USDT
                
                if not profitable_results:
                    # Если нет прибыльных, берем лучшие по минимальному убытку
                    profitable_results = sorted(all_results, key=lambda x: x['total_pnl'], reverse=True)[:10]
                
                # 2. Улучшенная метрика оптимизации - комплексная оценка
                def calculate_optimization_score(result):
                    pnl = result['total_pnl']
                    winrate = result['winrate']
                    avg_pnl = result['avg_pnl']
                    total_trades = result['total_trades']
                    trailing_rate = result['trailing_rate']
                    
                    # Базовая оценка - PnL с бонусом за винрейт
                    base_score = pnl + (winrate / 100 * 2.0)  # Бонус за винрейт
                    
                    # Бонус за высокую среднюю прибыль на сделку
                    if avg_pnl > 0:
                        base_score += avg_pnl * 0.5
                    
                    # Бонус за достаточное количество сделок (статистическая значимость)
                    if total_trades >= 10:
                        base_score += 1.0
                    elif total_trades >= 5:
                        base_score += 0.5
                    
                    # Бонус за активацию трейлинга (хорошая настройка параметров)
                    if trailing_rate > 30:
                        base_score += 0.5
                    
                    # Штраф за очень низкий винрейт
                    if winrate < 30:
                        base_score -= 2.0
                    
                    return base_score
                
                # 3. Сортируем по улучшенной метрике
                for result in profitable_results:
                    result['optimization_score'] = calculate_optimization_score(result)
                
                top_results = sorted(profitable_results, key=lambda x: x['optimization_score'], reverse=True)
                
                if top_results:
                    best_result = top_results[0]
                    timeframe_results[timeframe] = {
                        'best_result': best_result,
                        'top_3': top_results[:3],
                        'signals_count': len(signals)
                    }
                    
                    # Проверяем, лучший ли это результат среди всех таймфреймов
                    if best_result['total_pnl'] > overall_best_pnl:
                        overall_best_pnl = best_result['total_pnl']
                        overall_best_result = best_result
                        overall_best_timeframe = timeframe
                    
                    print(f"✅ Лучший результат для {timeframe}: PnL={best_result['total_pnl']:+.2f} USDT (Score: {best_result.get('optimization_score', 0):.2f})")
                    print(f"   📊 Винрейт: {best_result['winrate']:.1f}% | Ср.PnL: {best_result['avg_pnl']:+.3f} | Сделок: {best_result['total_trades']}")
                    print(f"   ⚙️ Параметры: SL={best_result['params']['stop_loss_percentage']:.1f}% TP={best_result['params']['trigger_profit_percentage']:.2f}% TL={best_result['params']['trailing_percentage']:.2f}% PL={best_result['params']['profit_lock_percentage']:.3f}%")
                else:
                    print(f"❌ Нет результатов для {timeframe}")
            
            # Выводим результаты по каждому таймфрейму
            if timeframe_results:
                print(f"\n📊 ИТОГОВЫЕ РЕЗУЛЬТАТЫ МНОГОПОТОЧНОЙ ОПТИМИЗАЦИИ")
                print("="*80)
                
                # Найдем лучший общий результат
                best_overall_pnl = -float('inf')
                best_overall_timeframe = None
                total_optimized_pnl = 0
                
                for timeframe, data in timeframe_results.items():
                    total_optimized_pnl += data['best_result']['total_pnl']
                    if data['best_result']['total_pnl'] > best_overall_pnl:
                        best_overall_pnl = data['best_result']['total_pnl']
                        best_overall_timeframe = timeframe
                
                # Сравнение общих результатов
                pnl_change = total_optimized_pnl - original_pnl
                pnl_change_pct = (pnl_change/abs(original_pnl)*100) if original_pnl != 0 else 0
                
                print(f"\n📈 ОБЩАЯ СРАВНИТЕЛЬНАЯ ТАБЛИЦА:")
                print(f"┌─────────────────────┬─────────────┬─────────────┬─────────────┐")
                print(f"│ Метрика             │    БЫЛО     │    СТАЛО    │  Изменение  │")
                print(f"├─────────────────────┼─────────────┼─────────────┼─────────────┤")
                print(f"│ 💰 Общая прибыль    │{original_pnl:>10.2f}   │{total_optimized_pnl:>10.2f}   │{pnl_change:>+10.2f}   │")
                print(f"└─────────────────────┴─────────────┴─────────────┴─────────────┘")
                
                if pnl_change > 0:
                    improvement = f"🚀 ОПТИМИЗАЦИЯ УСПЕШНА! +{pnl_change:.2f} USDT (+{pnl_change_pct:.1f}%) благодаря улучшенной метрике"
                elif pnl_change < -0.5:  # Только значительное ухудшение
                    improvement = f"📉 Минимальное ухудшение: {pnl_change:.2f} USDT ({pnl_change_pct:.1f}%) - возможно, нужно больше данных"
                else:
                    improvement = f"➡️ Стабильный результат: {pnl_change:+.2f} USDT (минимальное изменение)"
                
                print(f"\n{improvement}")
                
                # ТОП-3 лучших вариантов ДЛЯ КАЖДОГО таймфрейма
                print(f"\n🏆 ТОП-3 ЛУЧШИХ ВАРИАНТОВ ДЛЯ КАЖДОГО ТАЙМФРЕЙМА:")
                print("="*80)
                
                # Сортируем таймфреймы по общей прибыльности для красивого порядка
                sorted_timeframes = sorted(timeframe_results.items(), key=lambda x: x[1]['best_result']['total_pnl'], reverse=True)
                
                total_tested_combinations = 0
                
                for timeframe, data in sorted_timeframes:
                    signals_count = data['signals_count']
                    top_3_results = data['top_3']  # Уже отсортированные ТОП-3 результата
                    
                    print(f"\n📊 ТАЙМФРЕЙМ {timeframe} ({signals_count} сигналов):")
                    print("-" * 50)
                    
                    for i, result in enumerate(top_3_results):
                        medal = ["🥇", "🥈", "🥉"][i]
                        params = result['params']
                        
                        print(f"{medal} #{i+1}. PnL: {result['total_pnl']:+.2f} USDT (Score: {result.get('optimization_score', 0):.2f})")
                        print(f"   ⚙️ Параметры: SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.2f}% TL={params['trailing_percentage']:.2f}% PL={params['profit_lock_percentage']:.3f}%")
                        print(f"   📈 Метрики: Винрейт {result['winrate']:.1f}% | Трейлинг {result['trailing_rate']:.1f}% | Сделок {result['total_trades']} | Ср.PnL {result['avg_pnl']:+.3f}")
                    
                    total_tested_combinations += len(top_3_results)
                
                print(f"\n🏆️ Многопоточность позволила протестировать {total_tested_combinations} лучших комбинаций для всех таймфреймов параллельно!")
                print(f"🥇 УЛУЧШЕННАЯ ЛОГИКА ОПТИМИЗАЦИИ:")
                print(f"   • Фильтрация: Только прибыльные или близкие к безубыточности (≥-1 USDT)")
                print(f"   • Комплексная оценка: PnL + винрейт + стабильность")
                print(f"   • Бонусы: за высокий винрейт, среднюю прибыль, статистику")
                print(f"   • Штрафы: за низкий винрейт (<30%)")
                
            else:
                print("❌ Не удалось найти подходящие параметры ни для одного таймфрейма")
        
        finally:
            # Восстанавливаем уровень логирования
            logger.setLevel(original_level)
            
            # Сохраняем результаты оптимизации как атрибут объекта
            if timeframe_results:
                self.timeframe_results = timeframe_results
                # Создаем временный файл с настройками для генерации графиков
                self._create_temp_settings_file(timeframe_results)
    
    def _create_temp_settings_file(self, timeframe_results: Dict):
        """Создает временный файл с оптимальными настройками"""
        try:
            import json
            from datetime import datetime
            
            temp_data = {
                'export_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'export_type': 'temporary_optimization_results',
                'settings': {}
            }
            
            for timeframe, data in timeframe_results.items():
                best_result = data['best_result']
                temp_data['settings'][timeframe] = {
                    'params': best_result['params'],
                    'performance': {
                        'total_pnl': best_result['total_pnl'],
                        'winrate': best_result['winrate'],
                        'avg_pnl': best_result['avg_pnl'],
                        'total_trades': best_result['total_trades'],
                        'trailing_rate': best_result['trailing_rate'],
                        'optimization_score': best_result.get('optimization_score', 0)
                    }
                }
            
            # Сохраняем временный файл
            self.temp_settings_file = 'temp_best_settings.json'
            with open(self.temp_settings_file, 'w', encoding='utf-8') as f:
                json.dump(temp_data, f, indent=2, ensure_ascii=False)
            
            print(f"✅ Временный файл с настройками создан: {self.temp_settings_file}")
            
        except Exception as e:
            print(f"❌ Ошибка при создании временного файла: {e}")
            
    def _cleanup_temp_settings(self):
        """Удаляет временный файл с настройками"""
        try:
            import os
            if hasattr(self, 'temp_settings_file') and os.path.exists(self.temp_settings_file):
                os.remove(self.temp_settings_file)
                print(f"✅ Временный файл {self.temp_settings_file} удален")
        except Exception as e:
            print(f"❌ Ошибка при удалении временного файла: {e}")
    
    def offer_export_best_settings(self, timeframe_results: Dict):
        """Предлагает экспорт лучших настроек после оптимизации"""
        print("\n" + "=" * 80)
        print("💾 ЭКСПОРТ ЛУЧШИХ НАСТРОЕК")
        print("=" * 80)
        
        while True:
            print("\n🎯 Выберите действие:")
            print("1️⃣  Экспортировать ВСЕ лучшие настройки (по 1 варианту на таймфрейм)")
            print("2️⃣  Экспортировать ТОП-3 для выбранного таймфрейма")
            print("3️⃣  Экспортировать КОНКРЕТНЫЕ настройки")
            print("4️⃣  Пропустить экспорт")
            
            choice = input("\nВведите номер (1-4): ").strip()
            
            if choice == '1':
                self.export_all_best_settings(timeframe_results)
                break
            elif choice == '2':
                self.export_timeframe_top3(timeframe_results)
                break
            elif choice == '3':
                self.export_specific_settings(timeframe_results)
                break
            elif choice == '4':
                print("⏭️ Экспорт пропущен")
                break
            else:
                print("❌ Неверный выбор. Попробуйте снова.")
    
    def export_all_best_settings(self, timeframe_results: Dict):
        """Экспортирует лучшие настройки для всех таймфреймов"""
        export_data = {
            'export_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'export_type': 'all_best',
            'settings': {}
        }
        
        for timeframe, data in timeframe_results.items():
            best_result = data['best_result']
            export_data['settings'][timeframe] = {
                'params': best_result['params'],
                'performance': {
                    'total_pnl': best_result['total_pnl'],
                    'winrate': best_result['winrate'],
                    'avg_pnl': best_result['avg_pnl'],
                    'total_trades': best_result['total_trades'],
                    'trailing_rate': best_result['trailing_rate'],
                    'optimization_score': best_result.get('optimization_score', 0)
                }
            }
        
        filename = f"best_settings_all_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Экспортированы лучшие настройки для {len(timeframe_results)} таймфреймов в {filename}")
        
        # Показываем краткую сводку
        print("\n📊 Экспортированные настройки:")
        for timeframe, data in export_data['settings'].items():
            params = data['params']
            perf = data['performance']
            print(f"  {timeframe}: SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.2f}% | PnL={perf['total_pnl']:+.2f} (Score:{perf['optimization_score']:.2f})")
    
    def export_timeframe_top3(self, timeframe_results: Dict):
        """Экспортирует ТОП-3 для выбранного таймфрейма"""
        print("\n📋 Доступные таймфреймы:")
        timeframes = list(timeframe_results.keys())
        for i, tf in enumerate(timeframes, 1):
            signals_count = timeframe_results[tf]['signals_count']
            best_pnl = timeframe_results[tf]['best_result']['total_pnl']
            print(f"  {i}. {tf} ({signals_count} сигналов, лучший PnL: {best_pnl:+.2f})")
        
        while True:
            try:
                choice = int(input(f"\nВыберите таймфрейм (1-{len(timeframes)}): ")) - 1
                if 0 <= choice < len(timeframes):
                    selected_tf = timeframes[choice]
                    break
                else:
                    print("❌ Неверный номер")
            except ValueError:
                print("❌ Введите число")
        
        export_data = {
            'export_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'export_type': 'timeframe_top3',
            'timeframe': selected_tf,
            'top3_settings': []
        }
        
        top_3_results = timeframe_results[selected_tf]['top_3']
        for i, result in enumerate(top_3_results):
            export_data['top3_settings'].append({
                'rank': i + 1,
                'params': result['params'],
                'performance': {
                    'total_pnl': result['total_pnl'],
                    'winrate': result['winrate'],
                    'avg_pnl': result['avg_pnl'],
                    'total_trades': result['total_trades'],
                    'trailing_rate': result['trailing_rate'],
                    'optimization_score': result.get('optimization_score', 0)
                }
            })
        
        filename = f"top3_settings_{selected_tf}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Экспортированы ТОП-3 настройки для {selected_tf} в {filename}")
    
    def export_specific_settings(self, timeframe_results: Dict):
        """Экспортирует конкретные выбранные настройки"""
        export_data = {
            'export_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'export_type': 'specific_selection',
            'selected_settings': []
        }
        
        print("\n🎯 Выберите конкретные настройки для экспорта:")
        
        # Показываем все доступные варианты
        all_options = []
        option_num = 1
        
        for timeframe, data in timeframe_results.items():
            top_3_results = data['top_3']
            for i, result in enumerate(top_3_results):
                all_options.append((timeframe, i, result))
                rank = ["🥇", "🥈", "🥉"][i]
                params = result['params']
                print(f"  {option_num:2d}. {timeframe} {rank} - SL={params['stop_loss_percentage']:.1f}% TP={params['trigger_profit_percentage']:.2f}% | PnL={result['total_pnl']:+.2f}")
                option_num += 1
        
        print("\n💡 Введите номера через пробел (например: 1 3 5) или 'all' для всех:")
        selection = input("Ваш выбор: ").strip()
        
        if selection.lower() == 'all':
            selected_indices = list(range(len(all_options)))
        else:
            try:
                selected_indices = [int(x) - 1 for x in selection.split()]
                selected_indices = [i for i in selected_indices if 0 <= i < len(all_options)]
            except ValueError:
                print("❌ Неверный формат ввода")
                return
        
        if not selected_indices:
            print("❌ Не выбрано ни одной настройки")
            return
        
        for idx in selected_indices:
            timeframe, rank, result = all_options[idx]
            export_data['selected_settings'].append({
                'timeframe': timeframe,
                'rank': rank + 1,
                'params': result['params'],
                'performance': {
                    'total_pnl': result['total_pnl'],
                    'winrate': result['winrate'],
                    'avg_pnl': result['avg_pnl'],
                    'total_trades': result['total_trades'],
                    'trailing_rate': result['trailing_rate'],
                    'optimization_score': result.get('optimization_score', 0)
                }
            })
        
        filename = f"selected_settings_{len(selected_indices)}items_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Экспортировано {len(selected_indices)} настроек в {filename}")
    
    def run_full_testing_pipeline(self):
        """Запускает полный конвейер тестирования по этапам"""
        print("\n" + "=" * 80)
        print("🚀 АВТОМАТИЧЕСКИЙ КОНВЕЙЕР ТЕСТИРОВАНИЯ ЗАПУЩЕН")
        print("=" * 80)
        
        # Этап 1: Быстрая оптимизация
        print("\n🎯 ЭТАП 1/3: БЫСТРАЯ ОПТИМИЗАЦИЯ")
        print("-" * 50)
        self.apply_testing_method_settings('fast_optimization')
        stage1_start = time.time()
        self.run_replay_multithread()
        stage1_time = time.time() - stage1_start
        
        # Этап 2: Детальная валидация
        print("\n🔬 ЭТАП 2/3: ДЕТАЛЬНАЯ ВАЛИДАЦИЯ")
        print("-" * 50)
        print("🔄 Переключение на режим с проскальзыванием и микроструктурой...")
        self.apply_testing_method_settings('detailed_validation')
        stage2_start = time.time()
        self.run_replay_multithread()
        stage2_time = time.time() - stage2_start
        
        # Этап 3: Финальная проверка
        print("\n📈 ЭТАП 3/3: ФИНАЛЬНАЯ ПРОВЕРКА")
        print("-" * 50)
        print("🔄 Переключение на максимальную точность + Monte Carlo...")
        self.apply_testing_method_settings('final_validation')
        stage3_start = time.time()
        self.run_replay_multithread()
        stage3_time = time.time() - stage3_start
        
        # Сводка по всем этапам
        print("\n" + "=" * 80)
        print("📊 СВОДКА ПО АВТОМАТИЧЕСКОМУ КОНВЕЙЕРУ")
        print("=" * 80)
        print(f"⏱️ Этап 1 (Быстрая оптимизация): {stage1_time:.1f}с")
        print(f"⏱️ Этап 2 (Детальная валидация): {stage2_time:.1f}с")
        print(f"⏱️ Этап 3 (Финальная проверка): {stage3_time:.1f}с")
        print(f"⏱️ Общее время: {stage1_time + stage2_time + stage3_time:.1f}с")
        print("")
        print("🎯 РЕКОМЕНДАЦИИ ДЛЯ ПРОДАКШН:")
        print("   • Используйте параметры из Этапа 3 для реальной торговли")
        print("   • Мониторьте отклонения от бэктеста в первые дни")
        print("   • Начните с минимальных размеров позиций")
        print("   • Ведите журнал сделок для анализа")
        print("=" * 80)

    def _show_post_backtest_menu(self, trades_data):
        """Показать меню после завершения бэктеста"""
        while True:
            print("\n" + "=" * 50)
            print("📊 Бэктест завершен!")
            print("=" * 50)
            print("Выберите действие:")
            print("1. Сгенерировать графики ордеров")
            print("2. Экспортировать оптимальные настройки")
            print("3. Вернуться в главное меню")
            print("4. Выход")
            print("=" * 50)
            
            try:
                choice = input("Введите номер (1-4): ").strip()
                
                if choice == '1':
                    # Генерация графиков
                    self._generate_order_charts_menu(trades_data)
                elif choice == '2':
                    # Экспорт настроек (если есть результаты оптимизации)
                    if hasattr(self, 'timeframe_results') and self.timeframe_results:
                        self.offer_export_best_settings(self.timeframe_results)
                    else:
                        print("❌ Нет результатов оптимизации для экспорта")
                elif choice == '3':
                    # Вернуться в главное меню
                    return
                elif choice == '4':
                    # Выход
                    print("👋 До свидания!")
                    import sys
                    sys.exit(0)
                else:
                    print("❌ Неверный выбор. Попробуйте снова.")
            except KeyboardInterrupt:
                print("\n👋 До свидания!")
                import sys
                sys.exit(0)
            except Exception as e:
                print(f"❌ Ошибка: {e}")

    def _generate_order_charts_menu(self, trades_data):
        """Генерация графиков ордеров после бэктеста"""
        print(f"🔍 [DEBUG] Вызов generate_order_charts_menu с {len(trades_data) if trades_data else 0} сделками")  # Debug line
        try:
            # Сначала спрашиваем пользователя, какой тип графиков он хочет сгенерировать
            print("\n📊 Выберите тип графиков для генерации:")
            print("1. Стандартные графики ордеров")
            print("2. Сравнительные графики ордеров (оптимальные настройки)")
            
            while True:
                try:
                    chart_choice = input("Введите номер (1-2): ").strip()
                    if chart_choice in ['1', '2']:
                        break
                    else:
                        print("Пожалуйста, введите 1 или 2")
                except ValueError:
                    print("Пожалуйста, введите число 1 или 2")
            
            if chart_choice == '1':
                # Генерация стандартных графиков
                try:
                    from order_chart_generator import ChartGenerator
                    chart_generator = ChartGenerator(self)
                    print("✅ [DEBUG] ChartGenerator успешно импортирован и создан")  # Debug line
                    
                    # Спрашиваем пользователя, хочет ли он сгенерировать графики
                    print("\n📊 Хотите сгенерировать стандартные графики ордеров? (1 - Да, 2 - Нет)")
                    while True:
                        try:
                            response = int(input("Введите 1 или 2: ").strip())
                            if response in [1, 2]:
                                break
                            else:
                                print("Пожалуйста, введите 1 или 2")
                        except ValueError:
                            print("Пожалуйста, введите число 1 или 2")
                    
                    if response == 1:
                        print("📈 [DEBUG] Пользователь выбрал генерацию стандартных графиков")  # Debug line
                        # Генерируем все графики (передаем count=None, чтобы функция сама спросила)
                        chart_generator.generate_all_order_charts(trades_data, count=None)
                        print("✅ [DEBUG] Генерация стандартных графиков завершена")  # Debug line
                    else:
                        print("⏭️ [DEBUG] Пользователь отказался от генерации стандартных графиков")  # Debug line
                except ImportError as e:
                    print(f"⚠️ Модуль order_chart_generator не найден. Генерация графиков ордеров будет недоступна. Ошибка: {e}")
            else:
                # Генерация сравнительных графиков с оптимальными настройками
                try:
                    from otim_order_chart_generator import OtimChartGenerator
                    otim_chart_generator = OtimChartGenerator(self)
                    print("✅ [DEBUG] OtimChartGenerator успешно импортирован и создан")  # Debug line
                    
                    # Спрашиваем пользователя, хочет ли он сгенерировать графики
                    print("\n📊 Хотите сгенерировать сравнительные графики ордеров с оптимальными настройками? (1 - Да, 2 - Нет)")
                    while True:
                        try:
                            response = int(input("Введите 1 или 2: ").strip())
                            if response in [1, 2]:
                                break
                            else:
                                print("Пожалуйста, введите 1 или 2")
                        except ValueError:
                            print("Пожалуйста, введите число 1 или 2")
                    
                    if response == 1:
                        print("📈 [DEBUG] Пользователь выбрал генерацию сравнительных графиков")  # Debug line
                        # Генерируем все графики (передаем count=None, чтобы функция сама спросила)
                        otim_chart_generator.generate_all_order_charts(trades_data, count=None)
                        print("✅ [DEBUG] Генерация сравнительных графиков завершена")  # Debug line
                    else:
                        print("⏭️ [DEBUG] Пользователь отказался от генерации сравнительных графиков")  # Debug line
                except ImportError as e:
                    print(f"⚠️ Модуль otim_order_chart_generator не найден. Генерация сравнительных графиков ордеров будет недоступна. Ошибка: {e}")
                except Exception as e:
                    print(f"❌ Ошибка при генерации графиков ордеров: {e}")
                    import traceback
                    traceback.print_exc()
        except Exception as e:
            print(f"❌ Ошибка при генерации графиков ордеров: {e}")
            import traceback
            traceback.print_exc()

def main():
    """Главная функция"""
    try:
        # Простой стартовый текст без рамки
        print("\n🚀 МНОГОПОТОЧНЫЙ ТОРГОВЫЙ БЭКТЕСТЕР")
        print("⚙️ ОПТИМИЗАЦИЯ ПО ТАЙМФРЕЙМАМ")
        print("📈 Параллельный подбор параметров для каждого таймфрейма")
        print()
        
        # Краткая информация о системе
        print("🔍 Инициализация системы...")
        
        # Создание бэктестера
        backtester = MultiThreadBacktester('trading_backtest_config.json', 'test_signals.txt')
        
        # Краткая сводка
        print(f"✅ Система готова! Загружено {len(backtester.signals)} сигналов")
        print(f"💰 Начальный баланс: {backtester.config['backtest']['initial_balance']} USDT")
        print(f"🧠 Многопоточность: {backtester.max_workers} потоков")

        # Интерактивное меню выбора режима
        while True:
            print("\n======================================================================")
            print("🚀 МНОГОПОТОЧНЫЙ БЭКТЕСТЕР - ВЫБОР РЕЖИМА")
            print("======================================================================")
            print("1. Multithread Replay — параллельный прогон сигналов")
            print("2. Multithread Replay + оптимизация по таймфреймам  ⭐")
            print("3. Удалить все ранее созданные файлы теста")
            print("4. Импорт оптимальных настроек")
            print("5. Сброс настроек к заводским")
            print("6. Перезагрузка")
            print("7. Выход")
            print("======================================================================")
            choice = input("Введите номер и нажмите Enter: ").strip()

            if choice == '1':
                # Выбор метода тестирования
                testing_method = choose_testing_method()
                backtester.config.setdefault('backtest', {})['mode'] = 'replay'
                backtester.config.setdefault('backtest', {})['testing_method'] = testing_method
                backtester.config.setdefault('replay', {})['optimize'] = False
                
                # Применяем настройки в зависимости от выбранного метода
                backtester.apply_testing_method_settings(testing_method)
                
                # Показываем анимацию загрузки в стиле Windows 7
                print("\n📊 Подготовка к тестированию...")
                show_windows7_loading_animation()
                
                backtester.run_replay_multithread()
                # Убираем break, чтобы после завершения бэктеста вернуться в главное меню
                # break
            elif choice == '2':
                # Выбор метода тестирования
                testing_method = choose_testing_method()
                backtester.config.setdefault('backtest', {})['mode'] = 'replay'
                backtester.config.setdefault('backtest', {})['testing_method'] = testing_method
                backtester.config.setdefault('replay', {})['optimize'] = True
                
                # Выбор подхода к оптимизации
                optimization_approach = get_optimization_approach()
                if optimization_approach is None:
                    print("❌ Оптимизация отменена")
                    continue
                
                # Сохраняем выбор подхода в конфигурации
                backtester.config.setdefault('optimization', {})['approach'] = optimization_approach
                
                # Применяем настройки в зависимости от выбранного метода
                backtester.apply_testing_method_settings(testing_method)
                
                # Показываем анимацию загрузки в стиле Windows 7
                print("\n📊 Подготовка к тестированию...")
                show_windows7_loading_animation()
                
                if testing_method == 'full_pipeline':
                    backtester.run_full_testing_pipeline()
                else:
                    backtester.run_replay_multithread()
                # Убираем break, чтобы после завершения бэктеста вернуться в главное меню
                # break
            elif choice == '3':
                # Удаление всех ранее созданных файлов теста
                delete_test_files()
                continue
            elif choice == '4':
                # Импорт оптимальных настроек
                import_optimal_settings()
                continue
            elif choice == '5':
                # Сброс настроек к заводским
                reset_to_factory_settings()
                continue
            elif choice == '6':
                # Перезагрузка
                reload_application()
                continue
            elif choice == '7':
                print("👋 До свидания!")
                return
            else:
                print("❌ Неверный выбор, попробуйте снова.")
    
    except Exception as e:
        logger.error(f"Ошибка в главной функции: {e}")
        import traceback
        traceback.print_exc()

def show_windows7_loading_animation(duration=3):
    """Показывает анимацию загрузки в стиле Windows 7 с движущимися кружками"""
    import time
    import sys
    
    # Символы для анимации
    frames = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷']
    circles = ['○', '○', '○', '○', '○']
    filled_circle = '●'
    
    start_time = time.time()
    while time.time() - start_time < duration:
        # Анимация с движущимися кружками
        for i in range(len(frames)):
            # Создаем строку с движущимися кружками
            progress_line = ""
            for j in range(len(circles)):
                if j == i % len(circles):
                    progress_line += filled_circle + " "
                else:
                    progress_line += circles[j] + " "
            
            sys.stdout.write(f'\r🔄 Подготовка данных [{frames[i]}] {progress_line}')
            sys.stdout.flush()
            time.sleep(0.2)
    
    # Завершающая строка
    sys.stdout.write('\r✅ Подготовка завершена!                              \n')
    sys.stdout.flush()

def choose_testing_method() -> str:
    """Выбор стратегии тестирования сигналов по этапам"""
    while True:
        print("\n" + "=" * 80)
        print("🎯 РЕКОМЕНДУЕМАЯ СТРАТЕГИЯ ПОЭТАПНОГО ТЕСТИРОВАНИЯ")
        print("=" * 80)
        print("🚀 1️⃣  БЫСТРАЯ ОПТИМИЗАЦИЯ - Текущий подход (рекомендуется)")
        print("   • Параллельный подбор параметров по таймфреймам")
        print("   • Базовое OHLC моделирование для скорости")
        print("   • Отличный первый этап для поиска перспективных настроек")
        print("")
        print("🔬 2️⃣  ДЕТАЛЬНАЯ ВАЛИДАЦИЯ - Проскальзывание + микроструктура")
        print("   • 15 внутрисвечевых шагов с реалистичным моделированием")
        print("   • Учет спредов, проскальзывания и задержек исполнения")
        print("   • Валидация лучших параметров из этапа 1")
        print("")
        print("📈 3️⃣  ФИНАЛЬНАЯ ПРОВЕРКА - Тиковая симуляция")
        print("   • Максимально точное моделирование с тиковыми данными")
        print("   • Статистические доверительные интервалы (Monte Carlo)")
        print("   • Подготовка для продакшн-тестирования")
        print("")
        print("💡 4️⃣  АВТОМАТИЧЕСКИЙ КОНВЕЙЕР - Все этапы последовательно")
        print("   • Автоматически проходит все 3 этапа тестирования")
        print("   • Сравнительный анализ результатов на каждом этапе")
        print("   • Рекомендации для продакшн-запуска")
        print("=" * 80)

        method_choice = input("Выберите этап тестирования (1-4): ").strip()
        
        if method_choice == '1':
            print("✅ Выбран: БЫСТРАЯ ОПТИМИЗАЦИЯ (базовое OHLC моделирование)")
            print("🎯 Этап 1/3: Поиск оптимальных параметров")
            return 'fast_optimization'
        elif method_choice == '2':
            print("✅ Выбран: ДЕТАЛЬНАЯ ВАЛИДАЦИЯ (проскальзывание + микроструктура)")
            print("🎯 Этап 2/3: Валидация с реалистичным моделированием")
            return 'detailed_validation'
        elif method_choice == '3':
            print("✅ Выбран: ФИНАЛЬНАЯ ПРОВЕРКА (тиковая симуляция)")
            print("🎯 Этап 3/3: Максимально точное тестирование")
            return 'final_validation'
        elif method_choice == '4':
            print("✅ Выбран: АВТОМАТИЧЕСКИЙ КОНВЕЙЕР (все этапы)")
            print("🎯 Полный цикл: Оптимизация → Валидация → Финальная проверка")
            return 'full_pipeline'
        else:
            print("❌ Неверный выбор. Попробуйте снова.")

def get_optimization_approach() -> Optional[int]:
    """Выбор подхода к оптимизации с числовым ответом"""
    print("\n" + "=" * 60)
    print("🎯 ПОДХОДЫ К ОПТИМИЗАЦИИ")
    print("=" * 60)
    
    # Заголовки таблицы
    print(f"{'Номер':<8} {'Подход':<15} {'Комбинаций':<12} {'Время':<15} {'Точность':<12}")
    print("-" * 60)
    
    # Данные таблицы
    approaches = [
        (1, "Быстрая", "100", "< 1 мин", "Низкая"),
        (2, "Стандартная", "500", "5-15 мин", "Средняя"),
        (3, "Точная", "1,000", "15-30 мин", "Высокая"),
        (4, "Полная", "12,960,000", "1.5 дня", "Максимальная")
    ]
    
    # Вывод данных
    for approach in approaches:
        print(f"{approach[0]:<8} {approach[1]:<15} {approach[2]:<12} {approach[3]:<15} {approach[4]:<12}")
    
    print("=" * 60)
    print("💡 Рекомендации по выбору:")
    print("   • 1 - Быстрая: Для тестирования и проверки работоспособности")
    print("   • 2 - Стандартная: Для ежедневной оптимизации")
    print("   • 3 - Точная: Для недельной финальной настройки")
    print("   • 4 - Полная: Для месячной глубокой оптимизации")
    print("=" * 60)
    
    while True:
        try:
            choice = input("Введите номер подхода (1-4): ").strip()
            if choice.lower() == 'q':
                print("\n\n❌ Отменено пользователем")
                return None
            choice_num = int(choice)
            if 1 <= choice_num <= 4:
                print(f"✅ Выбран подход: {approaches[choice_num-1][1]} ({approaches[choice_num-1][2]} комбинаций)")
                return choice_num
            else:
                print("❌ Неверный выбор. Введите число от 1 до 4.")

        except ValueError:
            print("❌ Пожалуйста, введите корректное число.")
        except KeyboardInterrupt:
            print("\n\n❌ Отменено пользователем")
            return None

def delete_test_files():
    """Удаление всех ранее созданных файлов теста"""
    import os
    import shutil
    
    # Список директорий и файлов для удаления
    test_items = [
        "data_cache",
        "order_charts",
        "signal_charts",
        "optimization_charts",
        "optimization_results.json",
        "backtest_results.json",
        "strategy_optimization_report.txt",
        "enhanced_backtest_report.txt",
        "performance_comparison.json"
    ]
    
    print("\n🗑️  УДАЛЕНИЕ ВСЕХ ФАЙЛОВ ТЕСТА")
    print("=" * 50)
    
    deleted_count = 0
    for item in test_items:
        try:
            if os.path.exists(item):
                if os.path.isdir(item):
                    shutil.rmtree(item)
                    print(f"✅ Удалена директория: {item}")
                else:
                    os.remove(item)
                    print(f"✅ Удален файл: {item}")
                deleted_count += 1
            else:
                print(f"⚠️  Не найдено: {item}")
        except Exception as e:
            print(f"❌ Ошибка при удалении {item}: {e}")
    
    print("=" * 50)
    print(f"✅ Удалено {deleted_count} элементов")
    input("\nНажмите Enter для возврата в меню...")

def import_optimal_settings():
    """Импорт оптимальных настроек из файла"""
    import os
    import json
    from datetime import datetime
    
    print("\n📥 ИМПОРТ ОПТИМАЛЬНЫХ НАСТРОЕК")
    print("=" * 50)
    
    # Поиск файлов с настройками
    settings_files = [f for f in os.listdir('.') if f.startswith('best_settings_') and f.endswith('.json')]
    
    if not settings_files:
        print("❌ Не найдено файлов с оптимальными настройками")
        print("💡 Экспортируйте настройки через оптимизацию, чтобы получить файлы настроек")
        input("\nНажмите Enter для возврата в меню...")
        return
    
    # Сортировка файлов по дате (новые первыми)
    settings_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    
    print("Найдены файлы с настройками:")
    for i, filename in enumerate(settings_files, 1):
        mod_time = os.path.getmtime(filename)
        mod_time_str = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
        print(f"  {i}. {filename} (от {mod_time_str})")
    
    print(f"  {len(settings_files) + 1}. Отмена")
    
    while True:
        try:
            choice = input(f"\nВыберите файл (1-{len(settings_files) + 1}): ").strip()
            choice_num = int(choice)
            
            if choice_num == len(settings_files) + 1:
                print("↩️  Импорт отменен")
                return
            elif 1 <= choice_num <= len(settings_files):
                selected_file = settings_files[choice_num - 1]
                break
            else:
                print(f"❌ Неверный выбор. Введите число от 1 до {len(settings_files) + 1}")
        except ValueError:
            print("❌ Пожалуйста, введите корректное число")
        except KeyboardInterrupt:
            print("\n↩️  Импорт отменен")
            return
    
    try:
        # Чтение выбранного файла
        with open(selected_file, 'r', encoding='utf-8') as f:
            settings_data = json.load(f)
        
        # Создание файла конфигурации с импортированными настройками
        config_filename = f"imported_config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Базовая конфигурация
        new_config = {
            "backtest": {
                "initial_balance": 1000,
                "commission": 0.001
            },
            "trading": {
                "position_size_percentage": 1.0,
                "leverage": 1.0
            },
            "replay": {
                "stop_loss_percentage": 1.0,
                "trigger_profit_percentage": 0.5,
                "trailing_percentage": 0.5,
                "profit_lock_percentage": 0.25,
                "lookahead_hours": 24
            },
            "optimization": {
                "approach": 2
            }
        }
        
        # Применение настроек из файла
        if 'settings' in settings_data:
            # Если это файл с настройками для нескольких таймфреймов
            timeframe_settings = settings_data['settings']
            # Берем настройки первого таймфрейма как основные
            first_timeframe = list(timeframe_settings.keys())[0]
            params = timeframe_settings[first_timeframe]['params']
        elif 'top3_settings' in settings_data:
            # Если это файл с ТОП-3 настройками
            params = settings_data['top3_settings'][0]['params']
        elif 'selected_settings' in settings_data:
            # Если это файл с выбранными настройками
            params = settings_data['selected_settings'][0]['params']
        else:
            print("❌ Неверный формат файла настроек")
            input("\nНажмите Enter для возврата в меню...")
            return
        
        # Обновление параметров в конфигурации
        new_config['replay']['stop_loss_percentage'] = params['stop_loss_percentage']
        new_config['replay']['trigger_profit_percentage'] = params['trigger_profit_percentage']
        new_config['replay']['trailing_percentage'] = params['trailing_percentage']
        new_config['replay']['profit_lock_percentage'] = params['profit_lock_percentage']
        
        # Сохранение новой конфигурации
        with open(config_filename, 'w', encoding='utf-8') as f:
            json.dump(new_config, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Настройки успешно импортированы из {selected_file}")
        print(f"💾 Новая конфигурация сохранена в {config_filename}")
        print("💡 Чтобы использовать импортированные настройки, переименуйте файл в trading_backtest_config.json")
        input("\nНажмите Enter для возврата в меню...")
        
    except Exception as e:
        print(f"❌ Ошибка при импорте настроек: {e}")
        input("\nНажмите Enter для возврата в меню...")

def reset_to_factory_settings():
    """Сброс настроек к заводским"""
    import os
    import json
    from datetime import datetime
    
    print("\n🔄 СБРОС НАСТРОЕК К ЗАВОДСКИМ")
    print("=" * 50)
    
    # Заводская конфигурация
    factory_config = {
        "backtest": {
            "initial_balance": 1000,
            "commission": 0.001
        },
        "trading": {
            "position_size_percentage": 1.0,
            "leverage": 1.0
        },
        "replay": {
            "stop_loss_percentage": 1.0,
            "trigger_profit_percentage": 0.5,
            "trailing_percentage": 0.5,
            "profit_lock_percentage": 0.25,
            "lookahead_hours": 24
        },
        "optimization": {
            "approach": 2,
            "parameters": {
                "stop_loss_percentage": {
                    "min": 0.5,
                    "max": 3.0,
                    "step": 0.1
                },
                "trigger_profit_percentage": {
                    "min": 0.3,
                    "max": 2.0,
                    "step": 0.1
                },
                "trailing_percentage": {
                    "min": 0.1,
                    "max": 1.0,
                    "step": 0.1
                },
                "profit_lock_percentage": {
                    "min": 0.1,
                    "max": 1.0,
                    "step": 0.1
                }
            }
        },
        "strategies": {
            "BB": {
                "width_lookback_period": 15,
                "num_std_dev": 2.0
            },
            "EMA": {
                "ema_period1": 3,
                "ema_period2": 20
            },
            "VOLUM": {
                "volume_average_window": 20
            },
            "STOH": {
                "stoch_k": 14,
                "stoch_d": 3
            }
        }
    }
    
    # Проверяем существование файла конфигурации
    config_file = "trading_backtest_config.json"
    
    if os.path.exists(config_file):
        # Создаем резервную копию текущей конфигурации
        backup_file = f"trading_backtest_config_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        try:
            import shutil
            shutil.copy2(config_file, backup_file)
            print(f"💾 Резервная копия текущих настроек сохранена в {backup_file}")
        except Exception as e:
            print(f"⚠️  Не удалось создать резервную копию: {e}")
    
    # Сохраняем заводские настройки
    try:
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(factory_config, f, indent=2, ensure_ascii=False)
        print(f"✅ Настройки успешно сброшены к заводским")
        print(f"💾 Заводская конфигурация сохранена в {config_file}")
    except Exception as e:
        print(f"❌ Ошибка при сбросе настроек: {e}")
    
    input("\nНажмите Enter для возврата в меню...")

def reload_application():
    """Перезагрузка приложения"""
    import sys
    import os
    
    print("\n🔄 ПЕРЕЗАГРУЗКА ПРИЛОЖЕНИЯ")
    print("=" * 50)
    print("🔄 Перезапуск бэктестера...")
    
    try:
        # Получаем путь к текущему скрипту
        script_path = os.path.abspath(__file__)
        
        # Закрываем все открытые файлы и ресурсы
        print("🔄 Очистка ресурсов...")
        
        # Перезапуск скрипта
        print("🚀 Перезапуск...")
        os.execv(sys.executable, [sys.executable] + sys.argv)
        
    except Exception as e:
        print(f"❌ Ошибка при перезагрузке: {e}")
        print("💡 Попробуйте перезапустить приложение вручную")
        input("\nНажмите Enter для возврата в меню...")

if __name__ == "__main__":
    main()