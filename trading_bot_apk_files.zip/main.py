#!/usr/bin/env python3
# -*- coding: utf-8 -*-

try:
    import kivy
    kivy.require('2.0.0')
    
    from kivy.app import App
    from kivy.uix.screenmanager import ScreenManager, Screen
    from kivy.core.window import Window
    from kivy.uix.popup import Popup
    from kivy.uix.label import Label
    import os
    import sys
    
    # Добавляем путь к текущей директории для импорта модулей
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    
    # Импортируем основные компоненты торгового бота
    try:
        from menu import setup_database, check_database
        HAS_TRADING_BOT = True
    except ImportError as e:
        print(f"Ошибка импорта торгового бота: {e}")
        HAS_TRADING_BOT = False
    
    class MainScreen(Screen):
        def __init__(self, **kwargs):
            super(MainScreen, self).__init__(**kwargs)
            # Инициализация базы данных
            self.init_database()
        
        def init_database(self):
            """Инициализация базы данных"""
            try:
                if setup_database():
                    # Обновляем статус через kv файл
                    if hasattr(self, 'ids') and 'status_label' in self.ids:
                        self.ids.status_label.text = 'Статус: База данных создана'
                else:
                    if hasattr(self, 'ids') and 'status_label' in self.ids:
                        self.ids.status_label.text = 'Статус: Ошибка создания БД'
            except Exception as e:
                self.show_error(f"Ошибка инициализации БД: {str(e)}")
        
        def start_trading_bot(self):
            """Запуск торгового бота"""
            if hasattr(self, 'ids') and 'status_label' in self.ids:
                self.ids.status_label.text = 'Статус: Запуск торгового бота...'
            # Здесь будет код запуска торгового бота
            
        def run_backtest(self):
            """Запуск бэктеста"""
            if hasattr(self, 'ids') and 'status_label' in self.ids:
                self.ids.status_label.text = 'Статус: Запуск бэктеста...'
            # Здесь будет код запуска бэктеста
            
        def import_settings(self):
            """Импорт оптимальных настроек"""
            if hasattr(self, 'ids') and 'status_label' in self.ids:
                self.ids.status_label.text = 'Статус: Импорт настроек...'
            # Здесь будет код импорта настроек
            
        def reset_settings(self):
            """Сброс к заводским настройкам"""
            if hasattr(self, 'ids') and 'status_label' in self.ids:
                self.ids.status_label.text = 'Статус: Сброс настроек...'
            # Здесь будет код сброса настроек
        
        def show_error(self, message):
            """Показать сообщение об ошибке"""
            # В мобильной версии просто печатаем в лог
            print(f"Ошибка: {message}")
    
    class TradingBotApp(App):
        def build(self):
            # Создаем менеджер экранов
            sm = ScreenManager()
            
            # Добавляем основной экран
            sm.add_widget(MainScreen(name='main'))
            
            return sm

    if __name__ == '__main__':
        TradingBotApp().run()
        
except ImportError:
    print("Kivy не установлен. Для запуска мобильной версии установите Kivy и Buildozer.")
    print("Инструкции по установке смотрите в README_ANDROID.md")