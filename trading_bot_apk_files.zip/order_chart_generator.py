#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import mplfinance as mpf
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random
from collections import defaultdict
import matplotlib.gridspec as gridspec


class ChartGenerator:
    def __init__(self, backtester):
        """Инициализация генератора графиков"""
        self.backtester = backtester
    
    def calculate_ema(self, data, period):
        """Расчет экспоненциальной скользящей средней"""
        return data['close'].ewm(span=period, adjust=False).mean()
    
    def calculate_bollinger_bands(self, df, window=15, num_std_dev=2.0, calculate_from_beginning=True):
        """
        Расчет полос Боллинджера
        
        Args:
            df: DataFrame с данными
            window: Период окна
            num_std_dev: Количество стандартных отклонений
            calculate_from_beginning: Рассчитывать с начала данных (True) или только для отображаемого участка (False)
        """
        if calculate_from_beginning:
            # Рассчитываем индикаторы для всего датасета, а не только для отображаемого участка
            sma = df['close'].rolling(window=window, min_periods=1).mean()
            std = df['close'].rolling(window=window, min_periods=1).std()
        else:
            # Старый способ - только для отображаемого участка
            sma = df['close'].rolling(window=window).mean()
            std = df['close'].rolling(window=window).std()
            
        upper = sma + (std * num_std_dev)
        lower = sma - (std * num_std_dev)
        return sma, upper, lower
    
    def calculate_stochastic(self, data, k=14, d=3):
        """Расчет стохастического осциллятора"""
        low_low = data['low'].rolling(window=k).min()
        high_high = data['high'].rolling(window=k).max()
        k_line = 100 * (data['close'] - low_low) / (high_high - low_low)
        d_line = k_line.rolling(window=d).mean()
        return k_line, d_line

    def generate_signal_chart(self, df, symbol, timeframe, strategy, direction, timestamp, save_path=None):
        """
        Генерация графика сигнала с индикаторами
        
        Args:
            df: DataFrame с данными OHLCV
            symbol: Символ валютной пары
            timeframe: Таймфрейм
            strategy: Название стратегии
            direction: Направление сигнала (Buy/Sell)
            timestamp: Временная метка сигнала
            save_path: Путь для сохранения графика (опционально)
        """
        try:
            # Убедимся, что direction в верхнем регистре для совместимости
            direction = direction.upper()
            
            # Определяем индекс сигнала
            signal_index = df.index.get_loc(timestamp)
            
            # Определяем диапазон для отображения (20 свечей до сигнала и 50 после)
            candles_before = min(20, signal_index)  # Максимум 20 свечей до сигнала
            candles_after = min(50, len(df) - signal_index - 1)  # Максимум 50 свечей после сигнала
            
            start_index = max(0, signal_index - candles_before)
            end_index = min(len(df), signal_index + candles_after + 1)  # +1 для включения сигнала
            
            # Убедимся, что у нас есть данные
            if start_index >= end_index:
                start_index = max(0, end_index - 1)
            
            chart_df = df.iloc[start_index:end_index].copy()
            
            # Рассчитываем ВСЕ индикаторы независимо от стратегии
            apds = []
            
            # EMA индикаторы (отображаем для всех стратегий)
            ema_config = self.backtester.strategies_config.get('EMA', {})
            ema_period1 = ema_config.get('ema_period1', 3) if ema_config else 3
            ema_period2 = ema_config.get('ema_period2', 20) if ema_config else 20
            chart_df['ema_period1'] = self.calculate_ema(chart_df, ema_period1)
            chart_df['ema_period2'] = self.calculate_ema(chart_df, ema_period2)
            apds.extend([
                mpf.make_addplot(chart_df['ema_period1'], color='m', alpha=0.57, panel=0, ylabel='EMA'),
                mpf.make_addplot(chart_df['ema_period2'], color='r', alpha=0.57, panel=0, ylabel='EMA')
            ])
            
            # Bollinger Bands индикаторы (отображаем для всех стратегий)
            bb_config = self.backtester.strategies_config.get('BB', {})
            bb_window = bb_config.get('width_lookback_period', 15) if bb_config else 15
            bb_std_dev = bb_config.get('num_std_dev', 2.0) if bb_config else 2.0
            
            # Рассчитываем Bollinger Bands с начала данных для лучшей точности
            full_bb_sma, full_bb_upper, full_bb_lower = self.calculate_bollinger_bands(
                df, window=bb_window, num_std_dev=bb_std_dev, calculate_from_beginning=True)
            
            # Берем только нужный участок для отображения
            chart_df['bollinger_sma'] = full_bb_sma.iloc[start_index:end_index].values
            chart_df['bollinger_upper'] = full_bb_upper.iloc[start_index:end_index].values
            chart_df['bollinger_lower'] = full_bb_lower.iloc[start_index:end_index].values
            
            apds.extend([
                mpf.make_addplot(chart_df['bollinger_sma'], color='black', alpha=0.1, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bollinger_upper'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bollinger_lower'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс')
            ])
            
            # Volume индикаторы (отображаем для всех стратегий)
            volum_config = self.backtester.strategies_config.get('VOLUM', {})
            volume_window = volum_config.get('volume_average_window', 20) if volum_config else 20
            chart_df['avg_volume'] = chart_df['volume'].rolling(window=volume_window).mean()
            apds.append(
                mpf.make_addplot(chart_df['avg_volume'], color='blue', alpha=0.45, panel=1, ylabel='Средний Объем')
            )
            
            # Stochastic индикаторы (отображаем для всех стратегий)
            stoh_config = self.backtester.strategies_config.get('STOH', {})
            stoch_k_period = stoh_config.get('stoch_k', 14) if stoh_config else 14
            stoch_d_period = stoh_config.get('stoch_d', 3) if stoh_config else 3
            chart_df['stoch_k'], chart_df['stoch_d'] = self.calculate_stochastic(
                chart_df, k=stoch_k_period, d=stoch_d_period)
            apds.extend([
                mpf.make_addplot(chart_df['stoch_k'], color='blue', alpha=0.6, panel=2, ylabel='Стochastic'),
                mpf.make_addplot(chart_df['stoch_d'], color='purple', alpha=0.6, panel=2, ylabel='Стochastic'),
                # Линии уровня для стохастика
                mpf.make_addplot([0]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([100]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([20]*len(chart_df), color='green', panel=2, linestyle='--', linewidths=0.5),
                mpf.make_addplot([80]*len(chart_df), color='red', panel=2, linestyle='--', linewidths=0.5),
                # Зоны заполнения для стохастика
                mpf.make_addplot(
                    pd.Series([20] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                ),
                mpf.make_addplot(
                    pd.Series([80] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                )
            ])
            
            # Определяем цвет и тип маркера для сигнала
            marker_color = 'green' if direction == 'BUY' else 'red'
            marker_type = '^' if direction == 'BUY' else 'v'
            
            # Находим индекс сигнала на графике
            signal_chart_index = signal_index - start_index
            
            # Создаем график
            fig, axlist = mpf.plot(
                chart_df,
                type='candle',
                style='yahoo',
                volume=True,
                show_nontrading=True,
                returnfig=True,
                addplot=apds,
                warn_too_much_data=100,
                title=f'{strategy} {direction} Signal for {symbol} ({timeframe})\n{timestamp.strftime("%Y-%m-%d %H:%M")}',
                figscale=0.8,
                figsize=(12, 10)
            )
            
            # Добавляем вертикальную пунктирную линию в момент сигнала на все панели
            signal_time = chart_df.index[signal_chart_index]
            for ax in axlist:
                if hasattr(ax, 'axvline'):  # Проверяем, что это ось, на которой можно рисовать линии
                    ax.axvline(x=signal_time, color='blue', linestyle='--', linewidth=1, alpha=0.7)
            
            # Добавляем маркер сигнала
            axlist[0].scatter(
                chart_df.index[signal_chart_index], 
                chart_df['close'].iloc[signal_chart_index],
                color=marker_color, 
                marker=marker_type, 
                s=200, 
                zorder=5,
                label=f'{direction} Signal'
            )
            
            # Добавляем легенду
            axlist[0].legend()
            
            # Сохраняем график, если указан путь
            if save_path:
                # Создаем директорию если она не существует
                directory = os.path.dirname(save_path)
                if directory and not os.path.exists(directory):
                    os.makedirs(directory)
                
                plt.savefig(save_path, dpi=150, bbox_inches='tight')
                plt.close()
                # Уменьшаем избыточный вывод при сохранении графиков
                # print(f"График сохранен: {save_path}")  # Закомментировано для уменьшения вывода
                return True
            else:
                # В многопоточной среде сохраняем график в файл вместо показа
                temp_path = f"temp_signal_chart_{int(datetime.now().timestamp())}.png"
                plt.savefig(temp_path, dpi=150, bbox_inches='tight')
                plt.close()
                print(f"График сохранен как: {temp_path}")
                return True
                
        except Exception as e:
            print(f"Ошибка при генерации графика: {e}")
            if save_path:
                plt.close()
            return False

    def generate_all_order_charts(self, trades_data, count=None):
        """
        Генерация графиков для всех ордеров в результатах бэктеста
        
        Args:
            trades_data: Список сделок из результатов бэктеста
            count: Количество графиков для генерации (None - спрашивать у пользователя)
        """
        if not trades_data:
            print("⚠️ Нет данных о сделках для генерации графиков")
            return
        
        # Если количество не задано, спрашиваем у пользователя
        if count is None:
            print(f"\n📊 Всего доступно сделок: {len(trades_data)}")
            while True:
                try:
                    count_input = input("Сколько графиков сгенерировать? (0 - нет, Enter - все, или введите число): ").strip()
                    if count_input == "0":
                        print("Генерация графиков отменена пользователем")
                        return
                    elif count_input == "":
                        count = len(trades_data)
                        break
                    else:
                        count = int(count_input)
                        if 0 <= count <= len(trades_data):
                            break
                        else:
                            print(f"Пожалуйста, введите число от 0 до {len(trades_data)}")
                except ValueError:
                    print("Пожалуйста, введите корректное число")
        else:
            # Проверяем, что count в допустимых пределах
            count = max(0, min(count, len(trades_data)))
            print(f"\n📊 Всего доступно сделок: {len(trades_data)}")
            print(f"Будет сгенерировано графиков: {count}")
        
        if count == 0:
            print("Генерация графиков отменена пользователем")
            return
        
        # Ограничиваем количество сделок для генерации
        selected_trades = trades_data[:count] if count < len(trades_data) else trades_data
        
        # Создаем директорию для графиков ордеров
        orders_dir = "order_charts"
        if not os.path.exists(orders_dir):
            os.makedirs(orders_dir)
        
        print(f"\n📊 Генерация графиков ордеров для {len(selected_trades)} сделок...")
        
        # Для каждой сделки генерируем график
        for i, trade in enumerate(selected_trades):
            try:
                symbol = trade['symbol']
                timeframe = trade['timeframe']
                entry_time = trade['entry_time']
                exit_time = trade.get('exit_time')  # Может быть None для незакрытых ордеров
                entry_price = trade['entry_price']
                exit_price = trade.get('exit_price')  # Может быть None для незакрытых ордеров
                strategy = "Backtest"  # Можно уточнить, если есть информация о стратегии
                # Исправляем обработку направления - учитываем, что в backtester направление в нижнем регистре
                direction = trade.get('direction', 'buy').upper()  # Преобразуем в верхний регистр для совместимости
                
                # Загружаем данные (берем больше данных для лучшего контекста)
                # Вычисляем временные границы: от entry_time минус 1 день до entry_time плюс 2 дня
                start_time = entry_time - timedelta(days=1)
                end_time = entry_time + timedelta(days=2)
                df = self.backtester.fetch_historical_data(symbol, timeframe, start_time, end_time)
                if df is None or len(df) < 40:
                    print(f"   ⚠️ Недостаточно данных для {symbol} ({timeframe})")
                    continue
                
                # Проверяем, что время входа находится в данных
                if entry_time not in df.index:
                    print(f"   ⚠️ Время входа не найдено в данных для {symbol} ({timeframe})")
                    continue
                
                # Определяем время сигнала (можно использовать время входа как сигнал)
                signal_time = entry_time
                
                # Получаем стратегию и причину закрытия из данных сделки
                strategy = trade.get('strategy', 'Backtest')
                close_reason = trade.get('close_reason', 'Не указана')
                
                # Генерируем график
                filename = f"{orders_dir}/{symbol.replace('/', '_')}_{timeframe}_{entry_time.strftime('%Y%m%d_%H%M')}_order.png"
                success = self.generate_order_chart(
                    df, symbol, timeframe, strategy, direction, signal_time,
                    entry_time, exit_time, entry_price, exit_price, filename, close_reason)
                
                if success:
                    print(f"   ✅ График ордера сохранен: {filename}")
                else:
                    print(f"   ❌ Ошибка при генерации графика ордера для {symbol} ({timeframe})")
                    
            except Exception as e:
                print(f"   ❌ Ошибка при генерации графика ордера: {e}")
                continue

    def generate_order_chart(self, df, symbol, timeframe, strategy, direction, timestamp, 
                            order_entry_time, order_exit_time, order_entry_price, order_exit_price,
                            save_path=None, close_reason="Не указана"):
        """
        Генерация графика ордера с индикаторами
        
        Args:
            df: DataFrame с данными OHLCV
            symbol: Символ валютной пары
            timeframe: Таймфрейм
            strategy: Название стратегии
            direction: Направление сигнала (Buy/Sell)
            timestamp: Временная метка сигнала
            order_entry_time: Время открытия ордера
            order_exit_time: Время закрытия ордера (может быть None для незакрытых ордеров)
            order_entry_price: Цена открытия ордера
            order_exit_price: Цена закрытия ордера (может быть None для незакрытых ордеров)
            save_path: Путь для сохранения графика (опционально)
            close_reason: Причина закрытия ордера (опционально)
        """
        try:
            # Убедимся, что direction в верхнем регистре для совместимости
            direction = direction.upper()
            
            # Определяем индекс сигнала
            signal_index = df.index.get_loc(timestamp)
            
            # Определяем диапазон для отображения (20 свечей до сигнала и 50 после)
            candles_before = min(20, signal_index)  # Максимум 20 свечей до сигнала
            candles_after = min(50, len(df) - signal_index - 1)  # Максимум 50 свечей после сигнала
            
            start_index = max(0, signal_index - candles_before)
            end_index = min(len(df), signal_index + candles_after + 1)  # +1 для включения сигнала
            
            # Убедимся, что у нас есть данные
            if start_index >= end_index:
                start_index = max(0, end_index - 1)
            
            chart_df = df.iloc[start_index:end_index].copy()
            
            # Рассчитываем ВСЕ индикаторы независимо от стратегии
            apds = []
            
            # EMA индикаторы (отображаем для всех стратегий)
            ema_config = self.backtester.strategies_config.get('EMA', {})
            ema_period1 = ema_config.get('ema_period1', 3) if ema_config else 3
            ema_period2 = ema_config.get('ema_period2', 20) if ema_config else 20
            chart_df['ema_period1'] = self.calculate_ema(chart_df, ema_period1)
            chart_df['ema_period2'] = self.calculate_ema(chart_df, ema_period2)
            apds.extend([
                mpf.make_addplot(chart_df['ema_period1'], color='m', alpha=0.57, panel=0, ylabel='EMA'),
                mpf.make_addplot(chart_df['ema_period2'], color='r', alpha=0.57, panel=0, ylabel='EMA')
            ])
            
            # Bollinger Bands индикаторы (отображаем для всех стратегий)
            bb_config = self.backtester.strategies_config.get('BB', {})
            bb_window = bb_config.get('width_lookback_period', 15) if bb_config else 15
            bb_std_dev = bb_config.get('num_std_dev', 2.0) if bb_config else 2.0
            
            # Рассчитываем Bollinger Bands с начала данных для лучшей точности
            full_bb_sma, full_bb_upper, full_bb_lower = self.calculate_bollinger_bands(
                df, window=bb_window, num_std_dev=bb_std_dev, calculate_from_beginning=True)
            
            # Берем только нужный участок для отображения
            chart_df['bollinger_sma'] = full_bb_sma.iloc[start_index:end_index].values
            chart_df['bollinger_upper'] = full_bb_upper.iloc[start_index:end_index].values
            chart_df['bollinger_lower'] = full_bb_lower.iloc[start_index:end_index].values
            
            apds.extend([
                mpf.make_addplot(chart_df['bollinger_sma'], color='black', alpha=0.1, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bollinger_upper'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bollinger_lower'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс')
            ])
            
            # Volume индикаторы (отображаем для всех стратегий)
            volum_config = self.backtester.strategies_config.get('VOLUM', {})
            volume_window = volum_config.get('volume_average_window', 20) if volum_config else 20
            chart_df['avg_volume'] = chart_df['volume'].rolling(window=volume_window).mean()
            apds.append(
                mpf.make_addplot(chart_df['avg_volume'], color='blue', alpha=0.45, panel=1, ylabel='Средний Объем')
            )
            
            # Stochastic индикаторы (отображаем для всех стратегий)
            stoh_config = self.backtester.strategies_config.get('STOH', {})
            stoch_k_period = stoh_config.get('stoch_k', 14) if stoh_config else 14
            stoch_d_period = stoh_config.get('stoch_d', 3) if stoh_config else 3
            chart_df['stoch_k'], chart_df['stoch_d'] = self.calculate_stochastic(
                chart_df, k=stoch_k_period, d=stoch_d_period)
            apds.extend([
                mpf.make_addplot(chart_df['stoch_k'], color='blue', alpha=0.6, panel=2, ylabel='Стochastic'),
                mpf.make_addplot(chart_df['stoch_d'], color='purple', alpha=0.6, panel=2, ylabel='Стochastic'),
                # Линии уровня для стохастика
                mpf.make_addplot([0]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([100]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([20]*len(chart_df), color='green', panel=2, linestyle='--', linewidths=0.5),
                mpf.make_addplot([80]*len(chart_df), color='red', panel=2, linestyle='--', linewidths=0.5),
                # Зоны заполнения для стохастика
                mpf.make_addplot(
                    pd.Series([20] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                ),
                mpf.make_addplot(
                    pd.Series([80] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                )
            ])
            
            # Определяем цвета и типы маркеров для открытия/закрытия ордера
            # Для покупки (BUY): зеленый треугольник вверх (^) на открытии, красный треугольник вниз (v) на закрытии
            # Для продажи (SELL): красный треугольник вниз (v) на открытии, зеленый треугольник вверх (^) на закрытии
            entry_marker_color = 'green' if direction == 'BUY' else 'red'
            exit_marker_color = 'red' if direction == 'BUY' else 'green'
            entry_marker_type = '^' if direction == 'BUY' else 'v'
            exit_marker_type = 'v' if direction == 'BUY' else '^'
            
            # Находим индексы на графике
            signal_chart_index = signal_index - start_index
            
            # Рассчитываем PnL и процент изменения цены (если доступны данные о выходе)
            if order_exit_price is not None and order_entry_price is not None:
                if direction == 'BUY':
                    pnl = order_exit_price - order_entry_price  # Исправлено: было order_exit_price - order_exit_price
                    pnl_percentage = ((order_exit_price - order_entry_price) / order_entry_price) * 100
                else:  # SELL
                    pnl = order_entry_price - order_exit_price
                    pnl_percentage = ((order_entry_price - order_exit_price) / order_entry_price) * 100
            else:
                # Для незакрытых ордеров показываем текущую цену
                current_price = chart_df['close'].iloc[-1]
                if direction == 'BUY':
                    pnl = current_price - order_entry_price
                    pnl_percentage = ((current_price - order_entry_price) / order_entry_price) * 100
                else:  # SELL
                    pnl = order_entry_price - current_price
                    pnl_percentage = ((order_entry_price - current_price) / order_entry_price) * 100
            
            # Подготовка подробной информации для отображения слева
            exit_time_str = order_exit_time.strftime("%Y-%m-%d %H:%M") if order_exit_time else "Не закрыт"
            exit_price_str = f"{order_exit_price:.4f}" if order_exit_price else "Н/Д"
            
            # Определяем тип ордера на русском языке (исправляем логику)
            # В фьючерсной торговле: Buy = покупка (лонг), Sell = продажа (шорт)
            order_type_russian = "покупка (лонг)" if direction == 'BUY' else "продажа (шорт)"
            
            # Получаем параметры трейдинга из конфигурации бэктестера
            # Используем реальные параметры из конфигурации, а не значения по умолчанию
            replay_config = self.backtester.config.get('replay', {})
            stop_loss_percentage = replay_config.get('stop_loss_percentage', 1.0)
            trigger_profit_percentage = replay_config.get('trigger_profit_percentage', 0.5)
            trailing_percentage = replay_config.get('trailing_percentage', 0.5)
            profit_lock_percentage = replay_config.get('profit_lock_percentage', 0.25)
            
            # Рассчитываем размер позиции и маржу как в бэктестере
            initial_balance = self.backtester.config['backtest']['initial_balance']
            position_size_percentage = self.backtester.config['trading']['position_size_percentage']
            position_size = initial_balance * (position_size_percentage / 100)
            leverage = self.backtester.config['trading'].get('leverage', 1.0)
            margin = position_size / leverage  # Маржа без плеча
            
            # Количество монет в позиции
            amount = position_size / order_entry_price
            
            # Добавляем отладочный вывод
            print(f"DEBUG: initial_balance={initial_balance}, position_size={position_size}, margin={margin}, amount={amount}")
            print(f"DEBUG: stop_loss_percentage={stop_loss_percentage}, trigger_profit_percentage={trigger_profit_percentage}")
            
            # Рассчитываем уровни SL, TP, TL, PL на основе PnL (как в оригинальном боте)
            # В оригинальном боте уровни рассчитываются как проценты от МАРЖИ
            if direction == 'BUY':
                # Для покупки (лонг)
                # SL: убыток в процентах от маржи
                sl_pnl = -(margin * stop_loss_percentage / 100)
                sl_price = order_entry_price + (sl_pnl / amount)
                
                # TP: прибыль в процентах от маржи для активации трейлинга
                tp_pnl = margin * trigger_profit_percentage / 100
                tp_price = order_entry_price + (tp_pnl / amount)
                
                # TL: трейлинг-стоп (50% от максимальной прибыли)
                # В бэктестере: stop_pnl = highest_pnl * (1 - trailing_percentage / 100)
                # Для отображения используем приблизительное значение
                tl_pnl = tp_pnl * (1 - trailing_percentage / 100)
                tl_price = order_entry_price + (tl_pnl / amount)
                
                # PL: фиксация прибыли (профит лок)
                pl_pnl = margin * profit_lock_percentage / 100
                pl_price = order_entry_price + (pl_pnl / amount)
            else:
                # Для продажи (шорт)
                # SL: убыток в процентах от маржи (цена должна быть ВЫШЕ цены входа)
                sl_pnl = -(margin * stop_loss_percentage / 100)
                sl_price = order_entry_price - (sl_pnl / amount)  # Вычитаем отрицательное значение = прибавляем
                
                # TP: прибыль в процентах от маржи для активации трейлинга (цена должна быть НИЖЕ цены входа)
                tp_pnl = margin * trigger_profit_percentage / 100
                tp_price = order_entry_price - (tp_pnl / amount)
                
                # TL: трейлинг-стоп (цена должна быть НИЖЕ цены входа)
                tl_pnl = tp_pnl * (1 - trailing_percentage / 100)
                tl_price = order_entry_price - (tl_pnl / amount)
                
                # PL: фиксация прибыли (цена должна быть НИЖЕ цены входа)
                pl_pnl = margin * profit_lock_percentage / 100
                pl_price = order_entry_price - (pl_pnl / amount)
            
            # Добавляем отладочный вывод для уровней
            print(f"DEBUG: sl_price={sl_price}, tp_price={tp_price}, tl_price={tl_price}, pl_price={pl_price}")
            
            # Формируем полный текст информации
            info_lines = [
                f"СИМВОЛ: {symbol}",
                f"ТАЙМФРЕЙМ: {timeframe}",
                f"СТРАТЕГИЯ: {strategy}",
                f"",
                f"ТИП ОРДЕРА: {order_type_russian}",
                f"ВРЕМЯ СИГНАЛА: {timestamp.strftime('%Y-%m-%d %H:%M')}",
                f"ВХОД: {order_entry_time.strftime('%Y-%m-%d %H:%M')}",
                f"ЦЕНА ВХОДА: {order_entry_price:.4f}",
                f"ВЫХОД: {exit_time_str}",
                f"ЦЕНА ВЫХОДА: {exit_price_str}",
                f"",
                f"BRUTTO PnL: {pnl:.4f}",
                f"ПРОЦЕНТ: {pnl_percentage:+.2f}%",
                f"",
                f"ПРИЧИНА ЗАКРЫТИЯ: {close_reason}",
                f"",
                f"=== УРОВНИ ===",
                f"стоп лосс (SL) = {stop_loss_percentage:.1f}% ЦЕНА {sl_price:.4f} USD",
                f"тейк профит (TP) = {trigger_profit_percentage:.1f}% ЦЕНА {tp_price:.4f} USD",
                f"тейлинг стоп (TL) = {trailing_percentage:.1f}% ЦЕНА {tl_price:.4f} USD",
                f"профит лок (PL) = {profit_lock_percentage:.1f}% ЦЕНА {pl_price:.4f} USD"
            ]
            
            info_text = "\n".join(info_lines)
            
            # Создаем отдельные графики и объединяем их
            from io import BytesIO
            import PIL.Image as Image
            
            # === Создаем информационную панель ===
            info_buffer = BytesIO()
            info_fig, info_ax = plt.subplots(figsize=(4, 10))
            info_ax.text(0.05, 0.95, info_text, transform=info_ax.transAxes, fontsize=11,
                        verticalalignment='top', fontfamily='monospace',
                        bbox=dict(boxstyle='round,pad=0.5', facecolor='lightcyan', alpha=0.9))
            info_ax.set_xlim(0, 1)
            info_ax.set_ylim(0, 1)
            info_ax.axis('off')
            plt.savefig(info_buffer, format='png', dpi=150, bbox_inches='tight')
            plt.close()
            
            # === Создаем основной график ===
            chart_buffer = BytesIO()
            
            # Создаем график с помощью mplfinance
            chart_fig, axlist = mpf.plot(
                chart_df,
                type='candle',
                style='yahoo',
                volume=True,
                show_nontrading=True,
                returnfig=True,
                addplot=apds,
                warn_too_much_data=100,
                figscale=0.8,
                figsize=(10, 8)
            )
            
            # Добавляем вертикальную пунктирную линию в момент сигнала на все панели
            if 0 <= signal_chart_index < len(chart_df):
                signal_time = chart_df.index[signal_chart_index]
                for ax in axlist:
                    if hasattr(ax, 'axvline'):
                        ax.axvline(x=signal_time, color='blue', linestyle='--', linewidth=1, alpha=0.7)
            
            # Добавляем маркер сигнала
            if 0 <= signal_chart_index < len(chart_df):
                axlist[0].scatter(
                    chart_df.index[signal_chart_index], 
                    chart_df['close'].iloc[signal_chart_index],
                    color='blue', 
                    marker='o', 
                    s=150, 
                    zorder=5,
                    label='Signal'
                )
            
            # Добавляем горизонтальные пунктирные линии для уровней SL, TP, TL, PL
            # Используем тонкие линии с разными цветами для лучшей визуализации
            # Проверяем, находятся ли уровни в пределах отображаемого диапазона цен
            min_chart_price = chart_df['low'].min()
            max_chart_price = chart_df['high'].max()
            
            # Добавляем линии только если они находятся в пределах графика или близко к нему
            price_range = max_chart_price - min_chart_price
            extended_min = min_chart_price - price_range * 0.1
            extended_max = max_chart_price + price_range * 0.1
            
            def add_line_if_in_range(level_price, color, label):
                if extended_min <= level_price <= extended_max:
                    axlist[0].axhline(y=level_price, color=color, linestyle='--', linewidth=0.8, alpha=0.8, label=label)
                    return True
                return False
            
            # Добавляем линии и отслеживаем, какие были добавлены
            sl_added = add_line_if_in_range(sl_price, 'red', 'Stop Loss (SL)')
            tp_added = add_line_if_in_range(tp_price, 'green', 'Take Profit (TP)')
            tl_added = add_line_if_in_range(tl_price, 'orange', 'Trailing Stop (TL)')
            pl_added = add_line_if_in_range(pl_price, 'purple', 'Profit Lock (PL)')
            
            # Добавляем подписи к линиям справа над ними
            # Получаем максимальную цену на графике для правильного позиционирования подписей
            max_price = chart_df['high'].max()
            min_price = chart_df['low'].min()
            price_range = max_price - min_price
            
            # Позиционируем подписи немного выше линий
            label_offset = price_range * 0.01  # 1% от диапазона цен
            
            # Добавляем подписи только для линий, которые были добавлены
            def add_label_if_added(added, level_price, text, color):
                if added and extended_min <= level_price <= extended_max:
                    axlist[0].text(chart_df.index[-1], level_price + label_offset, text, 
                                  color=color, fontsize=8, ha='right', va='bottom')
            
            add_label_if_added(sl_added, sl_price, f'SL ({stop_loss_percentage:.1f}%)', 'red')
            add_label_if_added(tp_added, tp_price, f'TP ({trigger_profit_percentage:.1f}%)', 'green')
            add_label_if_added(tl_added, tl_price, f'TL ({trailing_percentage:.1f}%)', 'orange')
            add_label_if_added(pl_added, pl_price, f'PL ({profit_lock_percentage:.1f}%)', 'purple')
            
            # Добавляем маркер открытия ордера
            try:
                # Находим индекс для открытия ордера
                entry_chart_index = chart_df.index.get_loc(order_entry_time)
                
                # Добавляем маркер открытия
                axlist[0].scatter(
                    order_entry_time, 
                    order_entry_price,
                    color=entry_marker_color, 
                    marker=entry_marker_type, 
                    s=200, 
                    zorder=5,
                    label='Order Entry'
                )
                
                # Если есть данные о закрытии, добавляем маркер закрытия и соединяющую линию
                if order_exit_time is not None and order_exit_price is not None:
                    try:
                        exit_chart_index = chart_df.index.get_loc(order_exit_time)
                        
                        # Добавляем маркер закрытия
                        axlist[0].scatter(
                            order_exit_time, 
                            order_exit_price,
                            color=exit_marker_color, 
                            marker=exit_marker_type, 
                            s=200, 
                            zorder=5,
                            label='Order Exit'
                        )
                        
                        # Соединяем точки открытия и закрытия тонкой пунктирной линией (синий цвет вместо оранжевого)
                        axlist[0].plot(
                            [order_entry_time, order_exit_time],
                            [order_entry_price, order_exit_price],
                            color='blue',  # Изменен цвет с оранжевого на синий
                            linestyle='--',
                            linewidth=1,
                            alpha=0.8
                        )
                    except KeyError:
                        # Если время закрытия не найдено в данных графика
                        print("Предупреждение: время закрытия ордера не найдено в данных графика")
                        # Показываем линию от открытия до конца графика
                        last_time = chart_df.index[-1]
                        last_price = chart_df['close'].iloc[-1]
                        axlist[0].plot(
                            [order_entry_time, last_time],
                            [order_entry_price, last_price],
                            color='blue',
                            linestyle='--',
                            linewidth=1,
                            alpha=0.8
                        )
                else:
                    # Для незакрытых ордеров показываем линию от открытия до конца графика
                    last_time = chart_df.index[-1]
                    last_price = chart_df['close'].iloc[-1]
                    axlist[0].plot(
                        [order_entry_time, last_time],
                        [order_entry_price, last_price],
                        color='blue',
                        linestyle='--',
                        linewidth=1,
                        alpha=0.8
                    )
                    # Добавляем маркер текущей цены
                    axlist[0].scatter(
                        last_time, 
                        last_price,
                        color='orange', 
                        marker='o', 
                        s=150, 
                        zorder=5,
                        label='Current Price'
                    )
                
            except KeyError:
                # Если время открытия не найдено в данных графика
                print("Предупреждение: время открытия ордера не найдено в данных графика")
            
            # Добавляем легенду
            axlist[0].legend()
            
            plt.savefig(chart_buffer, format='png', dpi=150, bbox_inches='tight')
            plt.close(chart_fig)
            
            # === Объединяем два изображения ===
            # Загружаем изображения из буферов
            info_buffer.seek(0)
            chart_buffer.seek(0)
            
            img1 = Image.open(info_buffer)
            img2 = Image.open(chart_buffer)
            
            # Создаем новое изображение для объединения
            combined_width = img1.width + img2.width
            combined_height = max(img1.height, img2.height)
            
            combined_img = Image.new('RGB', (combined_width, combined_height), 'white')
            combined_img.paste(img1, (0, 0))
            combined_img.paste(img2, (img1.width, 0))
            
            # Сохраняем объединенное изображение
            if save_path:
                # Создаем директорию если она не существует
                directory = os.path.dirname(save_path)
                if directory and not os.path.exists(directory):
                    os.makedirs(directory)
                
                combined_img.save(save_path, 'PNG', dpi=(150, 150))
                return True
            else:
                # Показываем объединенное изображение
                combined_img.show()
                return True
                
        except Exception as e:
            print(f"Ошибка при генерации графика ордера: {e}")
            import traceback
            traceback.print_exc()
            if save_path:
                plt.close()
            return False

    def generate_comparison_chart(self, df, symbol, timeframe, strategy, direction, timestamp, 
                                 before_params, after_params, save_path=None):
        """
        Генерация сравнительного графика до и после оптимизации
        Создаем два отдельных графика и сохраняем их во временные буферы
        
        Args:
            df: DataFrame с данными OHLCV
            symbol: Символ валютной пары
            timeframe: Таймфрейм
            strategy: Название стратегии
            direction: Направление сигнала (Buy/Sell)
            timestamp: Временная метка сигнала
            before_params: Параметры до оптимизации
            after_params: Параметры после оптимизации
            save_path: Путь для сохранения графика (опционально)
        """
        try:
            # Убедимся, что direction в верхнем регистре для совместимости
            direction = direction.upper()
            
            # Определяем индекс сигнала
            signal_index = df.index.get_loc(timestamp)
            
            # Определяем диапазон для отображения (20 свечей до сигнала и 50 после)
            candles_before = min(20, signal_index)  # Максимум 20 свечей до сигнала
            candles_after = min(50, len(df) - signal_index - 1)  # Максимум 50 свечей после сигнала
            
            start_index = max(0, signal_index - candles_before)
            end_index = min(len(df), signal_index + candles_after + 1)  # +1 для включения сигнала
            
            # Убедимся, что у нас есть данные
            if start_index >= end_index:
                start_index = max(0, end_index - 1)
            
            chart_df = df.iloc[start_index:end_index].copy()
            
            # Создаем два отдельных графика и сохраняем их во временные буферы
            from io import BytesIO
            import PIL.Image as Image
            
            # === График "ДО оптимизации" ===
            before_buffer = BytesIO()
            
            # Рассчитываем индикаторы для "до оптимизации"
            before_apds = []
            
            # EMA индикаторы (всегда отображаем)
            ema_period1_before = before_params.get('ema_period1', 3)
            ema_period2_before = before_params.get('ema_period2', 20)
            chart_df['ema1_before'] = self.calculate_ema(chart_df, ema_period1_before)
            chart_df['ema2_before'] = self.calculate_ema(chart_df, ema_period2_before)
            before_apds.extend([
                mpf.make_addplot(chart_df['ema1_before'], color='m', alpha=0.57, panel=0, ylabel='EMA'),
                mpf.make_addplot(chart_df['ema2_before'], color='r', alpha=0.57, panel=0, ylabel='EMA')
            ])
            
            # Bollinger Bands индикаторы (всегда отображаем)
            bb_window_before = before_params.get('width_lookback_period', 15)
            bb_std_dev_before = before_params.get('num_std_dev', 2.0)
            
            # Рассчитываем Bollinger Bands с начала данных для лучшей точности
            full_bb_sma_before, full_bb_upper_before, full_bb_lower_before = self.calculate_bollinger_bands(
                df, window=bb_window_before, num_std_dev=bb_std_dev_before, calculate_from_beginning=True)
            
            # Берем только нужный участок для отображения
            chart_df['bb_sma_before'] = full_bb_sma_before.iloc[start_index:end_index].values
            chart_df['bb_upper_before'] = full_bb_upper_before.iloc[start_index:end_index].values
            chart_df['bb_lower_before'] = full_bb_lower_before.iloc[start_index:end_index].values
            
            before_apds.extend([
                mpf.make_addplot(chart_df['bb_sma_before'], color='black', alpha=0.1, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bb_upper_before'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bb_lower_before'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс')
            ])
            
            # Volume индикаторы (всегда отображаем)
            volume_window_before = before_params.get('volume_average_window', 20)
            chart_df['avg_volume_before'] = chart_df['volume'].rolling(window=volume_window_before).mean()
            before_apds.append(
                mpf.make_addplot(chart_df['avg_volume_before'], color='blue', alpha=0.45, panel=1, ylabel='Средний Объем')
            )
            
            # Stochastic индикаторы (всегда отображаем)
            stoch_k_before = before_params.get('stoch_k', 14)
            stoch_d_before = before_params.get('stoch_d', 3)
            stoch_k_vals_before, stoch_d_vals_before = self.calculate_stochastic(
                chart_df, stoch_k_before, stoch_d_before)
            chart_df['stoch_k_before'] = stoch_k_vals_before
            chart_df['stoch_d_before'] = stoch_d_vals_before
            before_apds.extend([
                mpf.make_addplot(chart_df['stoch_k_before'], color='blue', alpha=0.6, panel=2, ylabel='Стochastic'),
                mpf.make_addplot(chart_df['stoch_d_before'], color='purple', alpha=0.6, panel=2, ylabel='Стochastic'),
                # Линии уровня для стохастика
                mpf.make_addplot([0]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([100]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([20]*len(chart_df), color='green', panel=2, linestyle='--', linewidths=0.5),
                mpf.make_addplot([80]*len(chart_df), color='red', panel=2, linestyle='--', linewidths=0.5),
                # Зоны заполнения для стохастика
                mpf.make_addplot(
                    pd.Series([20] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                ),
                mpf.make_addplot(
                    pd.Series([80] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                )
            ])
            
            # Добавляем маркер сигнала
            marker_color = 'green' if direction == 'BUY' else 'red'
            marker_type = '^' if direction == 'BUY' else 'v'
            signal_chart_index = signal_index - start_index
            signal_time = chart_df.index[signal_chart_index]
            
            # Создаем график "до оптимизации"
            fig1, axlist1 = mpf.plot(
                chart_df, type='candle', style='yahoo', volume=True,
                show_nontrading=True, returnfig=True, addplot=before_apds,
                warn_too_much_data=100,
                title=f'BEFORE OPTIMIZATION\n{strategy} {direction} Signal for {symbol} ({timeframe})\n{timestamp.strftime("%Y-%m-%d %H:%M")}',
                figscale=0.8,
                figsize=(10, 8)
            )
            
            # Добавляем вертикальную пунктирную линию в момент сигнала на все панели графика "до оптимизации"
            for ax in axlist1:
                if hasattr(ax, 'axvline'):  # Проверяем, что это ось, на которой можно рисовать линии
                    ax.axvline(x=signal_time, color='blue', linestyle='--', linewidth=1, alpha=0.7)
            
            # Добавляем маркер сигнала на график "до оптимизации"
            axlist1[0].scatter(
                chart_df.index[signal_chart_index], 
                chart_df['close'].iloc[signal_chart_index],
                color=marker_color, 
                marker=marker_type, 
                s=200, 
                zorder=5
            )
            
            plt.savefig(before_buffer, format='png', dpi=150, bbox_inches='tight')
            plt.close()
            
            # === График "ПОСЛЕ оптимизации" ===
            after_buffer = BytesIO()
            
            # Рассчитываем индикаторы для "после оптимизации"
            after_apds = []
            
            # EMA индикаторы (всегда отображаем)
            ema_period1_after = after_params.get('ema_period1', 3)
            ema_period2_after = after_params.get('ema_period2', 20)
            chart_df['ema1_after'] = self.calculate_ema(chart_df, ema_period1_after)
            chart_df['ema2_after'] = self.calculate_ema(chart_df, ema_period2_after)
            after_apds.extend([
                mpf.make_addplot(chart_df['ema1_after'], color='m', alpha=0.57, panel=0, ylabel='EMA'),
                mpf.make_addplot(chart_df['ema2_after'], color='r', alpha=0.57, panel=0, ylabel='EMA')
            ])
            
            # Bollinger Bands индикаторы (всегда отображаем)
            bb_window_after = after_params.get('width_lookback_period', 15)
            bb_std_dev_after = after_params.get('num_std_dev', 2.0)
            
            # Рассчитываем Bollinger Bands с начала данных для лучшей точности
            full_bb_sma_after, full_bb_upper_after, full_bb_lower_after = self.calculate_bollinger_bands(
                df, window=bb_window_after, num_std_dev=bb_std_dev_after, calculate_from_beginning=True)
            
            # Берем только нужный участок для отображения
            chart_df['bb_sma_after'] = full_bb_sma_after.iloc[start_index:end_index].values
            chart_df['bb_upper_after'] = full_bb_upper_after.iloc[start_index:end_index].values
            chart_df['bb_lower_after'] = full_bb_lower_after.iloc[start_index:end_index].values
            
            after_apds.extend([
                mpf.make_addplot(chart_df['bb_sma_after'], color='black', alpha=0.1, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bb_upper_after'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс'),
                mpf.make_addplot(chart_df['bb_lower_after'], color='black', alpha=0.5, panel=0, ylabel='Боллинджер Бандс')
            ])
            
            # Volume индикаторы (всегда отображаем)
            volume_window_after = after_params.get('volume_average_window', 20)
            chart_df['avg_volume_after'] = chart_df['volume'].rolling(window=volume_window_after).mean()
            after_apds.append(
                mpf.make_addplot(chart_df['avg_volume_after'], color='blue', alpha=0.45, panel=1, ylabel='Средний Объем')
            )
            
            # Stochastic индикаторы (всегда отображаем)
            stoch_k_after = after_params.get('stoch_k', 14)
            stoch_d_after = after_params.get('stoch_d', 3)
            stoch_k_vals_after, stoch_d_vals_after = self.calculate_stochastic(
                chart_df, stoch_k_after, stoch_d_after)
            chart_df['stoch_k_after'] = stoch_k_vals_after
            chart_df['stoch_d_after'] = stoch_d_vals_after
            after_apds.extend([
                mpf.make_addplot(chart_df['stoch_k_after'], color='blue', alpha=0.6, panel=2, ylabel='Стochastic'),
                mpf.make_addplot(chart_df['stoch_d_after'], color='purple', alpha=0.6, panel=2, ylabel='Стochastic'),
                # Линии уровня для стохастика
                mpf.make_addplot([0]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([100]*len(chart_df), color='black', panel=2, linestyle='--', linewidths=1),
                mpf.make_addplot([20]*len(chart_df), color='green', panel=2, linestyle='--', linewidths=0.5),
                mpf.make_addplot([80]*len(chart_df), color='red', panel=2, linestyle='--', linewidths=0.5),
                # Зоны заполнения для стохастика
                mpf.make_addplot(
                    pd.Series([20] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                ),
                mpf.make_addplot(
                    pd.Series([80] * len(chart_df), index=chart_df.index), 
                    color='blue', alpha=0.3, panel=2, 
                    fill_between=dict(y1=20, y2=80, alpha=0.3)
                )
            ])
            
            # Создаем график "после оптимизации"
            fig2, axlist2 = mpf.plot(
                chart_df, type='candle', style='yahoo', volume=True,
                show_nontrading=True, returnfig=True, addplot=after_apds,
                warn_too_much_data=100,
                title=f'AFTER OPTIMIZATION\n{strategy} {direction} Signal for {symbol} ({timeframe})\n{timestamp.strftime("%Y-%m-%d %H:%M")}',
                figscale=0.8,
                figsize=(10, 8)
            )
            
            # Добавляем вертикальную пунктирную линию в момент сигнала на все панели графика "после оптимизации"
            for ax in axlist2:
                if hasattr(ax, 'axvline'):  # Проверяем, что это ось, на которой можно рисовать линии
                    ax.axvline(x=signal_time, color='blue', linestyle='--', linewidth=1, alpha=0.7)
            
            # Добавляем маркер сигнала на график "после оптимизации"
            axlist2[0].scatter(
                chart_df.index[signal_chart_index], 
                chart_df['close'].iloc[signal_chart_index],
                color=marker_color, 
                marker=marker_type, 
                s=200, 
                zorder=5
            )
            
            plt.savefig(after_buffer, format='png', dpi=150, bbox_inches='tight')
            plt.close()
            
            # === Объединяем два графика в один ===
            # Загружаем изображения из буферов
            before_buffer.seek(0)
            after_buffer.seek(0)
            
            img1 = Image.open(before_buffer)
            img2 = Image.open(after_buffer)
            
            # Создаем новое изображение для объединения
            combined_width = max(img1.width, img2.width)
            combined_height = img1.height + img2.height + 20  # Добавляем немного места между графиками
            
            combined_img = Image.new('RGB', (combined_width, combined_height), 'white')
            combined_img.paste(img1, (0, 0))
            combined_img.paste(img2, (0, img1.height + 20))
            
            # Сохраняем объединенное изображение
            if save_path:
                # Создаем директорию если она не существует
                directory = os.path.dirname(save_path)
                if directory and not os.path.exists(directory):
                    os.makedirs(directory)
                
                combined_img.save(save_path, 'PNG', dpi=(150, 150))
                # print(f"Сравнительный график сохранен: {save_path}")  # Закомментировано для уменьшения вывода
                return True
            else:
                # В многопоточной среде сохраняем график в файл вместо показа
                temp_path = f"temp_comparison_chart_{int(datetime.now().timestamp())}.png"
                combined_img.save(temp_path, 'PNG', dpi=(150, 150))
                print(f"Сравнительный график сохранен как: {temp_path}")
                return True
                
        except Exception as e:
            print(f"Ошибка при генерации сравнительного графика: {e}")
            return False

    def ask_generate_charts(self, optimization_mode=False, optimization_results=None, best_params=None):
        """
        Спрашиваем, хочет ли пользователь сгенерировать графики сигналов
        """
        # Спрашиваем, хочет ли пользователь сгенерировать графики сигналов
        print("\n📊 Хотите сгенерировать графики сигналов? (1 - Да, 2 - Нет)")
        while True:
            try:
                response = int(input("Введите 1 или 2: ").strip())
                if response in [1, 2]:
                    break
                else:
                    print("Пожалуйста, введите 1 или 2")
            except ValueError:
                print("Пожалуйста, введите число 1 или 2")
        
        if response == 1:
            try:
                if optimization_mode and optimization_results and best_params:
                    # Генерация сравнительных графиков после оптимизации
                    self.generate_optimization_comparison_charts(optimization_results, best_params)
                else:
                    # Генерация обычных графиков сигналов с возможностью выбора количества
                    self.generate_selected_signal_charts()
            except Exception as e:
                print(f"❌ Ошибка при генерации графиков: {e}")

    def generate_selected_signal_charts(self):
        """Генерация графиков для выбранных сигналов с запросом количества для каждого таймфрейма"""
        if not hasattr(self.backtester, 'signals') or not self.backtester.signals:
            print("⚠️ Нет сигналов для генерации графиков")
            return
        
        # Создаем директорию для графиков
        charts_dir = "signal_charts"
        if not os.path.exists(charts_dir):
            os.makedirs(charts_dir)
        
        # Группируем сигналы по символам и таймфреймам
        signal_groups = defaultdict(list)
        for signal in self.backtester.signals:
            key = (signal['symbol'], signal['timeframe'])
            signal_groups[key].append(signal)
        
        print(f"\n📊 Генерация графиков для {len(signal_groups)} групп сигналов...")
        
        # Для каждой группы спрашиваем количество графиков для генерации
        for (symbol, timeframe), signals in signal_groups.items():
            print(f"\n   📈 {symbol} ({timeframe}): доступно {len(signals)} сигналов")
            
            # Спрашиваем количество графиков для генерации
            while True:
                try:
                    count_input = input(f"   Сколько графиков сгенерировать? (0-{len(signals)}, Enter=все): ").strip()
                    if count_input == "":
                        count = len(signals)
                        break
                    count = int(count_input)
                    if 0 <= count <= len(signals):
                        break
                    else:
                        print(f"   Пожалуйста, введите число от 0 до {len(signals)}")
                except ValueError:
                    print("   Пожалуйста, введите корректное число")
            
            if count == 0:
                print(f"   ⏭️ Пропущена генерация графиков для {symbol} ({timeframe})")
                continue
                
            # Ограничиваем количество сигналов для генерации
            selected_signals = signals[:count] if count < len(signals) else signals
            print(f"   🎯 Будет сгенерировано {len(selected_signals)} графиков для {symbol} ({timeframe})")
            
            # Загружаем данные (берем больше данных для лучшего контекста)
            # Вычисляем временные границы: от самого раннего сигнала минус 2 дня до самого позднего сигнала плюс 2 дня
            earliest_signal = min([s['timestamp'] for s in signals])
            latest_signal = max([s['timestamp'] for s in signals])
            start_time = earliest_signal - timedelta(days=2)
            end_time = latest_signal + timedelta(days=2)
            df = self.backtester.fetch_historical_data(symbol, timeframe, start_time, end_time)
            if df is None or len(df) < 50:  # 30 до сигнала + 20 после
                print(f"   ⚠️ Недостаточно данных для {symbol} ({timeframe})")
                continue
            
            # Генерируем графики для каждого сигнала
            for i, signal in enumerate(selected_signals):
                try:
                    strategy = signal['strategy']
                    direction = signal['direction']
                    timestamp = signal['timestamp']
                    
                    # Проверяем, что сигнал находится в данных
                    if timestamp not in df.index:
                        print(f"   ⚠️ Сигнал {timestamp} не найден в данных")
                        continue
                    
                    # Генерируем график
                    filename = f"{charts_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy}_{direction}_{timestamp.strftime('%Y%m%d_%H%M')}.png"
                    success = self.generate_signal_chart(df, symbol, timeframe, strategy, direction, timestamp, filename)
                    
                    if success:
                        print(f"   ✅ График сохранен: {filename}")
                    else:
                        print(f"   ❌ Ошибка при генерации графика для {symbol} ({timeframe})")
                        
                except Exception as e:
                    print(f"   ❌ Ошибка при генерации графика: {e}")
                    continue

    def generate_all_signal_charts(self):
        """Генерация графиков для всех сигналов"""
        if not hasattr(self.backtester, 'signals') or not self.backtester.signals:
            print("⚠️ Нет сигналов для генерации графиков")
            return
        
        # Создаем директорию для графиков
        charts_dir = "signal_charts"
        if not os.path.exists(charts_dir):
            os.makedirs(charts_dir)
        
        # Группируем сигналы по символам и таймфреймам
        signal_groups = defaultdict(list)
        for signal in self.backtester.signals:
            key = (signal['symbol'], signal['timeframe'])
            signal_groups[key].append(signal)
        
        print(f"\n📊 Генерация графиков для {len(signal_groups)} групп сигналов...")
        
        # Для каждой группы генерируем графики
        for (symbol, timeframe), signals in signal_groups.items():
            print(f"\n   📈 Генерация графиков для {symbol} ({timeframe})...")
            
            # Загружаем данные (берем больше данных для лучшего контекста)
            # Вычисляем временные границы: от самого раннего сигнала минус 2 дня до самого позднего сигнала плюс 2 дня
            earliest_signal = min([s['timestamp'] for s in signals])
            latest_signal = max([s['timestamp'] for s in signals])
            start_time = earliest_signal - timedelta(days=2)
            end_time = latest_signal + timedelta(days=2)
            df = self.backtester.fetch_historical_data(symbol, timeframe, start_time, end_time)
            if df is None or len(df) < 50:  # 30 до сигнала + 20 после
                print(f"   ⚠️ Недостаточно данных для {symbol} ({timeframe})")
                continue
            
            # Генерируем графики для каждого сигнала
            for i, signal in enumerate(signals):
                try:
                    strategy = signal['strategy']
                    direction = signal['direction']
                    timestamp = signal['timestamp']
                    
                    # Проверяем, что сигнал находится в данных
                    if timestamp not in df.index:
                        print(f"   ⚠️ Сигнал {timestamp} не найден в данных")
                        continue
                    
                    # Генерируем график
                    filename = f"{charts_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy}_{direction}_{timestamp.strftime('%Y%m%d_%H%M')}.png"
                    success = self.generate_signal_chart(df, symbol, timeframe, strategy, direction, timestamp, filename)
                    
                    if success:
                        print(f"   ✅ График сохранен: {filename}")
                    else:
                        print(f"   ❌ Ошибка при генерации графика для {symbol} ({timeframe})")
                        
                except Exception as e:
                    print(f"   ❌ Ошибка при генерации графика: {e}")
                    continue

    def generate_optimization_comparison_charts(self, optimization_results, best_params):
        """Генерация сравнительных графиков после оптимизации"""
        if not hasattr(self.backtester, 'signals') or not self.backtester.signals:
            print("⚠️ Нет сигналов для генерации графиков")
            return
        
        # Создаем директорию для графиков
        charts_dir = "optimization_charts"
        if not os.path.exists(charts_dir):
            os.makedirs(charts_dir)
        
        # Получаем базовые параметры для сравнения
        from strategy_optimizer import StrategyOptimizer
        optimizer = StrategyOptimizer(use_original_base=True)
        base_params = optimizer._get_base_parameters_from_signal_bot()
        
        print(f"\n📊 Генерация сравнительных графиков...")
        
        # Для каждой стратегии и таймфрейма генерируем сравнительные графики
        for result in optimization_results:
            if result['status'] != 'completed' or not result['best_params']:
                continue
            
            strategy = result['strategy']
            timeframe = result['timeframe']
            best_optimized_params = result['best_params']
            
            # Получаем базовые параметры для этой стратегии
            before_params = base_params.get(strategy, {})
            
            print(f"\n   📊 Генерация сравнительных графиков для {strategy} ({timeframe})...")
            
            # Получаем сигналы для этой стратегии и таймфрейма
            strategy_signals = [s for s in self.backtester.signals 
                              if s['strategy'] == strategy and s['timeframe'] == timeframe]
            
            if not strategy_signals:
                print(f"   ⚠️ Нет сигналов для {strategy} ({timeframe})")
                continue
            
            # Выбираем случайные сигналы (или последние, если их меньше)
            count = min(3, len(strategy_signals))  # Максимум 3 графика для каждой стратегии
            import random
            selected_signals = random.sample(strategy_signals, count) if len(strategy_signals) > count else strategy_signals
            
            for i, signal in enumerate(selected_signals):
                try:
                    symbol = signal['symbol']
                    direction = signal['direction']
                    timestamp = signal['timestamp']
                    
                    # Загружаем данные (берем больше данных для лучшего контекста)
                    # Вычисляем временные границы: от сигнала минус 2 дня до сигнала плюс 2 дня
                    start_time = timestamp - timedelta(days=2)
                    end_time = timestamp + timedelta(days=2)
                    df = self.backtester.fetch_historical_data(symbol, timeframe, start_time, end_time)
                    if df is None or len(df) < 50:  # 30 до сигнала + 20 после
                        print(f"   ⚠️ Недостаточно данных для {symbol} ({timeframe})")
                        continue
                    
                    # Проверяем, что сигнал находится в данных
                    if timestamp not in df.index:
                        print(f"   ⚠️ Сигнал {timestamp} не найден в данных")
                        continue
                    
                    # Генерируем сравнительный график
                    filename = f"{charts_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy}_{direction}_{timestamp.strftime('%Y%m%d_%H%M')}_comparison.png"
                    success = self.generate_comparison_chart(
                        df, symbol, timeframe, strategy, direction, timestamp, 
                        before_params, best_optimized_params, filename)
                    
                    if success:
                        print(f"   ✅ Сравнительный график сохранен: {filename}")
                    else:
                        print(f"   ❌ Ошибка при генерации сравнительного графика для {symbol} ({timeframe})")
                        
                except Exception as e:
                    print(f"   ❌ Ошибка при генерации сравнительного графика: {e}")
                    continue