#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Адаптер для работы торгового бота на мобильной платформе Android
Содержит упрощенные версии компонентов, которые несовместимы с мобильной средой
"""

import os
import sys
import time
import json
import sqlite3
from datetime import datetime
import threading
from threading import Thread, Lock

# Глобальные переменные для мобильной версии
MOBILE_DB_PATH = "trading_bot.db"
MOBILE_SIGNALS_FILE = "signals.txt"
MOBILE_ENV_FILE = ".env"

class MobileGateIO:
    """Упрощенная версия GateIO для мобильной платформы"""
    
    def __init__(self, user_data):
        self.user_id = user_data['user_id']
        self.user_data = user_data
        self.api_key = user_data['api_key']
        self.api_secret = user_data['api_secret']
        self.leverage = user_data.get('leverage', 10.0)
        self.margin_mode = user_data.get('margin_mode', 'isolated')
        self.qty_percentage = min(user_data.get('qty_percentage', 5.0), 50.0)
        self.order_type = user_data.get('order_type', 'percentage')
        self.fixed_volume = user_data.get('fixed_volume', 100.0)
        self.trailing_interval = user_data.get('trailing_interval', 3.0)
        self.trailing_threads = {}
        
        # Имитация инициализации API
        print(f"Инициализация мобильного GateIO для пользователя {self.user_id}")
    
    def get_current_price(self, symbol):
        """Имитация получения текущей цены"""
        # В мобильной версии возвращаем случайную цену для демонстрации
        import random
        return round(random.uniform(30000, 40000), 2)
    
    def get_balance_usdt(self):
        """Имитация получения баланса USDT"""
        # В мобильной версии возвращаем случайный баланс для демонстрации
        import random
        return round(random.uniform(1000, 10000), 2)
    
    def place_order(self, symbol, side, timescale='1h', qty=None, usdt_amount=None):
        """Имитация размещения ордера"""
        print(f"Мобильная версия: Размещение ордера {side} для {symbol}")
        # В мобильной версии просто имитируем размещение ордера
        return "MOBILE_ORDER_ID", 1.0
    
    def close_position_enhanced(self, symbol, side, qty, reason="manual"):
        """Имитация закрытия позиции"""
        print(f"Мобильная версия: Закрытие позиции {side} для {symbol}")
        return "MOBILE_CLOSE_ID", qty

class MobileTrailingStopManager:
    """Упрощенный менеджер трейлинг-стопа для мобильной платформы"""
    
    def __init__(self, gate_io_instance):
        self.gate_io = gate_io_instance
        self.user_id = gate_io_instance.user_id
        self.trailing_threads = {}
    
    def start_monitoring(self, symbol, side):
        """Запуск мониторинга трейлинг-стопа"""
        print(f"Мобильная версия: Запуск мониторинга для {symbol} ({side})")
        # В мобильной версии просто имитируем запуск
        
    def stop_monitoring(self, symbol, side):
        """Остановка мониторинга трейлинг-стопа"""
        print(f"Мобильная версия: Остановка мониторинга для {symbol} ({side})")

def mobile_get_user_data(user_id):
    """Упрощенная версия получения данных пользователя для мобильной платформы"""
    try:
        conn = sqlite3.connect(MOBILE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT user_id, api_key, api_secret, account_type, leverage, margin_mode, order_type,
                   qty_percentage, fixed_volume, initial_stop_percentage, trigger_profit_percentage,
                   profit_lock_percentage, trailing_percentage, trailing_interval, daily_loss_limit,
                   max_open_trades, is_trading, report_type, report_time, averaging_enabled, averaging_pause
            FROM users WHERE user_id = ?
        ''', (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'user_id': row[0], 'api_key': row[1], 'api_secret': row[2], 'account_type': row[3],
                'leverage': row[4], 'margin_mode': row[5], 'order_type': row[6], 'qty_percentage': row[7],
                'fixed_volume': row[8], 'initial_stop_percentage': row[9], 'trigger_profit_percentage': row[10],
                'profit_lock_percentage': row[11], 'trailing_percentage': row[12], 'trailing_interval': row[13],
                'daily_loss_limit': row[14], 'max_open_trades': row[15], 'is_trading': row[16],
                'report_type': row[17], 'report_time': row[18], 'averaging_enabled': row[19],
                'averaging_pause': row[20]
            }
        return None
    except Exception as e:
        print(f"Ошибка получения данных пользователя: {e}")
        return None

def mobile_get_tp_config(user_id, timescale):
    """Упрощенная версия получения конфигурации TP/SL для мобильной платформы"""
    try:
        conn = sqlite3.connect(MOBILE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT stop_loss_percentage, trigger_profit_percentage, trailing_percentage, profit_lock_percentage
            FROM tp_config WHERE user_id = ? AND timescale = ?
        ''', (user_id, timescale))
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'stop_loss_percentage': result[0],
                'trigger_profit_percentage': result[1],
                'trailing_percentage': result[2],
                'profit_lock_percentage': result[3]
            }
        
        # Если конфигурация не найдена, возвращаем значения по умолчанию
        user_data = mobile_get_user_data(user_id)
        if user_data:
            return {
                'stop_loss_percentage': user_data.get('initial_stop_percentage', 3.0),
                'trigger_profit_percentage': user_data.get('trigger_profit_percentage', 5.0),
                'trailing_percentage': user_data.get('trailing_percentage', 1.0),
                'profit_lock_percentage': user_data.get('profit_lock_percentage', 2.0)
            }
        
        return {
            'stop_loss_percentage': 3.0,
            'trigger_profit_percentage': 5.0,
            'trailing_percentage': 1.0,
            'profit_lock_percentage': 2.0
        }
    except Exception as e:
        print(f"Ошибка получения конфигурации TP/SL: {e}")
        return {
            'stop_loss_percentage': 3.0,
            'trigger_profit_percentage': 5.0,
            'trailing_percentage': 1.0,
            'profit_lock_percentage': 2.0
        }

def mobile_setup_database():
    """Упрощенная версия создания базы данных для мобильной платформы"""
    try:
        conn = sqlite3.connect(MOBILE_DB_PATH)
        cursor = conn.cursor()
        
        # Создание таблицы users
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users
            (
                user_id INTEGER PRIMARY KEY,
                api_key TEXT,
                api_secret TEXT,
                account_type TEXT DEFAULT 'demo',
                leverage REAL DEFAULT 10.0,
                margin_mode TEXT DEFAULT 'isolated',
                order_type TEXT DEFAULT 'percentage',
                qty_percentage REAL DEFAULT 5.0,
                fixed_volume REAL DEFAULT 100.0,
                initial_stop_percentage REAL DEFAULT 3.0,
                trigger_profit_percentage REAL DEFAULT 5.0,
                profit_lock_percentage REAL DEFAULT 2.0,
                trailing_percentage REAL DEFAULT 1.0,
                trailing_interval REAL DEFAULT 3.0,
                daily_loss_limit INTEGER DEFAULT 3,
                max_open_trades INTEGER DEFAULT 5,
                is_trading INTEGER DEFAULT 0,
                report_type TEXT DEFAULT 'fixed',
                report_time TEXT DEFAULT '00:00',
                averaging_enabled INTEGER DEFAULT 0,
                averaging_pause REAL DEFAULT 300.0
            )
        ''')
        
        # Создание таблицы trades
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trades
            (
                trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                symbol TEXT,
                side TEXT,
                price REAL,
                amount REAL,
                timestamp INTEGER,
                status TEXT,
                timescale TEXT,
                current_stop_price REAL,
                open_order_id TEXT,
                close_order_id TEXT,
                average_entry_price REAL,
                trailing_active INTEGER DEFAULT 0,
                highest_price REAL,
                lowest_price REAL,
                close_reason TEXT,
                close_price REAL,
                pnl REAL DEFAULT 0.0,
                fees REAL DEFAULT 0.0,
                original_stop_price REAL,
                trailing_stop_price REAL,
                margin REAL,
                balance_at_open REAL,
                signal_id TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Создание таблицы tp_config
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tp_config
            (
                user_id INTEGER,
                timescale TEXT NOT NULL,
                stop_loss_percentage REAL,
                trigger_profit_percentage REAL,
                trailing_percentage REAL,
                profit_lock_percentage REAL,
                pnl_based_trailing BOOLEAN DEFAULT 0,
                PRIMARY KEY (user_id, timescale)
            )
        ''')
        
        # Добавляем пользователя по умолчанию, если таблица пуста
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO users (user_id) VALUES (0)")
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Ошибка создания базы данных: {e}")
        return False

def mobile_load_environment():
    """Упрощенная версия загрузки переменных окружения для мобильной платформы"""
    # В мобильной версии переменные окружения могут быть недоступны
    # Возвращаем значения по умолчанию или из файла .env если он существует
    env_vars = {
        'TELEGRAM_TOKEN': '',
        'GROUP_CHAT_ID': '0',
        'ALLOWED_USERS': '',
        'GATEIO_API_KEY': '',
        'GATEIO_API_SECRET': ''
    }
    
    # Пытаемся загрузить из файла .env
    if os.path.exists(MOBILE_ENV_FILE):
        try:
            with open(MOBILE_ENV_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    if '=' in line and not line.startswith('#'):
                        key, value = line.strip().split('=', 1)
                        env_vars[key] = value
        except Exception as e:
            print(f"Ошибка загрузки .env файла: {e}")
    
    return (
        env_vars['TELEGRAM_TOKEN'],
        env_vars['GROUP_CHAT_ID'],
        env_vars['ALLOWED_USERS'],
        env_vars['GATEIO_API_KEY'],
        env_vars['GATEIO_API_SECRET']
    )

# Функции для работы с сигналами
def mobile_load_signals(signals_file=None):
    """Упрощенная версия загрузки сигналов для мобильной платформы"""
    if signals_file is None:
        signals_file = MOBILE_SIGNALS_FILE
    
    signals = []
    if os.path.exists(signals_file):
        try:
            with open(signals_file, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    # Парсим строку сигнала
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            timestamp_str = parts[0] + ' ' + parts[1]
                            timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                            symbol = parts[2]
                            direction = parts[3].upper()
                            
                            # Определяем таймфрейм из символа
                            timeframe = '1h'  # Значение по умолчанию
                            if len(parts) > 4:
                                timeframe = parts[4]
                            
                            # Определяем стратегию
                            strategy = 'UNKNOWN'
                            if len(parts) > 5:
                                strategy = parts[5]
                            
                            signals.append({
                                'timestamp': timestamp,
                                'symbol': symbol,
                                'direction': direction,
                                'timeframe': timeframe,
                                'strategy': strategy
                            })
                        except ValueError as e:
                            print(f"Ошибка парсинга сигнала в строке {line_num}: {e}")
                            continue
        except Exception as e:
            print(f"Ошибка загрузки файла сигналов: {e}")
    
    return signals

# Имитация Telegram бота для мобильной версии
class MobileTelegramBot:
    """Упрощенная версия Telegram бота для мобильной платформы"""
    
    def __init__(self, token):
        self.token = token
        print(f"Инициализация мобильного Telegram бота с токеном: {token[:10]}...")
    
    def send_message(self, chat_id, text):
        """Имитация отправки сообщения"""
        print(f"Мобильная версия Telegram: Отправка сообщения в чат {chat_id}")
        print(f"Сообщение: {text}")
        # В мобильной версии просто выводим сообщение в консоль

# Глобальные переменные для мобильной версии
MOBILE_TELEGRAM_TOKEN, MOBILE_GROUP_CHAT_ID_STR, MOBILE_ALLOWED_USERS_STR, MOBILE_GATEIO_API_KEY, MOBILE_GATEIO_API_SECRET = mobile_load_environment()
MOBILE_GROUP_CHAT_ID = int(MOBILE_GROUP_CHAT_ID_STR) if MOBILE_GROUP_CHAT_ID_STR.replace('-', '').isdigit() else 0
MOBILE_ALLOWED_USERS = [int(uid) for uid in MOBILE_ALLOWED_USERS_STR.split(',') if uid and uid.isdigit()]

# Инициализация мобильного Telegram бота
mobile_bot = MobileTelegramBot(MOBILE_TELEGRAM_TOKEN) if MOBILE_TELEGRAM_TOKEN else None

if __name__ == "__main__":
    print("Мобильный адаптер готов к использованию")
    print(f"База данных: {MOBILE_DB_PATH}")
    print(f"Файл сигналов: {MOBILE_SIGNALS_FILE}")